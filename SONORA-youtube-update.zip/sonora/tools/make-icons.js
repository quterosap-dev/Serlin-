#!/usr/bin/env node
/* Renders dist/icons/icon-192.png, icon-512.png, icon-maskable-512.png from dist/icons/icon.svg using Playwright's Chromium.
   Run after `node build.js`:  node tools/make-icons.js            */
const fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const dir = path.join(__dirname, '..', 'dist', 'icons');
const svg = fs.readFileSync(path.join(dir, 'icon.svg'), 'utf8');
const glyph = svg.replace(/<rect[^>]*\/>/, '');            // logo strokes without the rounded square
const grad = svg.match(/<defs>[\s\S]*?<\/defs>/)[0];
(async () => {
  const b = await chromium.launch(); const p = await b.newPage();
  const shot = async (name, size, html) => { await p.setViewportSize({ width: size, height: size }); await p.setContent(`<body style="margin:0;background:transparent">${html}</body>`); await p.screenshot({ path: path.join(dir, name), omitBackground: true }); console.log('wrote', name); };
  await shot('icon-192.png', 192, `<img width=192 height=192 src="data:image/svg+xml;utf8,${encodeURIComponent(svg)}">`);
  await shot('icon-512.png', 512, `<img width=512 height=512 src="data:image/svg+xml;utf8,${encodeURIComponent(svg)}">`);
  // maskable: full-bleed gradient, glyph kept inside the central 72% "safe zone"
  const mask = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="512" height="512">${grad}<rect width="64" height="64" fill="url(#g)"/><g transform="translate(32 32) scale(.72) translate(-32 -32)">${glyph.replace(/<\/?svg[^>]*>/g, '').replace(/<defs>[\s\S]*?<\/defs>/, '')}</g></svg>`;
  await shot('icon-maskable-512.png', 512, `<img width=512 height=512 src="data:image/svg+xml;utf8,${encodeURIComponent(mask)}">`);
  await b.close();
})();
