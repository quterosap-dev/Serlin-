/* ==========================================================================
   SONORA — 07 browse views: Home, Explore (+ category pages), Search
   Everything shown as "real" comes from a provider response. Curated tiles
   (genres, moods, languages) are labelled as SONORA shortcuts.
   ========================================================================== */

const LOGO = `<svg class="logo" viewBox="0 0 64 64" role="img" aria-label="SONORA"><use href="#logo"/></svg>`;
const AUDIUS_GENRES = ['Electronic', 'Rock', 'Metal', 'Alternative', 'Hip-Hop/Rap', 'Experimental', 'Punk', 'Folk', 'Pop', 'Ambient', 'Soundtrack', 'World', 'Jazz', 'Acoustic', 'Funk', 'R&B/Soul', 'Devotional', 'Classical', 'Reggae', 'Country', 'Blues', 'Latin', 'Lo-Fi', 'Hyperpop', 'Dancehall', 'Techno', 'Trap', 'House', 'Disco', 'Trance', 'Dubstep', 'Drum & Bass'];

function topbar({ title = '', back = false, actions = '' } = {}) {
  return `<header class="topbar">${back ? `<button class="icon-btn" type="button" data-act="back" aria-label="Back">${ic('chevron-left')}</button>` : ''}${title ? `<h1 class="top-title">${esc(title)}</h1>` : ''}<span class="spacer"></span>${actions}</header>`;
}
const seeAll = (cat, label = 'See all') => `<button type="button" class="link-btn" data-act="openCat" data-cat="${cat}">${label}</button>`;

/* deterministic shuffle so "Daily Mix" is stable through a day */
function seededShuffle(list, seed) {
  let s = hashStr(seed) || 1;
  const rnd = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
const slug = s => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

/* ---------- shared loaders ---------- */
const trendWeek = () => Audius.trending({ time: 'week', limit: 50 });
function artistsFromTracks(tracks) {
  const m = new Map();
  tracks.forEach(t => {
    if (!t.artistId) return;
    const a = m.get(t.artistId) || { id: t.artistId, rid: String(t.artistId).slice(3), src: t.src, name: t.artist, handle: t.handle, img480: t.uimg || '', img150: t.uimg150 || '', followers: t.ufol || 0, plays: 0 };
    a.plays += t.plays || 0; m.set(t.artistId, a);
  });
  return [...m.values()].sort((a, b) => b.plays - a.plays);
}
async function loadAlbums(kind = 'album') {
  let out = [], err = null;
  try { out = (await Audius.trendingLists({ type: kind })).filter(x => x.kind === kind); } catch (e) { err = e; }
  if (!out.length) { try { out = (await Audius.searchLists(kind)).filter(x => x.kind === kind); } catch (e) { err = err || e; } }
  if (!out.length && err) throw err;
  return out;
}
async function loadRecommended() {
  const taste = Lib.taste(), heard = new Set([...LIB.history.map(x => x.t.id), ...LIB.liked.map(x => x.t.id)]);
  const genres = taste.genres.filter(g => AUDIUS_GENRES.includes(g)).slice(0, 2);
  const artists = taste.artists.filter(a => a.id && a.id.startsWith('au:')).slice(0, 2);
  const personal = genres.length + artists.length > 0;
  const jobs = personal
    ? [...genres.map(g => Audius.trending({ genre: g, time: 'month', limit: 30 })), ...artists.map(a => Audius.userTracks(a.id.slice(3), { limit: 15 }))]
    : [Audius.trending({ time: 'month', limit: 40 })];
  const res = await Promise.allSettled(jobs);
  const ok = res.filter(r => r.status === 'fulfilled').map(r => r.value);
  if (!ok.length) throw res[0].reason;
  const tracks = interleave(...ok).filter(t => t.stream !== false && (!personal || !heard.has(t.id))).slice(0, 20);
  REC_META = { personal, genres, artists };
  return tracks;
}
let REC_META = { personal: false, genres: [], artists: [] };
async function loadMixes() {
  const taste = Lib.taste();
  let gs = taste.genres.filter(g => AUDIUS_GENRES.includes(g)).slice(0, 3);
  const personal = gs.length > 0;
  for (const d of ['Electronic', 'Hip-Hop/Rap', 'Pop', 'Lo-Fi', 'Rock']) if (gs.length < 3 && !gs.includes(d)) gs.push(d);
  gs = gs.slice(0, 3);
  const res = await Promise.allSettled(gs.map(g => Audius.trending({ genre: g, time: 'month', limit: 30 })));
  const mixes = res.map((r, i) => (r.status === 'fulfilled' && r.value.length >= 5)
    ? rememberEnt({ id: 'mix:' + slug(gs[i]), kind: 'mix', name: `Daily Mix ${i + 1}`, desc: gs[i], genre: gs[i], tracks: seededShuffle(r.value, dayKey() + gs[i]).slice(0, 25), gen: true, personal })
    : null).filter(Boolean);
  if (!mixes.length && res.every(r => r.status === 'rejected')) throw res[0].reason;
  return mixes;
}

/* ==========================================================================
   HOME
   ========================================================================== */
function buildHome(el) {
  el.innerHTML = `
    <header class="topbar home-top">
      <div class="brand">${LOGO}<span class="wordmark">SONORA</span></div><span class="spacer"></span>
      <button class="icon-btn" type="button" data-act="homeRefresh" aria-label="Refresh home">${ic('refresh')}</button>
      <button class="icon-btn" type="button" data-act="openSettings" aria-label="Settings">${ic('settings')}</button>
    </header>
    <div class="pad">
      <h1 class="greet">${greeting()}</h1>
      <div id="home-continue"></div>
      <section class="sec" id="sh-recent">${sectionHead('Recently played', '', `<button type="button" class="link-btn" data-act="openLibTab" data-tab="recent">See all</button>`)}<div class="shelf" data-shelf="recent"></div></section>
      ${shelfSection('trending', 'Trending songs', 'This week on Audius', seeAll('cat:trending'))}
      ${shelfSection('made', 'Made for you', 'Generated on this device from what you play')}
      ${shelfSection('rec', 'Recommended', 'Popular picks')}
      ${shelfSection('new', 'New releases', 'Newest among this week’s trending tracks', seeAll('cat:new'))}
      ${shelfSection('albums', 'Popular albums', 'Albums trending on Audius', seeAll('cat:albums'))}
      ${shelfSection('lists', 'Featured playlists', 'Playlists trending on Audius')}
      ${shelfSection('artists', 'Popular artists', 'Most played artists in this week’s trending tracks', seeAll('cat:artists'))}
      ${Jamendo.enabled() ? shelfSection('jamendo', 'Popular on Jamendo', 'Creative Commons music via Jamendo') : ''}
      <p class="attrib">Music streams from <a href="https://audius.co" target="_blank" rel="noopener">Audius</a>${Jamendo.enabled() ? ' and <a href="https://www.jamendo.com" target="_blank" rel="noopener">Jamendo</a>' : ''}. Artwork and audio belong to the artists.</p>
    </div>`;
  renderHomeLocal(el);
  loadHomeShelves(el);
}
function renderContinue(el) {
  const box = $('#home-continue', el); if (!box) return;
  const t = curTrack() || (LIB.history[0] && LIB.history[0].t);
  if (!t) { box.innerHTML = ''; return; }
  const live = curTrack() && curTrack().id === t.id;
  const pos = live ? PS.pos : 0, dur = (live ? PS.dur : 0) || t.dur || 0;
  ensureTrack(t);
  box.innerHTML = `<div class="continue" data-act="continue" role="button" tabindex="0">
    <div class="cont-art">${artEl(t, 'md')}</div>
    <div class="cont-main"><span class="eyebrow">${PS.playing && live ? 'Now playing' : 'Continue listening'}</span>
      <div class="cont-title">${esc(t.title)}</div><div class="cont-sub">${esc(t.artist)}</div>
      <div class="cont-bar"><i style="width:${dur ? clamp(pos / dur * 100, 0, 100) : 0}%"></i></div>
      <div class="cont-time">${fmtTime(pos)}${dur ? ' / ' + fmtTime(dur) : ''}</div></div>
    <span class="fab" aria-label="${PS.playing && live ? 'Pause' : 'Play'}">${ic(PS.playing && live ? 'pause' : 'play')}</span></div>`;
}
function renderRecent(el) {
  const sh = $('[data-shelf="recent"]', el); if (!sh) return;
  const rec = uniqBy(LIB.history.map(x => x.t), x => x.id).slice(0, 12);
  if (!rec.length) { sh.classList.add('note'); sh.innerHTML = `<div class="shelf-note">Songs you play will show up here.</div>`; return; }
  sh.classList.remove('note');
  const k = regList(rec, { type: 'list', name: 'Recently played' });
  sh.innerHTML = rec.map((x, i) => trackCard(x, k, i)).join('');
}
function renderHomeLocal(el) { renderContinue(el); renderRecent(el); }
function loadHomeShelves(el) {
  const setSub = (id, txt) => { const s = $(`#sh-${id} .sec-sub`, el); if (s) s.textContent = txt; };
  fillShelf(el, 'trending', async () => {
    try {
      const t = await trendWeek();
      LS.set('snap', { t: t.slice(0, 20).map(slim), at: now() });
      return t.slice(0, 20);
    } catch (e) {
      const s = LS.get('snap', null);
      if (s && s.t && s.t.length) { setSub('trending', `Saved from ${new Date(s.at).toLocaleDateString()}. Reconnect for fresh results.`); return rememberTracks(s.t); }
      throw e;
    }
  }, items => { const k = regList(items, { type: 'list', name: 'Trending on Audius' }); return items.map((t, i) => trackCard(t, k, i)).join(''); });

  fillShelf(el, 'made', loadMixes, ms => { setSub('made', ms[0].personal ? 'Built on this device from what you play and like' : 'Starter mixes from popular genres. They adapt as you listen'); return ms.map(listCard).join(''); }, { hideIfEmpty: true });

  fillShelf(el, 'rec', loadRecommended, items => {
    const r = REC_META;
    setSub('rec', r.personal ? `Based on your listening${r.genres.length ? ' · ' + r.genres.join(', ') : ''}` : 'Popular picks. Play a few songs and this becomes personal');
    const k = regList(items, { type: 'list', name: 'Recommended' });
    return items.map((t, i) => trackCard(t, k, i)).join('');
  }, { hideIfEmpty: true });

  fillShelf(el, 'new', async () => (await trendWeek()).filter(t => t.rel).sort((a, b) => String(b.rel).localeCompare(String(a.rel))).slice(0, 20),
    items => { const k = regList(items, { type: 'list', name: 'New releases' }); return items.map((t, i) => trackCard(t, k, i)).join(''); }, { hideIfEmpty: true });

  fillShelf(el, 'albums', () => loadAlbums('album'), items => items.slice(0, 12).map(listCard).join(''), { emptyText: 'Audius returned no albums right now.' });
  fillShelf(el, 'lists', () => loadAlbums('playlist'), items => items.slice(0, 12).map(listCard).join(''), { emptyText: 'Audius returned no playlists right now.' });
  fillShelf(el, 'artists', async () => artistsFromTracks(await trendWeek()).slice(0, 12), items => items.map(artistCard).join(''), { round: true });
  if (Jamendo.enabled()) fillShelf(el, 'jamendo', () => Jamendo.popular({ limit: 20 }), items => { const k = regList(items, { type: 'list', name: 'Popular on Jamendo' }); return items.map((t, i) => trackCard(t, k, i)).join(''); });
}


/* ==========================================================================
   EXPLORE
   ========================================================================== */
const PATTERNS = [
  s => `<g fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="2">${[12, 24, 36, 48, 60, 72].map(r => `<circle cx="${70 + (s % 20)}" cy="${78 - (s % 14)}" r="${r}"/>`).join('')}</g>`,
  s => `<g fill="#fff" fill-opacity=".26">${[8, 20, 32, 44, 56, 68, 80, 92].map((x, i) => { const h = 20 + ((i * 41 + s) % 54); return `<rect x="${x}" y="${100 - h}" width="8" height="${h}" rx="4"/>`; }).join('')}</g>`,
  s => `<g fill="none" stroke="#fff" stroke-opacity=".32" stroke-width="2.4" stroke-linecap="round">${[0, 1, 2, 3].map(i => `<path d="M-10 ${52 + i * 12 + (s % 8)} Q 12 ${34 + i * 12} 34 ${52 + i * 12} T 78 ${52 + i * 12} T 122 ${52 + i * 12}"/>`).join('')}</g>`,
  s => `<g fill="#fff" fill-opacity=".3">${Array.from({ length: 30 }, (_, i) => `<circle cx="${45 + (i % 6) * 11}" cy="${10 + Math.floor(i / 6) * 11 + (s % 4)}" r="2.2"/>`).join('')}</g>`,
  s => `<g fill="#fff" fill-opacity=".2"><polygon points="${60 + s % 10},100 100,100 100,${40 + s % 12}"/><polygon points="30,100 70,100 70,${62 + s % 8}"/></g>`,
  s => `<g stroke="#fff" stroke-opacity=".26" stroke-width="3" stroke-linecap="round">${Array.from({ length: 9 }, (_, i) => `<line x1="${20 + i * 14}" y1="100" x2="${60 + i * 14}" y2="${30 + (s % 10)}"/>`).join('')}</g>`
];
function catArt(id, label, hue, note) {
  const h = hashStr(id);
  return `<div class="cat-art" style="--h:${hue};background:linear-gradient(145deg,hsl(${hue} 78% 50%),hsl(${(hue + 48) % 360} 72% 26%))">
    <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${PATTERNS[h % PATTERNS.length](h)}</svg>
    <span class="cat-label">${esc(label)}</span>${note ? `<span class="cat-note">${esc(note)}</span>` : ''}</div>`;
}

const GENRE_DEFS = [
  { id: 'pop', name: 'Pop', t: 'genre', g: 'Pop', jt: 'pop', hue: 332 },
  { id: 'rock', name: 'Rock', t: 'genre', g: 'Rock', jt: 'rock', hue: 8 },
  { id: 'hiphop', name: 'Hip-hop', t: 'genre', g: 'Hip-Hop/Rap', jt: 'hiphop', hue: 38 },
  { id: 'electronic', name: 'Electronic', t: 'genre', g: 'Electronic', jt: 'electronic', hue: 262 },
  { id: 'classical', name: 'Classical', t: 'genre', g: 'Classical', jt: 'classical', hue: 28 },
  { id: 'jazz', name: 'Jazz', t: 'genre', g: 'Jazz', jt: 'jazz', hue: 212 },
  { id: 'lofi', name: 'Lo-fi', t: 'genre', g: 'Lo-Fi', jt: 'lofi', hue: 168 },
  { id: 'instrumental', name: 'Instrumental', t: 'genre', q: 'instrumental', jt: 'instrumental', hue: 192 },
  { id: 'ambient', name: 'Ambient', t: 'genre', g: 'Ambient', jt: 'ambient', hue: 228 },
  { id: 'indie', name: 'Indie', t: 'genre', q: 'indie', jt: 'indie', hue: 86 },
  { id: 'acoustic', name: 'Acoustic', t: 'genre', g: 'Acoustic', jt: 'acoustic', hue: 48 },
  { id: 'dance', name: 'Dance', t: 'genre', q: 'dance', jt: 'dance', hue: 300 }
];
const LANG_DEFS = [
  { id: 'english', name: 'English', t: 'lang', q: 'english', jl: 'en', hue: 205 },
  { id: 'hindi', name: 'Hindi', t: 'lang', q: 'hindi', jl: 'hi', hue: 18 },
  { id: 'assamese', name: 'Assamese', t: 'lang', q: 'assamese', jl: 'as', hue: 140 },
  { id: 'punjabi', name: 'Punjabi', t: 'lang', q: 'punjabi', jl: 'pa', hue: 48 },
  { id: 'bengali', name: 'Bengali', t: 'lang', q: 'bengali', jl: 'bn', hue: 350 },
  { id: 'international', name: 'International', t: 'lang', g: 'World', hue: 250 }
];
const CAT_DEFS = [
  { id: 'trending', name: 'Trending now', t: 'trend', desc: 'The tracks Audius listeners are playing most this week.', hue: 10 },
  { id: 'new', name: 'New releases', t: 'new', desc: 'The newest tracks among this week’s trending music.', hue: 150 },
  { id: 'artists', name: 'Popular artists', t: 'artists', desc: 'Artists with the most plays in this week’s trending tracks.', hue: 280 },
  { id: 'albums', name: 'Popular albums', t: 'albums', desc: 'Albums trending on Audius right now.', hue: 200 },
  { id: 'relaxing', name: 'Relaxing music', t: 'query', q: 'relax', mood: ['Peaceful', 'Easygoing'], jt: 'relaxation', desc: 'Calm, easygoing tracks.', hue: 175 },
  { id: 'workout', name: 'Workout music', t: 'query', q: 'workout', mood: ['Energizing', 'Empowering'], jt: 'energetic', desc: 'High-energy tracks to move to.', hue: 14 },
  { id: 'study', name: 'Study music', t: 'query', q: 'study', jt: 'ambient', desc: 'Low-distraction music for studying.', hue: 220 },
  { id: 'sleep', name: 'Sleep music', t: 'query', q: 'sleep', jt: 'ambient', desc: 'Soft, slow music for winding down.', hue: 245 },
  { id: 'focus', name: 'Focus music', t: 'query', q: 'focus', jt: 'ambient', desc: 'Steady music to concentrate to.', hue: 190 },
  { id: 'romantic', name: 'Romantic music', t: 'query', q: 'romantic', mood: ['Romantic', 'Tender', 'Sensual'], jt: 'romantic', desc: 'Warm, tender love songs.', hue: 340 },
  { id: 'sad', name: 'Sad songs', t: 'query', q: 'sad', mood: ['Melancholy', 'Sentimental', 'Yearning'], jt: 'sad', desc: 'Melancholy and heartfelt tracks.', hue: 258 }
];
const CATS = new Map();
GENRE_DEFS.forEach(d => CATS.set('genre:' + d.id, d));
LANG_DEFS.forEach(d => CATS.set('lang:' + d.id, d));
CAT_DEFS.forEach(d => CATS.set('cat:' + d.id, d));

function buildExplore(el) {
  const tile = (key, d, note) => `<button type="button" class="tile" data-act="openCat" data-cat="${key}" aria-label="${esc(d.name)}">${catArt(key, d.name, d.hue, note)}</button>`;
  el.innerHTML = `
    ${topbar({ title: 'Explore' })}
    <div class="pad">
      <section class="sec">${sectionHead('Browse by genre', 'SONORA shortcuts. The songs inside load live from the connected music services.')}
        <div class="tiles">${GENRE_DEFS.map(d => tile('genre:' + d.id, d)).join('')}</div></section>
      <section class="sec">${sectionHead('Languages and regions', 'Audius has no language catalogue, so these run keyword searches. Expect uneven results.')}
        <div class="tiles">${LANG_DEFS.map(d => tile('lang:' + d.id, d)).join('')}</div></section>
      <section class="sec">${sectionHead('Categories', 'Charts and moods')}
        <div class="banners">${CAT_DEFS.map(d => `<button type="button" class="banner" data-act="openCat" data-cat="cat:${d.id}">${catArt('cat:' + d.id, d.name, d.hue)}<span class="banner-desc">${esc(d.desc)}</span>${ic('chevron-right')}</button>`).join('')}</div></section>
    </div>`;
}

/* ---------- category page ---------- */
const PAGE = 30;
async function loadCategory(def, offset = 0) {
  const jam = Jamendo.enabled();
  let tracks = [], more = false;
  if (def.t === 'trend') {
    tracks = await Audius.trending({ time: 'week', limit: PAGE, offset }); more = tracks.length === PAGE;
  } else if (def.t === 'new') {
    tracks = (await trendWeek()).filter(t => t.rel).sort((a, b) => String(b.rel).localeCompare(String(a.rel)));
  } else if (def.t === 'genre' || def.t === 'lang') {
    if (def.g) {
      tracks = await Audius.trending({ genre: def.g, time: 'month', limit: PAGE, offset });
      if (!offset && tracks.length < 8) tracks = interleave(tracks, await Audius.trending({ genre: def.g, time: 'allTime', limit: PAGE }));
      more = tracks.length >= PAGE;
    } else {
      tracks = await Audius.searchTracks(def.q, { limit: PAGE, offset }); more = tracks.length === PAGE;
    }
    if (jam && !offset) {
      const extra = def.t === 'lang' ? (def.jl ? await Jamendo.tracks({ lang: def.jl, order: 'popularity_week', limit: 15 }).catch(() => []) : [])
        : await Jamendo.tracks({ tags: def.jt || def.id, order: 'popularity_week', limit: 15 }).catch(() => []);
      tracks = interleave(tracks, extra);
    }
  } else if (def.t === 'query') {
    let a = [];
    if (def.mood) a = await Audius.searchTracks(def.q, { limit: PAGE, offset, mood: def.mood }).catch(() => []);
    const b = a.length < 8 ? await Audius.searchTracks(def.q, { limit: PAGE, offset }) : [];
    tracks = interleave(a, b); more = tracks.length >= PAGE;
    if (jam && !offset && def.jt) tracks = interleave(tracks, await Jamendo.tracks({ tags: def.jt, order: 'popularity_week', limit: 15 }).catch(() => []));
  }
  return { tracks, more };
}
function categoryNote(def) {
  if (def.t === 'genre' || def.t === 'lang') return def.g ? `Live from Audius, filtered by the “${def.g}” genre tag.` : `Keyword search on Audius for “${def.q}”. Results depend on how artists tagged their music.`;
  if (def.t === 'query') return `Keyword search on Audius for “${def.q}”${def.mood ? ` plus the ${def.mood.join(' / ')} mood tags` : ''}. Not a complete catalogue.`;
  return 'Live from Audius.';
}
function buildCategory(el, { cat }) {
  const def = CATS.get(cat);
  if (!def) { el.innerHTML = topbar({ back: true }) + emptyState({ icon: 'info', title: 'Unknown category' }); return; }
  let offset = 0, all = [];
  const head = `${topbar({ back: true, title: def.name })}
    <div class="pad"><div class="cat-hero">${catArt(cat, def.name, def.hue)}</div>
    <p class="muted cat-note">${esc(def.desc || '')} ${esc(categoryNote(def))}</p><div id="cat-body"></div></div>`;
  el.innerHTML = head;
  const body = $('#cat-body', el);
  const draw = (more) => {
    const ctx = { type: 'category', name: def.name };
    const key = regList(all, ctx);
    body.innerHTML = `<div class="action-row">
        <button type="button" class="btn primary" data-act="playAll" data-list="${key}">${ic('play')} Play</button>
        <button type="button" class="btn ghost" data-act="shuffleAll" data-list="${key}">${ic('shuffle')} Shuffle</button></div>
      <div class="rows" data-list="${key}">${all.map((t, i) => trackRow(t, { list: key, i })).join('')}</div>
      ${more ? `<div class="center"><button type="button" class="btn ghost" id="cat-more">Load more</button></div>` : ''}`;
    const mb = $('#cat-more', body);
    if (mb) mb.addEventListener('click', () => { mb.disabled = true; mb.textContent = 'Loading…'; load(); });
  };
  const load = async () => {
    try {
      if (def.t === 'artists') {
        const arts = artistsFromTracks(await trendWeek());
        body.innerHTML = arts.length ? `<div class="grid-cards">${arts.map(artistCard).join('')}</div>` : emptyState({ icon: 'user', title: 'No artists returned', text: 'Audius returned no trending tracks right now.' });
        return;
      }
      if (def.t === 'albums') {
        const l = await loadAlbums('album');
        body.innerHTML = l.length ? `<div class="grid-cards">${l.map(listCard).join('')}</div>` : emptyState({ icon: 'disc', title: 'No albums returned', text: 'Audius returned no albums right now.' });
        return;
      }
      if (!offset) body.innerHTML = skelRows(8);
      const r = await loadCategory(def, offset);
      if (!el.isConnected) return;
      all = uniqBy(all.concat(r.tracks), t => t.id); offset += PAGE;
      if (!all.length) { body.innerHTML = emptyState({ icon: 'music', title: 'Nothing found', text: 'The connected music services returned no tracks for this category. Try another one, or search for a specific artist.' }); return; }
      draw(r.more);
    } catch (e) {
      if (!el.isConnected) return;
      if (all.length) { toast(errMsg(e), { kind: 'warn' }); draw(false); }
      else body.innerHTML = errorState(e, { act: 'retryCat', data: { cat } });
    }
  };
  el._retry = () => { offset = 0; all = []; load(); };
  load();
}

/* ==========================================================================
   SEARCH
   ========================================================================== */
const SS = { q: '', tab: 'all', seq: 0, abort: null, loading: false, results: null };
const SEARCH_TABS = [['all', 'All'], ['songs', 'Songs'], ['artists', 'Artists'], ['albums', 'Albums'], ['playlists', 'Playlists'], ['genres', 'Genres'], ['library', 'Your library']];

function libraryMatches(q) {
  const s = q.toLowerCase(), has = t => `${t.title} ${t.artist} ${t.album || ''}`.toLowerCase().includes(s);
  const tracks = uniqBy([...LOCAL, ...LIB.liked.map(x => x.t), ...LIB.downloads, ...LIB.history.map(x => x.t), ...LIB.playlists.flatMap(p => p.tracks)].filter(has), t => t.id);
  return {
    tracks,
    playlists: LIB.playlists.filter(p => p.name.toLowerCase().includes(s)),
    artists: LIB.followed.filter(a => a.name.toLowerCase().includes(s))
  };
}
function browseMatches(q) {
  const s = q.toLowerCase();
  return [...GENRE_DEFS.map(d => ['genre:' + d.id, d]), ...LANG_DEFS.map(d => ['lang:' + d.id, d]), ...CAT_DEFS.filter(d => d.t === 'query').map(d => ['cat:' + d.id, d])]
    .filter(([, d]) => d.name.toLowerCase().includes(s) || (d.g || '').toLowerCase().includes(s));
}

function buildSearch(el) {
  el.innerHTML = `
    ${topbar({ title: 'Search' })}
    <div class="searchbar"><div class="search-field">${ic('search')}
      <input id="search-input" type="search" inputmode="search" enterkeyhint="search" autocomplete="off" spellcheck="false" placeholder="Songs, artists, albums, playlists" aria-label="Search" value="${esc(SS.q)}">
      <button class="icon-btn" id="search-clear" type="button" data-act="searchClear" aria-label="Clear search" ${SS.q ? '' : 'hidden'}>${ic('x')}</button></div></div>
    <div class="pad"><button type="button" class="btn ghost small" data-act="youtubePlayLink">${ic('play')} Play a YouTube link inside SONORA</button></div>
    <div class="pad" id="search-body"></div>`;
  const input = $('#search-input', el);
  const run = debounce(q => runSearch(q), 300);
  input.addEventListener('input', () => {
    SS.q = input.value.trim();
    $('#search-clear', el).hidden = !SS.q;
    if (!SS.q) { run.cancel(); if (SS.abort) SS.abort.abort(); SS.seq++; SS.loading = false; SS.results = null; renderSearchBody(); return; }
    SS.loading = true; renderSearchBody(); run(SS.q);
  });
  input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); run.cancel(); if (SS.q) { Lib.addSearch(SS.q); runSearch(SS.q); } input.blur(); } });
  watch(el, 'lib', k => { if (k === 'searches' && !SS.q) renderSearchBody(); });
  renderSearchBody();
  if (SS.q && !SS.results) runSearch(SS.q);
}
async function runSearch(q) {
  const seq = ++SS.seq;
  if (SS.abort) SS.abort.abort();
  SS.abort = new AbortController(); SS.loading = true; renderSearchBody();
  const res = await searchAll(q, { signal: SS.abort.signal });
  if (seq !== SS.seq) return;
  SS.loading = false; SS.results = { q, ...res }; renderSearchBody();
}
function setSearch(q, commit) {
  SS.q = q;
  const input = $('#search-input'); if (input) { input.value = q; $('#search-clear').hidden = !q; }
  if (commit && q) Lib.addSearch(q);
  if (q) { SS.results = null; runSearch(q); } else { SS.results = null; SS.loading = false; renderSearchBody(); }
}

function renderSearchBody() {
  const body = $('#search-body'); if (!body) return;
  const q = SS.q;
  if (!q) { body.innerHTML = searchIdleHtml(); loadTrendingSearches(); return; }
  const lib = libraryMatches(q), br = browseMatches(q), R = SS.results && SS.results.q === q ? SS.results : null;
  const tabs = `<div class="chips" role="tablist">${SEARCH_TABS.map(([k, l]) => `<button type="button" role="tab" class="chip ${SS.tab === k ? 'on' : ''}" data-act="searchTab" data-tab="${k}" aria-selected="${SS.tab === k}">${l}</button>`).join('')}</div>`;
  const hist = LIB.searches.filter(h => h.toLowerCase().includes(q.toLowerCase()) && h.toLowerCase() !== q.toLowerCase()).slice(0, 3);
  const sugg = hist.length ? `<div class="sugg">${hist.map(h => `<button type="button" class="sugg-item" data-act="searchSet" data-q="${esc(h)}">${ic('clock')}<span>${esc(h)}</span></button>`).join('')}</div>` : '';
  let html = tabs + sugg;
  const tracks = R ? R.tracks : [], artists = R ? R.artists : [], lists = R ? R.lists : [];
  const albums = lists.filter(l => l.kind === 'album'), plays = lists.filter(l => l.kind === 'playlist');
  const sectionRows = (title, list, ctxName, limit, tab) => {
    if (!list.length) return '';
    const shown = limit ? list.slice(0, limit) : list;
    const key = regList(list, { type: 'search', name: `Search: ${q}` });
    return `<section class="sec">${sectionHead(title, '', limit && list.length > limit ? `<button type="button" class="link-btn" data-act="searchTab" data-tab="${tab}">See all</button>` : '')}
      <div class="rows" data-list="${key}">${shown.map((t, i) => trackRow(t, { list: key, i })).join('')}</div></section>`;
  };
  const shelfOf = (title, items, fn, tab, limit = 10) => items.length ? `<section class="sec">${sectionHead(title, '', items.length > 4 && SS.tab === 'all' ? `<button type="button" class="link-btn" data-act="searchTab" data-tab="${tab}">See all</button>` : '')}
      <div class="${SS.tab === 'all' ? 'shelf' : 'grid-cards'}">${items.slice(0, SS.tab === 'all' ? limit : 60).map(fn).join('')}</div></section>` : '';
  const genreTiles = br.length ? `<section class="sec">${sectionHead('Genres and categories')}<div class="tiles small">${br.slice(0, SS.tab === 'all' ? 6 : 30).map(([key, d]) => `<button type="button" class="tile" data-act="openCat" data-cat="${key}">${catArt(key, d.name, d.hue)}</button>`).join('')}</div></section>` : '';
  const libHtml = (lib.tracks.length || lib.playlists.length || lib.artists.length) ? `<section class="sec">${sectionHead('In your library')}
      ${lib.playlists.length ? `<div class="shelf">${lib.playlists.slice(0, 8).map(p => listCard({ ...p, kind: 'userlist' })).join('')}</div>` : ''}
      ${lib.tracks.length ? (() => { const k = regList(lib.tracks, { type: 'search', name: 'Your library' }); return `<div class="rows" data-list="${k}">${lib.tracks.slice(0, SS.tab === 'all' ? 4 : 100).map((t, i) => trackRow(t, { list: k, i })).join('')}</div>`; })() : ''}</section>` : '';
  const loadingBlock = SS.loading ? `<div class="loading-line" role="status">${ic('refresh', 'spin')} Searching${providerCount() > 1 ? ' all sources' : ' Audius'}…</div>${SS.tab === 'all' || SS.tab === 'songs' ? skelRows(4) : ''}` : '';
  const T = SS.tab;
  if (T === 'all') html += sectionRows('Songs', tracks, 'Songs', 5, 'songs') + shelfOf('Artists', artists, artistCard, 'artists') + shelfOf('Albums', albums, listCard, 'albums') + shelfOf('Playlists', plays, listCard, 'playlists') + genreTiles + libHtml;
  else if (T === 'songs') html += sectionRows('Songs', tracks, 'Songs', 0, 'songs');
  else if (T === 'artists') html += shelfOf('Artists', artists, artistCard, 'artists');
  else if (T === 'albums') html += shelfOf('Albums', albums, listCard, 'albums');
  else if (T === 'playlists') html += shelfOf('Playlists', plays, listCard, 'playlists');
  else if (T === 'genres') html += genreTiles;
  else if (T === 'library') html += libHtml;
  html += loadingBlock;
  const any = tracks.length || artists.length || lists.length || br.length || lib.tracks.length || lib.playlists.length || lib.artists.length;
  if (R && R.errors.length) {
    const net = R.errors.some(e => e.kind === 'network' || e.kind === 'offline');
    html += `<div class="notice warn">${ic('alert')}<div><strong>${R.errors.length === 1 + (providerCount() > 1 ? 0 : 2) && !any ? 'Search couldn’t finish.' : 'Some results couldn’t load.'}</strong>
      <p>${esc(net ? (NET.state === 'offline' ? 'You’re offline. Your library results are still shown.' : 'Couldn’t reach the music service. Library results are still shown.') : R.errors[0].msg)}</p>
      <button type="button" class="btn ghost small" data-act="searchRetry">${ic('refresh')} Retry</button></div></div>`;
  }
  if (!SS.loading && R && !any) html += emptyState({ icon: 'search', title: `No results for “${q}”`, text: 'Check the spelling or try a different keyword. SONORA searches the connected music services, which are smaller than the big commercial catalogues.' });
  body.innerHTML = html;
}
function searchIdleHtml() {
  const recents = LIB.searches.length ? `<section class="sec">${sectionHead('Recent searches', '', `<button type="button" class="link-btn" data-act="searchClearHistory">Clear</button>`)}
    <div class="chips wrap">${LIB.searches.map(q => `<span class="chip-x"><button type="button" class="chip" data-act="searchSet" data-q="${esc(q)}">${ic('clock')} ${esc(q)}</button><button type="button" class="chip-del" data-act="searchRemove" data-q="${esc(q)}" aria-label="Remove ${esc(q)}">${ic('x')}</button></span>`).join('')}</div></section>` : '';
  const items = LIB.recentItems.length ? `<section class="sec">${sectionHead('Recently viewed')}<div class="shelf">${LIB.recentItems.map(r => {
    if (r.type === 'track') { rememberTrack(r.data); const k = regList([r.data], { type: 'track', name: r.data.title }); return trackCard(r.data, k, 0); }
    if (r.type === 'artist') return artistCard(r.data);
    return listCard(r.data);
  }).join('')}</div></section>` : '';
  return `${recents}${items}
    <section class="sec" id="trending-searches">${sectionHead('Trending on Audius', 'Tap to search')}<div class="chips wrap" id="trend-chips"><span class="muted">Loading…</span></div></section>
    <section class="sec">${sectionHead('Browse genres')}<div class="tiles small">${GENRE_DEFS.map(d => `<button type="button" class="tile" data-act="openCat" data-cat="genre:${d.id}">${catArt('genre:' + d.id, d.name, d.hue)}</button>`).join('')}</div></section>`;
}
async function loadTrendingSearches() {
  const box = $('#trend-chips'); if (!box) return;
  try {
    const t = await trendWeek();
    if (!$('#trend-chips')) return;
    const terms = uniqBy([...t.slice(0, 8).map(x => x.title), ...t.slice(0, 20).map(x => x.artist)], x => x.toLowerCase()).slice(0, 10);
    $('#trend-chips').innerHTML = terms.length ? terms.map(q => `<button type="button" class="chip" data-act="searchSet" data-q="${esc(q)}">${ic('trending')} ${esc(q)}</button>`).join('') : '<span class="muted">Nothing trending right now.</span>';
  } catch (e) {
    const b = $('#trend-chips'); if (b) b.innerHTML = `<span class="muted">${esc(e.kind === 'offline' ? 'Offline. Trending searches return when you reconnect.' : 'Trending searches are unavailable right now.')}</span>`;
  }
}

TAB_BUILDERS.home = buildHome;
TAB_BUILDERS.explore = buildExplore;
TAB_BUILDERS.search = buildSearch;
VIEW_BUILDERS.category = buildCategory;
