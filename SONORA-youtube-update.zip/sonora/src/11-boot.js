/* ==========================================================================
   SONORA — 11 boot: wiring, connectivity bar, keyboard shortcuts, file inputs
   ========================================================================== */

function renderNetbar() {
  const b = $('#netbar'); if (!b) return;
  if (NET.state === 'offline' || !navigator.onLine) {
    b.hidden = false; b.className = 'netbar off';
    b.innerHTML = `${ic('wifi-off')}<span>You’re offline. Playlists, likes and music on your device still work.</span>`;
  } else if (NET.state === 'fail') {
    b.hidden = false; b.className = 'netbar warn';
    b.innerHTML = `${ic('alert')}<span>Can’t reach ${esc([...NET.failed].join(', '))}. Check your connection. If you opened SONORA in a restricted preview, online music may be blocked there.</span><button type="button" class="link-btn" data-act="netRetry">Retry</button>`;
  } else { b.hidden = true; b.innerHTML = ''; }
}
ACT.netRetry = () => { CACHE.clear(); NET.failed.clear(); NET.state = 'ok'; renderNetbar(); ACT.homeRefresh(); if (SS.q) runSearch(SS.q); };

function wireEvents() {
  const tickUI = throttle(() => { miniTime(); if ($('#np.in')) npTime(); }, 200);
  Bus.on('player:time', tickUI);
  Bus.on('player:track', () => {
    renderMini(); if (UI_STACK.some(i => i.kind === 'np')) npRender(); refreshRows();
    if (NAVS.built.home) renderContinue(tabEl('home'));
  });
  Bus.on('player:state', () => {
    miniState(); if ($('#np.in')) npState(); refreshRows();
    if (NAVS.built.home) renderContinue(tabEl('home'));
  });
  Bus.on('queue', () => { npTools(); refreshRows(); if ($('#np.in')) { const c = $('#np-ctx'); if (c) c.textContent = ctxLabel(); } });
  Bus.on('sleep', npTools); Bus.on('sleep:tick', npTools);
  Bus.on('eq', npTools);
  Bus.on('lib', k => {
    if (['liked', 'all'].includes(k)) refreshHearts();
    if (['playlists', 'liked', 'saved', 'followed', 'history', 'downloads', 'all'].includes(k)) markDirty('library');
    if (['history', 'all'].includes(k) && NAVS.built.home) renderRecent(tabEl('home'));
  });
  Bus.on('local', () => markDirty('library'));
  Bus.on('net', renderNetbar);
  Bus.on('pref', k => { if (['volume', 'muted', 'shuffle', 'repeat'].includes(k) && $('#np.in')) npState(); if (['theme', 'accent', 'dataSaver'].includes(k)) applyTheme(); });
  addEventListener('online', () => {
    renderNetbar();
    if (NAVS.built.home && $$('#tab-home .shelf.note').length) { ACT.homeRefresh(); }
  });
  addEventListener('offline', renderNetbar);

  $('#file-local').addEventListener('change', e => handleImport(e.target.files));
  $('#file-folder').addEventListener('change', e => handleImport(e.target.files));
  addEventListener('dragover', e => { if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) e.preventDefault(); });
  addEventListener('drop', e => { if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) { e.preventDefault(); handleImport(e.dataTransfer.files); } });
  wireNP();
}

/* ---------- keyboard shortcuts ---------- */
addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey || e.altKey) return;
  const tg = e.target, tag = tg && tg.tagName;
  const typing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (tg && tg.isContentEditable);
  if (e.key === 'Escape') {
    if (UI_STACK.length) { e.preventDefault(); popTop(false); }
    else if (typing) tg.blur();
    return;
  }
  if (typing) return;
  const onButton = tag === 'BUTTON' || tag === 'A' || (tg && tg.getAttribute && tg.getAttribute('role') === 'button');
  switch (e.key) {
    case ' ': if (onButton) return; e.preventDefault(); PL.toggle(); break;
    case 'ArrowLeft': e.preventDefault(); e.shiftKey ? PL.prev() : PL.seekRel(-5); break;
    case 'ArrowRight': e.preventDefault(); e.shiftKey ? PL.next() : PL.seekRel(5); break;
    case 'ArrowUp': e.preventDefault(); PL.setVolume(PREFS.volume + 0.05); break;
    case 'ArrowDown': e.preventDefault(); PL.setVolume(PREFS.volume - 0.05); break;
    case 'm': case 'M': PL.toggleMute(); break;
    case 'l': case 'L': ACT.npLike(); break;
    case 's': case 'S': ACT.shuffleToggle(); break;
    case 'r': case 'R': ACT.repeatToggle(); break;
    case 'n': case 'N': if (UI_STACK.some(i => i.kind === 'np')) closeNP(); else openNP(); break;
    case 'q': case 'Q': openQueue(); break;
    case '/': e.preventDefault(); showTab('search'); setTimeout(() => { const i = $('#search-input'); i && i.focus(); }, 30); break;
    case '?': ACT.openShortcuts(); break;
    default: return;
  }
});

function boot() {
  applyTheme();
  PL.init();
  wireEvents();
  renderNetbar();
  showTab('home');
  renderMini();
  loadLocalLibrary().then(() => { markDirty('library'); }).catch(() => { });
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => { });
  // test / debugging hook; contains no secrets
  window.SONORA = { H, PL, Q, PS, E, PREFS, LIB, Lib, LOCAL, NET, Audius, CACHE, UI_STACK, ACT, Sleep, UNAVAIL, LS, IDB, setPref, showTab, go, importFiles, parseLyrics, readMeta, TR };
}
try { boot(); } catch (e) {
  console.error('[boot]', e);
  const v = $('#views'); if (v) v.innerHTML = `<div class="empty" style="padding:40px 20px"><h3>SONORA couldn’t start</h3><p>${esc(e && e.message)}</p></div>`;
}
