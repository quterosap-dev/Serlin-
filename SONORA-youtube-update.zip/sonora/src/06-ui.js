/* ==========================================================================
   SONORA — 06 ui core: artwork, entity registry, overlay/back stack, sheets,
   dialogs, reusable components, drag-to-reorder, action dispatcher
   ========================================================================== */

/* ---------- artwork ---------- */
function artUrl(it, size = 'md') {
  if (!it) return '';
  const sm = it.art150 || it.img150 || '', md = it.art480 || it.img480 || '', lg = it.art1000 || it.art480 || it.img480 || '';
  if (PREFS.dataSaver) return sm || md;
  if (size === 'sm') return sm || md;
  if (size === 'lg') return lg || md;
  return md || sm;
}
function initialOf(it) { return ((it && (it.title || it.name)) || '♪').trim().charAt(0).toUpperCase(); }
function artEl(it, size = 'md', cls = '') {
  const seed = (it && (it.id || it.name || it.title)) || 'x', url = artUrl(it, size);
  return `<div class="art ${cls}" style="background:${gradFor(seed)}"><span class="art-ch" aria-hidden="true">${esc(initialOf(it))}</span>${url ? `<img class="artimg" src="${esc(url)}" alt="" loading="lazy" decoding="async">` : ''}</div>`;
}
/* user playlists show their cover, or a 2x2 collage of their tracks, or a gradient */
function plArt(p, cls = '') {
  if (p.cover) return `<div class="art ${cls}" style="background:${gradFor(p.id)}"><img class="artimg" src="${esc(p.cover)}" alt=""></div>`;
  const arts = uniqBy(p.tracks.map(t => artUrl(t, 'sm')).filter(Boolean), x => x).slice(0, 4);
  if (arts.length >= 4) return `<div class="art collage ${cls}" style="background:${gradFor(p.id)}">${arts.map(u => `<img class="artimg" src="${esc(u)}" alt="" loading="lazy">`).join('')}</div>`;
  if (arts.length) return `<div class="art ${cls}" style="background:${gradFor(p.id)}"><img class="artimg" src="${esc(arts[0])}" alt="" loading="lazy"></div>`;
  return `<div class="art ${cls}" style="background:${gradFor(p.id)}"><span class="art-ch">${ic('music')}</span></div>`;
}
document.addEventListener('error', e => { const t = e.target; if (t && t.tagName === 'IMG' && t.classList.contains('artimg')) t.classList.add('err'); }, true);

/* ---------- registries ---------- */
const ENT = new Map();      // id -> list / artist / mix entity, so cards can reopen them
const rememberEnt = e => { if (e && e.id) ENT.set(e.id, e); return e; };
const LISTS = new Map(); let listSeq = 0;
function regList(tracks, ctx) {
  const k = 'L' + (++listSeq);
  LISTS.set(k, { tracks, ctx });
  if (LISTS.size > 80) LISTS.delete(LISTS.keys().next().value);
  return k;
}
const trackOf = el => TR.get(el.dataset.tid);
/* tracks restored from storage aren't in the registry yet; register without overriding fresher copies */
function ensureTrack(t) { if (t && t.id && !TR.has(t.id)) TR.set(t.id, t); return t; }

/* ---------- overlay / back stack (Android back button, Esc, history) ---------- */
const UI_STACK = [];
/* History is kept in step with UI_STACK through a small serial queue. history.go() is asynchronous, so a
   close-then-open (menu item that closes its sheet and opens another) must not interleave pushState with a
   pending go(-1); that used to leave the history one entry short and the next "back" left the app.
   Each go() waits for its popstate; depth is clamped so we never go back past the app's own entries. */
const H = { depth: 0, q: [], busy: false, timer: null, ok: true };
function hRun() {
  if (H.busy) return;
  const op = H.q.shift(); if (!op) return;
  if (!H.ok) { hRun(); return; }
  if (op.t === 'push') { try { history.pushState({ sn: 1 }, ''); H.depth++; } catch { H.ok = false; } hRun(); return; }
  const n = Math.max(op.n, -H.depth);
  if (!n) { hRun(); return; }
  H.busy = true; H.depth += n;
  H.timer = setTimeout(hDone, 800);              // popstate never arrived: carry on anyway
  try { history.go(n); } catch { hDone(); }
}
function hDone() { clearTimeout(H.timer); H.busy = false; hRun(); }
function histPush() { H.q.push({ t: 'push' }); hRun(); }
function histGo(n) { if (n) { H.q.push({ t: 'go', n }); hRun(); } }
function pushUI(item) { UI_STACK.push(item); histPush(); syncViews(); return item; }
function popTop(fromHistory) {
  const it = UI_STACK.pop();
  if (!it) return false;
  try { it.close(); } catch (e) { console.error(e); }
  if (!fromHistory) histGo(-1);
  syncViews();
  return true;
}
function unwindAll() {
  const n = UI_STACK.length;
  while (UI_STACK.length) { const it = UI_STACK.pop(); try { it.close(); } catch (e) { console.error(e); } }
  if (n) histGo(-n);
  syncViews();
}
function unwindToView() {            // close sheets / Now Playing, keep pushed views
  while (UI_STACK.length && UI_STACK[UI_STACK.length - 1].kind !== 'view') popTop(false);
}
addEventListener('popstate', () => {
  if (H.busy) { hDone(); return; }               // the traversal we asked for
  H.depth = Math.max(0, H.depth - 1);            // the user (or Android back) went back one entry
  popTop(true);
});

/* ---------- views: persistent tab containers + pushed detail views ---------- */
const NAVS = { tab: 'home', built: {}, dirty: {} };
const TAB_BUILDERS = {};   // filled in by 07-views.js

function tabEl(name) { return $('#tab-' + name); }
function topViewEl() {
  for (let i = UI_STACK.length - 1; i >= 0; i--) if (UI_STACK[i].kind === 'view') return UI_STACK[i].el;
  return tabEl(NAVS.tab);
}
function syncViews() {
  const top = topViewEl();
  $$('#views > .view').forEach(v => {
    const show = v === top;
    if (!show && !v.hidden) v.dataset.sy = v.scrollTop;
    if (v.hidden !== !show) {
      v.hidden = !show;
      if (show) { const y = +v.dataset.sy || 0; requestAnimationFrame(() => { v.scrollTop = y; }); }
    }
  });
  $$('.nav-btn').forEach(b => { const on = b.dataset.tab === NAVS.tab; b.classList.toggle('on', on); b.setAttribute('aria-current', on ? 'page' : 'false'); });
  document.body.classList.toggle('np-open', UI_STACK.some(i => i.kind === 'np'));
}
function showTab(name) {
  if (UI_STACK.length) unwindAll();
  const same = NAVS.tab === name;
  NAVS.tab = name;
  const el = tabEl(name);
  if (!NAVS.built[name]) { NAVS.built[name] = true; TAB_BUILDERS[name](el); }
  else if (NAVS.dirty[name]) { NAVS.dirty[name] = false; const y = el.scrollTop; TAB_BUILDERS[name](el); el.scrollTop = y; }
  else if (same) { el.scrollTo({ top: 0, behavior: 'smooth' }); }
  syncViews();
  if (name === 'search' && same) { const i = $('#search-input'); i && i.focus(); }
}
function markDirty(name) {
  NAVS.dirty[name] = true;
  if (NAVS.tab === name && !UI_STACK.some(i => i.kind === 'view')) { NAVS.dirty[name] = false; const el = tabEl(name), y = el.scrollTop; TAB_BUILDERS[name](el); el.scrollTop = y; }
}
/* push a detail view (playlist, artist, category, settings...) */
function go(name, args = {}) {
  const el = document.createElement('div');
  el.className = 'view pushed'; el.dataset.view = name;
  $('#views').appendChild(el);
  const item = { kind: 'view', el, name, args, close() { el.remove(); } };
  pushUI(item);
  const b = VIEW_BUILDERS[name];
  if (!b) { el.innerHTML = emptyState({ icon: 'info', title: 'Page not found', text: name }); return el; }
  b(el, args);
  return el;
}
const VIEW_BUILDERS = {};   // filled in by 07-views.js
/* subscribe to bus events for as long as a view's element is attached */
function watch(el, evt, fn) {
  const off = Bus.on(evt, (...a) => { if (!el.isConnected) { off(); return; } fn(...a); });
}

/* ---------- toasts for storage problems ---------- */
Bus.on('storage-error', () => toast('Your device storage is full or blocked, so recent changes may not be saved.', { kind: 'warn', ms: 6000 }));

/* ---------- sheets & dialogs ---------- */
const Sheet = {
  open({ title = '', html = '', cls = '', onMount, onClose } = {}) {
    const wrap = document.createElement('div');
    wrap.className = 'sheet-wrap';
    wrap.innerHTML = `<div class="scrim" data-act="sheetClose"></div>
      <div class="sheet ${cls}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="sheet-grab"></div>
        ${title ? `<div class="sheet-head"><h3>${esc(title)}</h3><button class="icon-btn" data-act="sheetClose" type="button" aria-label="Close">${ic('x')}</button></div>` : ''}
        <div class="sheet-body">${html}</div>
      </div>`;
    $('#overlays').appendChild(wrap);
    requestAnimationFrame(() => wrap.classList.add('in'));
    const item = { kind: 'sheet', el: wrap, close() { wrap.classList.remove('in'); setTimeout(() => wrap.remove(), 230); onClose && onClose(); } };
    pushUI(item);
    onMount && onMount($('.sheet-body', wrap), wrap);
    return item;
  }
};
function closeTopSheet() { if (UI_STACK.length && UI_STACK[UI_STACK.length - 1].kind === 'sheet') popTop(false); }

function menuItems(items) {
  return `<div class="menu">${items.filter(Boolean).map(i => `
    <button type="button" class="menu-item ${i.danger ? 'danger' : ''}" ${i.disabled ? 'disabled' : ''} data-act="${i.act}" ${i.close === false ? '' : 'data-close'}
      ${Object.entries(i.data || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>
      ${ic(i.icon || 'chevron-right')}<span>${esc(i.label)}</span>${i.hint ? `<small>${esc(i.hint)}</small>` : ''}
    </button>`).join('')}</div>`;
}

function askText({ title, label = '', value = '', placeholder = '', okLabel = 'Save', multiline = false, extra = '', onMount } = {}) {
  return new Promise(resolve => {
    let settled = false;
    const done = v => { if (!settled) { settled = true; resolve(v); } };
    Sheet.open({
      title, cls: 'dialog',
      html: `<form class="form" id="ask-form">
        ${label ? `<label class="field-label" for="ask-input">${esc(label)}</label>` : ''}
        ${multiline ? `<textarea id="ask-input" class="field" rows="4" placeholder="${esc(placeholder)}">${esc(value)}</textarea>`
          : `<input id="ask-input" class="field" type="text" autocomplete="off" maxlength="120" value="${esc(value)}" placeholder="${esc(placeholder)}">`}
        ${extra}
        <div class="form-actions"><button type="button" class="btn ghost" data-act="sheetClose">Cancel</button><button type="submit" class="btn primary">${esc(okLabel)}</button></div>
      </form>`,
      onMount: (body, wrap) => {
        const input = $('#ask-input', body);
        setTimeout(() => { input.focus(); input.select && input.select(); }, 60);
        $('#ask-form', body).addEventListener('submit', e => { e.preventDefault(); const v = input.value; done({ value: v, root: body }); popTop(false); });
        onMount && onMount(body);
      },
      onClose: () => done(null)
    });
  });
}
function askConfirm({ title, text = '', okLabel = 'Confirm', danger = false } = {}) {
  return new Promise(resolve => {
    let settled = false;
    const done = v => { if (!settled) { settled = true; resolve(v); } };
    Sheet.open({
      title, cls: 'dialog',
      html: `<p class="muted dialog-text">${esc(text)}</p>
        <div class="form-actions"><button type="button" class="btn ghost" data-act="sheetClose">Cancel</button>
        <button type="button" class="btn ${danger ? 'danger' : 'primary'}" id="confirm-ok">${esc(okLabel)}</button></div>`,
      onMount: body => { $('#confirm-ok', body).addEventListener('click', () => { done(true); popTop(false); }); },
      onClose: () => done(false)
    });
  });
}

/* ---------- reusable components ---------- */
function emptyState({ icon = 'music', title, text = '', action } = {}) {
  return `<div class="empty">${ic(icon, 'empty-ic')}<h3>${esc(title)}</h3>${text ? `<p>${esc(text)}</p>` : ''}${action ? `<button type="button" class="btn primary" data-act="${action.act}" ${Object.entries(action.data || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>${esc(action.label)}</button>` : ''}</div>`;
}
function errorState(err, retry) {
  const kind = err && err.kind;
  const title = kind === 'offline' ? 'You\'re offline' : kind === 'network' ? 'Can\'t reach the music service' : 'Couldn\'t load this';
  const text = kind === 'network'
    ? 'The request was blocked or the service is down. If you opened SONORA inside a restricted preview, network access to music services may be disabled there.'
    : errMsg(err);
  return `<div class="empty compact">${ic(kind === 'offline' ? 'wifi-off' : 'alert', 'empty-ic')}<h3>${esc(title)}</h3><p>${esc(text)}</p>${retry ? `<button type="button" class="btn ghost" data-act="${retry.act}" ${Object.entries(retry.data || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>${ic('refresh')} Try again</button>` : ''}</div>`;
}
function skelCards(n = 6, round = false) {
  return Array.from({ length: n }, () => `<div class="card skel"><div class="art ${round ? 'round' : ''} sk"></div><div class="sk line"></div><div class="sk line short"></div></div>`).join('');
}
function skelRows(n = 6) {
  return Array.from({ length: n }, () => `<div class="row skel"><div class="art row-art sk"></div><div class="row-main"><div class="sk line"></div><div class="sk line short"></div></div></div>`).join('');
}

const srcBadge = t => (providerCount() > 1 && t.src !== 'local' ? `<span class="badge">${t.src === 'audius' ? 'Audius' : t.src === 'jamendo' ? 'Jamendo' : 'IA'}</span>` : (t.src === 'local' ? '<span class="badge local">Device</span>' : ''));

function trackRow(t, o = {}) {
  ensureTrack(t);
  const cur = curTrack(), isCur = cur && cur.id === t.id;
  const un = isUnavail(t);
  return `<div class="row ${isCur ? 'is-current' : ''} ${isCur && PS.playing ? 'is-playing' : ''} ${un ? 'is-unavail' : ''}" data-act="playRow" data-list="${o.list || ''}" data-i="${o.i ?? 0}" data-tid="${esc(t.id)}" ${o.plid ? `data-plid="${esc(o.plid)}"` : ''} role="button" tabindex="0">
    ${o.num ? `<span class="row-num">${o.num}</span>` : ''}
    ${o.grip ? `<button class="row-grip" type="button" data-grip aria-label="Drag to reorder">${ic('grip')}</button>` : ''}
    <div class="row-art-wrap">${artEl(t, 'sm', 'row-art')}<span class="eqbars" aria-hidden="true"><i></i><i></i><i></i></span></div>
    <div class="row-main">
      <div class="row-title">${esc(t.title)}</div>
      <div class="row-sub">${srcBadge(t)}${un ? '<span class="badge warn">Unavailable</span>' : ''}<span>${esc(t.artist)}${t.album ? ' · ' + esc(t.album) : ''}</span></div>
    </div>
    <span class="row-dur">${t.dur ? fmtTime(t.dur) : ''}</span>
    <button class="icon-btn row-like ${Lib.isLiked(t) ? 'on' : ''}" type="button" data-act="like" data-tid="${esc(t.id)}" aria-label="Like" aria-pressed="${Lib.isLiked(t)}">${ic('heart')}</button>
    <button class="icon-btn" type="button" data-act="trackMenu" data-tid="${esc(t.id)}" data-list="${o.list || ''}" data-i="${o.i ?? 0}" ${o.plid ? `data-plid="${esc(o.plid)}"` : ''} aria-label="More options for ${esc(t.title)}">${ic('more')}</button>
  </div>`;
}
function trackRows(tracks, ctx, o = {}) {
  const key = regList(tracks, ctx);
  return `<div class="rows" data-list="${key}">${tracks.map((t, i) => trackRow(t, { ...o, list: key, i, num: o.numbered ? i + 1 : 0 })).join('')}</div>`;
}

function trackCard(t, key, i) {
  ensureTrack(t);
  const isCur = curTrack() && curTrack().id === t.id;
  return `<div class="card ${isCur ? 'is-current' : ''}" data-act="playCard" data-list="${key}" data-i="${i}" data-tid="${esc(t.id)}" role="button" tabindex="0" aria-label="Play ${esc(t.title)} by ${esc(t.artist)}">
    <div class="card-art">${artEl(t, 'md')}<span class="card-play">${ic('play')}</span>
      <button class="card-more" type="button" data-act="trackMenu" data-tid="${esc(t.id)}" data-list="${key}" data-i="${i}" aria-label="More options for ${esc(t.title)}">${ic('more')}</button></div>
    <div class="card-title">${esc(t.title)}</div><div class="card-sub">${esc(t.artist)}</div></div>`;
}
function listCard(l) {
  rememberEnt(l);
  const art = l.kind === 'mix' ? mixArt(l) : (l.cover !== undefined ? plArt(l) : artEl(l, 'md'));
  return `<div class="card" data-act="openEntity" data-eid="${esc(l.id)}" role="button" tabindex="0" aria-label="Open ${esc(l.name)}">
    <div class="card-art">${art}<span class="card-play">${ic('play')}</span></div>
    <div class="card-title">${esc(l.name)}</div>
    <div class="card-sub">${l.kind === 'album' ? 'Album' : l.kind === 'mix' ? esc(l.desc || 'Made for you') : 'Playlist'}${l.artist ? ' · ' + esc(l.artist) : ''}</div></div>`;
}
function artistCard(a) {
  rememberEnt(a);
  return `<div class="card artist" data-act="openEntity" data-eid="${esc(a.id)}" role="button" tabindex="0" aria-label="Open artist ${esc(a.name)}">
    <div class="card-art">${artEl({ id: a.id, name: a.name, img150: a.img150, img480: a.img480 }, 'md', 'round')}</div>
    <div class="card-title">${esc(a.name)}</div><div class="card-sub">Artist${a.followers ? ' · ' + fmtNum(a.followers) + ' followers' : ''}</div></div>`;
}
function mixArt(m) {
  const arts = uniqBy(m.tracks.map(t => artUrl(t, 'sm')).filter(Boolean), x => x).slice(0, 4);
  const g = `background:linear-gradient(145deg,hsl(${hueOf(m.id)} 70% 45%),hsl(${(hueOf(m.id) + 60) % 360} 70% 22%))`;
  return `<div class="art mix ${arts.length >= 4 ? 'collage' : ''}" style="${g}">${arts.length >= 4 ? arts.map(u => `<img class="artimg" src="${esc(u)}" alt="" loading="lazy">`).join('') : ''}<span class="mix-label">${esc(m.name)}</span></div>`;
}

function sectionHead(title, sub, extra = '') {
  return `<div class="sec-head"><div><h2>${esc(title)}</h2>${sub ? `<p class="sec-sub">${esc(sub)}</p>` : ''}</div>${extra}</div>`;
}
function shelfSection(id, title, sub, extra) {
  return `<section class="sec" id="sh-${id}">${sectionHead(title, sub, extra)}<div class="shelf" data-shelf="${id}">${skelCards(6)}</div></section>`;
}
/* loads a shelf; never throws. render(items) -> html. opts.hideIfEmpty, opts.emptyText */
async function fillShelf(root, id, loader, render, opts = {}) {
  const sec = $(`#sh-${id}`, root);
  if (!sec) return;
  const box = $('.shelf', sec);
  box.innerHTML = skelCards(6, !!opts.round);
  SHELF_LOADERS.set(`${id}`, () => fillShelf(root, id, loader, render, opts));
  try {
    const items = await loader();
    if (!root.isConnected) return;
    if (!items || !items.length) {
      if (opts.hideIfEmpty) { sec.remove(); return; }
      box.innerHTML = `<div class="shelf-note">${esc(opts.emptyText || 'Nothing to show yet.')}</div>`; box.classList.add('note'); return;
    }
    box.classList.remove('note');
    box.innerHTML = render(items);
  } catch (e) {
    if (!root.isConnected || (e && e.kind === 'abort')) return;
    box.classList.add('note');
    box.innerHTML = errorState(e, { act: 'retryShelf', data: { shelf: id } });
  }
}
const SHELF_LOADERS = new Map();

/* ---------- drag-to-reorder (pointer events, touch friendly) ---------- */
function makeSortable(container, onMove, rowSel = '.row') {
  container.addEventListener('pointerdown', e => {
    const grip = e.target.closest('[data-grip]');
    if (!grip) return;
    const row = grip.closest(rowSel);
    if (!row) return;
    e.preventDefault();
    const rows = Array.from(container.querySelectorAll(rowSel)), from = rows.indexOf(row);
    const rects = rows.map(r => r.getBoundingClientRect()), startY = e.clientY;
    let to = from;
    row.classList.add('dragging'); container.classList.add('is-dragging');
    try { grip.setPointerCapture(e.pointerId); } catch { /* ignore */ }
    const mv = ev => {
      const dy = ev.clientY - startY;
      row.style.transform = `translateY(${dy}px)`;
      const center = rects[from].top + rects[from].height / 2 + dy;
      to = rects.findIndex(r => center < r.top + r.height);
      if (to < 0) to = rects.length - 1;
      rows.forEach((r, i) => {
        if (i === from) return;
        let sh = 0;
        if (from < to && i > from && i <= to) sh = -rects[from].height;
        if (from > to && i >= to && i < from) sh = rects[from].height;
        r.style.transform = sh ? `translateY(${sh}px)` : '';
      });
    };
    const up = () => {
      grip.removeEventListener('pointermove', mv); grip.removeEventListener('pointerup', up); grip.removeEventListener('pointercancel', up);
      rows.forEach(r => { r.style.transform = ''; });
      row.classList.remove('dragging');
      setTimeout(() => container.classList.remove('is-dragging'), 0);
      if (to !== from) onMove(from, to);
    };
    grip.addEventListener('pointermove', mv); grip.addEventListener('pointerup', up); grip.addEventListener('pointercancel', up);
  });
}

/* ---------- action dispatcher ---------- */
const ACT = {};
document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  if (el.closest('.is-dragging')) return;
  const fn = ACT[el.dataset.act];
  if (!fn) { console.warn('[ui] no handler for', el.dataset.act); return; }
  e.preventDefault();
  if (el.hasAttribute('data-close')) closeTopSheet();
  Promise.resolve().then(() => fn(el, e)).catch(err => { console.error(err); toast(errMsg(err), { kind: 'warn' }); });
});
/* rows/cards are role=button: Enter and Space activate them */
document.addEventListener('keydown', e => {
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('.row[role=button], .card[role=button]')) {
    e.preventDefault(); e.target.click();
  }
});
