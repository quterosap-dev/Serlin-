/* ==========================================================================
   SONORA — 01 storage: localStorage (prefs + library) and IndexedDB (audio blobs)
   Cloud-sync readiness: every record carries id + updatedAt, deletions are kept
   as tombstones, and all writes go through saveLib(), which calls Sync.push().
   ========================================================================== */

/* ---------- localStorage wrapper with in-memory fallback ---------- */
const memStore = {};
let lsOK = true;
try { localStorage.setItem('sonora.__t', '1'); localStorage.removeItem('sonora.__t'); } catch { lsOK = false; }
const LS = {
  ok: lsOK,
  frozen: false,            // set while wiping: nothing may be written back (pagehide handlers would undo the wipe)
  get(k, d) {
    try {
      const raw = lsOK ? localStorage.getItem('sonora.' + k) : memStore[k];
      return raw == null ? d : JSON.parse(raw);
    } catch { return d; }
  },
  set(k, v) {
    if (this.frozen) return false;
    try {
      const s = JSON.stringify(v);
      if (lsOK) localStorage.setItem('sonora.' + k, s); else memStore[k] = s;
      return true;
    } catch (e) { Bus.emit('storage-error', e); return false; }
  },
  del(k) { try { if (lsOK) localStorage.removeItem('sonora.' + k); else delete memStore[k]; } catch { /* ignore */ } },
  clearAll() {
    this.frozen = true;
    Object.keys(memStore).forEach(k => delete memStore[k]);
    try { Object.keys(localStorage).filter(k => k.startsWith('sonora.')).forEach(k => localStorage.removeItem(k)); } catch { /* ignore */ }
  }
};

/* ---------- IndexedDB wrapper (files, meta, offline) ---------- */
const IDB = {
  ok: true, _p: null,
  open() {
    if (this._p) return this._p;
    this._p = new Promise(res => {
      try {
        const r = indexedDB.open('sonora', 1);
        r.onupgradeneeded = () => { ['files', 'meta', 'offline'].forEach(s => r.result.createObjectStore(s)); };
        r.onsuccess = () => res(r.result);
        r.onerror = () => { this.ok = false; res(null); };
        r.onblocked = () => { this.ok = false; res(null); };
      } catch { this.ok = false; res(null); }
    });
    return this._p;
  },
  async tx(store, mode, fn) {
    const db = await this.open();
    if (!db) throw new Error('Device storage (IndexedDB) is not available here.');
    return new Promise((res, rej) => {
      const t = db.transaction(store, mode);
      let out;
      const req = fn(t.objectStore(store));
      if (req) req.onsuccess = () => { out = req.result; };
      t.oncomplete = () => res(out);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error || new Error('Storage write was aborted (quota?)'));
    });
  },
  get(s, k) { return this.tx(s, 'readonly', o => o.get(k)); },
  put(s, k, v) { return this.tx(s, 'readwrite', o => o.put(v, k)); },
  del(s, k) { return this.tx(s, 'readwrite', o => o.delete(k)); },
  all(s) { return this.tx(s, 'readonly', o => o.getAll()); },
  keys(s) { return this.tx(s, 'readonly', o => o.getAllKeys()); },
  clear(s) { return this.tx(s, 'readwrite', o => o.clear()); }
};

/* ---------- preferences ---------- */
const PREF_DEFAULTS = {
  theme: 'dark', accent: 'ember',
  dataSaver: false, crossfade: 0, autoSkip: true,
  rememberLocal: true,
  audiusHost: 'https://api.audius.co', audiusKey: '',
  useJamendo: false, jamendoId: '', useArchive: false,
  volume: 0.9, muted: false, speed: 1,
  eq: { on: false, preset: 'flat', gains: [0, 0, 0, 0, 0] },
  shuffle: false, repeat: 'off'
};
const PREFS = Object.assign({}, PREF_DEFAULTS, LS.get('prefs', {}));
PREFS.eq = Object.assign({}, PREF_DEFAULTS.eq, PREFS.eq || {});
function setPref(k, v) {
  PREFS[k] = v;
  LS.set('prefs', PREFS);
  Bus.emit('pref', k, v);
}
function applyTheme() {
  const root = document.documentElement;
  if (PREFS.theme === 'system') root.removeAttribute('data-theme'); else root.setAttribute('data-theme', PREFS.theme);
  root.setAttribute('data-accent', PREFS.accent);
  root.toggleAttribute('data-saver', !!PREFS.dataSaver);
  const m = document.querySelector('meta[name="theme-color"]');
  if (m) m.setAttribute('content', getComputedStyle(root).getPropertyValue('--bg').trim() || '#0e0f12');
}

/* ---------- library ---------- */
const LIB_DEFAULTS = () => ({
  v: 1,
  liked: [],            // [{t: track, at}]
  playlists: [],        // [{id,name,desc,cover,tracks:[track],created,updatedAt}]
  savedLists: [],       // saved Audius playlists / albums [{id,kind,name,art,artist,count,at,...}]
  followed: [],         // [{id,name,handle,img,at}]
  history: [],          // [{t: track, at}]
  searches: [],         // ['query', ...]
  recentItems: [],      // [{type, data, at}]
  stats: { seconds: 0, plays: 0, byDay: {}, artists: {}, genres: {} },
  lyrics: {},           // {trackId: 'text or LRC'}
  downloads: [],        // [track] saved for offline use
  tombstones: []        // [{type,id,at}] for future sync
});
const LIB = Object.assign(LIB_DEFAULTS(), LS.get('lib', {}));
LIB.stats = Object.assign(LIB_DEFAULTS().stats, LIB.stats || {});

/* A future backend only needs to implement push(changes)/pull(). Nothing is sent anywhere today. */
const Sync = { adapter: null, push() { if (this.adapter) this.adapter.push(LIB); } };

const saveLibNow = () => { const ok = LS.set('lib', LIB); if (ok) Sync.push(); return ok; };
const saveLib = debounce(saveLibNow, 250);
addEventListener('pagehide', () => { saveLibNow(); });
addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveLibNow(); });

/* only the fields we need are persisted for a track */
function slim(t) {
  if (!t) return t;
  const o = {};
  for (const k of ['id', 'src', 'rid', 'title', 'artist', 'artistId', 'handle', 'album', 'dur', 'art150', 'art480', 'art1000', 'genre', 'mood',
    'perm', 'dl', 'stream', 'plays', 'rel', 'audio', 'license', 'alt', 'localKey', 'lyr', 'year', 'no', 'uimg', 'uimg150', 'ufol', 'size', 'addedAt']) if (t[k] !== undefined && t[k] !== null && t[k] !== '') o[k] = t[k];
  return o;
}

/* ---------- track registry (id -> latest known object) ---------- */
const TR = new Map();
function rememberTrack(t) { if (t && t.id) TR.set(t.id, t); return t; }
function rememberTracks(list) { list.forEach(rememberTrack); return list; }
