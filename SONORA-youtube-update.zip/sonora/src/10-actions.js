/* ==========================================================================
   SONORA — 10 actions: every data-act handler, track details sheet, shortcuts
   ========================================================================== */

/* ---------- helpers ---------- */
function artistEntityFromTrack(t) {
  if (!t || !t.artistId) return null;
  return rememberEnt({ id: t.artistId, rid: String(t.artistId).slice(3), src: t.src, name: t.artist, handle: t.handle || '', img480: t.uimg || '', img150: t.uimg150 || '', followers: t.ufol || 0 });
}
function openArtistOf(t) {
  const a = ENT.get(t.artistId) || artistEntityFromTrack(t);
  if (!a) { toast('No artist page for this song.'); return; }
  unwindToView();
  go('artist', { id: a.id });
}
function slimList(e) {
  return { id: e.id, rid: e.rid, src: e.src, kind: e.kind, name: e.name, art150: e.art150, art480: e.art480, artist: e.artist, artistId: e.artistId, count: e.count, desc: e.desc, perm: e.perm };
}
function playFromEl(el, { shuffle = false } = {}) {
  const t = trackOf(el); if (!t) return;
  const L = LISTS.get(el.dataset.list);
  if (el.closest('#tab-search')) { Lib.addSearch(SS.q); Lib.addRecentItem('track', slim(t)); }
  const cur = curTrack();
  if (cur && cur.id === t.id && !PS.error && Q.list.length) { PL.toggle(); return; }
  if (isUnavail(t)) { toast('This track isn’t available for streaming.', { kind: 'warn' }); return; }
  if (L) PL.play(L.tracks, +el.dataset.i || 0, L.ctx, { shuffle }); else PL.playTrack(t);
}
async function setEq(on) {
  if (on) { const ok = await E.enableEQ(); if (!ok) return; PREFS.eq.on = true; }
  else { E.disableEQ(); PREFS.eq.on = false; }
  setPref('eq', PREFS.eq); Bus.emit('eq'); npTools();
}
async function handleImport(files) {
  if (!files || !files.length) return;
  const t = toast(`Reading ${plural(files.length, 'file')}…`, { ms: 60000 });
  const r = await importFiles(files, { onProgress: (i, n, name) => { if (t) { const m = t.querySelector('.toast-msg'); if (m) m.textContent = `Adding ${i} of ${n}: ${name}`; } } });
  if (t) t.remove();
  const bits = [];
  if (r.added.length) bits.push(`Added ${plural(r.added.length, 'song')}`);
  if (r.dupes) bits.push(`${r.dupes} already in your library`);
  if (r.failed.length) bits.push(`${r.failed.length} couldn’t be played by this browser (${r.failed.slice(0, 2).join(', ')}${r.failed.length > 2 ? '…' : ''})`);
  if (r.skipped) bits.push(`${r.skipped} not audio`);
  toast(bits.join('. ') + '.', { kind: r.added.length ? '' : 'warn', ms: 5200, action: r.added.length ? { label: 'Play', fn: () => PL.play(r.added, 0, { type: 'local', name: 'On this device' }) } : null });
  if (r.added.length) { LST.tab = 'local'; markDirty('library'); }
  const hasSess = r.added.some(x => x.session);
  if (hasSess && PREFS.rememberLocal) toast('These files couldn’t be saved to device storage, so they’ll be gone after you close SONORA.', { kind: 'warn', ms: 6000 });
}

/* ==========================================================================
   Track details + actions sheet
   ========================================================================== */
function openTrackSheet(t, { list = '', i = 0, plid = '' } = {}) {
  if (!t) return;
  rememberTrack(t);
  const liked = Lib.isLiked(t), isLocal = t.src === 'local', off = Offline.has(t.id);
  const srcName = isLocal ? 'On this device' : t.src === 'audius' ? 'Audius' : t.src === 'jamendo' ? 'Jamendo' : 'Internet Archive';
  const chips = [t.genre, t.dur ? fmtTime(t.dur) : '', t.plays ? fmtNum(t.plays) + ' plays' : '', srcName, t.license ? 'Creative Commons' : '', t.year || ''].filter(Boolean);
  const d = { tid: t.id, list, i };
  const items = [
    { icon: 'play', label: 'Play', act: 'menuPlay', data: d },
    { icon: 'next', label: 'Play next', act: 'menuNext', data: { tid: t.id } },
    { icon: 'list', label: 'Add to queue', act: 'menuQueue', data: { tid: t.id } },
    { icon: 'heart', label: liked ? 'Remove from Liked songs' : 'Add to Liked songs', act: 'like', data: { tid: t.id } },
    { icon: 'plus', label: 'Add to playlist…', act: 'menuAddPl', data: { tid: t.id } },
    plid ? { icon: 'trash', label: 'Remove from this playlist', act: 'menuRemovePl', data: { tid: t.id, plid, i } } : null,
    plid && i > 0 ? { icon: 'arrow-up', label: 'Move up', act: 'moveUp', data: { plid, i } } : null,
    plid && LISTS.get(list) && i < LISTS.get(list).tracks.length - 1 ? { icon: 'arrow-down', label: 'Move down', act: 'moveDown', data: { plid, i } } : null,
    t.artistId ? { icon: 'user', label: `Go to ${t.artist}`, act: 'goArtist', data: { tid: t.id } } : null,
    { icon: 'text', label: 'Lyrics', act: 'openLyrics', data: { tid: t.id } },
    !isLocal && t.dl && !off ? { icon: 'download', label: 'Save for offline', hint: 'Artist allows downloads', act: 'saveOffline', data: { tid: t.id } } : null,
    off ? { icon: 'trash', label: 'Remove offline copy', act: 'removeOffline', data: { tid: t.id } } : null,
    t.perm ? { icon: 'link', label: 'Copy link', act: 'copyLink', data: { tid: t.id } } : null,
    isLocal ? { icon: 'trash', label: 'Remove from this device library', danger: true, act: 'removeLocal', data: { tid: t.id } } : null
  ];
  Sheet.open({
    title: '', cls: 'track-sheet',
    html: `<div class="ts-head">${artEl(t, 'md', 'ts-art')}<div class="ts-text"><div class="ts-title">${esc(t.title)}</div><div class="ts-artist">${esc(t.artist)}${t.album ? ' · ' + esc(t.album) : ''}</div>
      <div class="ts-chips">${chips.map(c => `<span class="badge">${esc(c)}</span>`).join('')}</div></div></div>
      ${isUnavail(t) ? `<p class="notice-inline warn">${ic('alert')} This track isn’t available for streaming right now.</p>` : ''}
      ${menuItems(items)}
      ${t.perm ? `<p class="attrib"><a href="${esc(t.perm)}" target="_blank" rel="noopener">Open on ${esc(srcName)}</a>${t.license ? ` · <a href="${esc(t.license)}" target="_blank" rel="noopener">License</a>` : ''}</p>` : ''}`
  });
}

/* ==========================================================================
   Action handlers
   ========================================================================== */
Object.assign(ACT, {
  /* navigation */
  tab: el => showTab(el.dataset.tab),
  back: () => { popTop(false); },
  sheetClose: () => closeTopSheet(),
  openSettings: () => go('settings'),
  youtubePlayLink: () => {
    const raw = prompt('Paste a YouTube video link (youtube.com, youtu.be, or a video ID):');
    if (!raw) return;
    let id = '';
    const value = raw.trim();
    if (/^[a-zA-Z0-9_-]{11}$/.test(value)) id = value;
    else {
      try {
        const u = new URL(value);
        if (u.hostname === 'youtu.be' || u.hostname.endsWith('.youtu.be')) id = u.pathname.split('/').filter(Boolean)[0] || '';
        else if (u.hostname.includes('youtube.com')) id = u.searchParams.get('v') || (u.pathname.match(/\/(?:embed|shorts|live)\/([^/?]+)/) || [])[1] || '';
      } catch { /* invalid URL */ }
    }
    if (!/^[a-zA-Z0-9_-]{11}$/.test(id)) { toast('That doesn’t look like a valid YouTube video link.', { kind: 'warn' }); return; }
    Sheet.open({ title: 'YouTube playback', cls: 'tall youtube-player-sheet', html: `<p class="attrib">Playing through YouTube’s official embedded player. Some videos may not allow embedding.</p><div style="position:relative;width:100%;aspect-ratio:16/9;background:#000;border-radius:14px;overflow:hidden"><iframe title="YouTube video player" src="https://www.youtube-nocookie.com/embed/${id}?autoplay=1&playsinline=1&rel=0" style="position:absolute;inset:0;width:100%;height:100%;border:0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe></div><p class="attrib">YouTube controls playback. Background audio and lock-screen controls are not guaranteed for embedded videos.</p>` });
  },
  openStats: () => go('stats'),
  openCat: el => go('category', { cat: el.dataset.cat }),
  retryCat: el => { const v = el.closest('.view'); if (v && v._retry) v._retry(); },
  retryList: el => { const v = el.closest('.view'); if (v && v._reload) v._reload(); },
  retryArtist: el => { const v = el.closest('.view'); if (v && v._reload) v._reload(); },
  retryShelf: el => { const f = SHELF_LOADERS.get(el.dataset.shelf); if (f) f(); },
  openEntity: el => {
    const e = ENT.get(el.dataset.eid); if (!e) return;
    if (e.kind === 'userlist') return go('playlist', { id: e.id });
    if (['album', 'playlist', 'mix'].includes(e.kind)) return go('list', { id: e.id });
    return go('artist', { id: e.id });
  },
  openPlaylist: el => go('playlist', { id: el.dataset.id }),
  openArtistById: el => {
    const id = el.dataset.aid;
    const a = ENT.get(id) || rememberEnt({ id, rid: id.slice(3), src: id.startsWith('ja:') ? 'jamendo' : 'audius', name: el.dataset.name || 'Artist' });
    go('artist', { id: a.id });
  },
  openLibTab: el => { LST.tab = el.dataset.tab; LST.q = ''; NAVS.dirty.library = true; showTab('library'); },
  libTab: el => { LST.tab = el.dataset.tab; LST.q = ''; const f = $('#lib-filter'); if (f) f.value = ''; renderLibTabs(); renderLibBody(); },
  libSort: el => { LST.sort = el.dataset.sort; renderLibTabs(); renderLibBody(); },
  libAdd: () => Sheet.open({ title: 'Add to your library', cls: 'dialog', html: menuItems([
    { icon: 'plus', label: 'New playlist', act: 'plNew' },
    { icon: 'upload', label: 'Add music from this device', act: 'addLocal' },
    'webkitdirectory' in document.createElement('input') ? { icon: 'folder', label: 'Add a folder of music', act: 'addFolder' } : null,
    { icon: 'upload', label: 'Import a SONORA backup', act: 'importLib' }]) }),
  homeRefresh: () => { CACHE.clear(); const el = tabEl('home'), y = el.scrollTop; buildHome(el); el.scrollTop = y; toast('Refreshing…', { ms: 1200 }); },
  openNP: () => openNP(),
  closeNP: () => closeNP(),
  continue: () => {
    if (curTrack()) { PL.toggle(); return; }
    const h = LIB.history[0]; if (h) { rememberTrack(h.t); PL.playTrack(h.t, { type: 'history', name: 'Recently played' }); }
  },

  /* playback */
  playRow: el => playFromEl(el),
  playCard: el => playFromEl(el),
  playAll: el => { const L = LISTS.get(el.dataset.list); if (L && L.tracks.length) PL.play(L.tracks, 0, L.ctx); },
  shuffleAll: el => { const L = LISTS.get(el.dataset.list); if (L && L.tracks.length) PL.play(L.tracks, 0, L.ctx, { shuffle: true }); },
  toggle: () => PL.toggle(),
  next: () => PL.next(),
  prev: () => PL.prev(),
  shuffleToggle: () => { PL.toggleShuffle(); toast(PREFS.shuffle ? 'Shuffle on' : 'Shuffle off', { ms: 1400 }); },
  repeatToggle: () => { const r = PL.cycleRepeat(); toast({ off: 'Repeat off', all: 'Repeat all', one: 'Repeat this song' }[r], { ms: 1400 }); },
  npMute: () => PL.toggleMute(),
  npRetry: () => PL.resumePlayback(),
  npLike: () => { const t = curTrack(); if (t) { const on = Lib.toggleLike(t); toast(on ? 'Added to Liked songs' : 'Removed from Liked songs', { ms: 1600 }); refreshHearts(); } },
  miniLike: () => ACT.npLike(),
  npMenu: () => openTrackSheet(curTrack()),
  npArtist: () => { const t = curTrack(); if (t) openArtistOf(t); },
  npQueue: () => openQueue(),
  npAdd: () => { const t = curTrack(); if (t) openAddToPlaylist([t]); },
  npLyrics: () => openLyrics(),
  queueJump: el => PL.jump(+el.dataset.i),
  queueRemove: el => PL.removeFromQueue(+el.dataset.i),
  queueClear: () => { PL.clearUpcoming(); toast('Cleared upcoming songs.', { ms: 1500 }); },

  /* likes & track menu */
  like: el => { const t = trackOf(el); if (!t) return; const on = Lib.toggleLike(t); toast(on ? 'Added to Liked songs' : 'Removed from Liked songs', { ms: 1600 }); refreshHearts(); },
  trackMenu: el => openTrackSheet(trackOf(el), { list: el.dataset.list || '', i: +el.dataset.i || 0, plid: el.dataset.plid || '' }),
  menuPlay: el => { const t = trackOf(el), L = LISTS.get(el.dataset.list); if (isUnavail(t)) return toast('This track isn’t available for streaming.', { kind: 'warn' }); if (L) PL.play(L.tracks, +el.dataset.i || 0, L.ctx); else PL.playTrack(t); },
  menuNext: el => { PL.addNext(trackOf(el)); toast('Will play next', { ms: 1500 }); },
  menuQueue: el => { PL.addToQueue(trackOf(el)); toast('Added to queue', { ms: 1500 }); },
  menuAddPl: el => openAddToPlaylist([trackOf(el)]),
  menuRemovePl: el => { Lib.removeFromPlaylist(el.dataset.plid, +el.dataset.i); toast('Removed from playlist', { ms: 1500 }); },
  moveUp: el => Lib.moveInPlaylist(el.dataset.plid, +el.dataset.i, +el.dataset.i - 1),
  moveDown: el => Lib.moveInPlaylist(el.dataset.plid, +el.dataset.i, +el.dataset.i + 1),
  goArtist: el => { const t = trackOf(el); if (t) openArtistOf(t); },
  copyLink: async el => { const t = trackOf(el); toast((await copyText(t.perm)) ? 'Link copied' : 'Couldn’t copy the link. Long-press it to copy.', { ms: 1800 }); },
  saveOffline: async el => {
    const t = trackOf(el), n = toast(`Downloading “${t.title}”…`, { ms: 120000 });
    try { const size = await Offline.save(t, p => { const m = n && n.querySelector('.toast-msg'); if (m) m.textContent = `Downloading “${t.title}” ${Math.round(p * 100)}%`; }); if (n) n.remove(); toast(`Saved for offline (${fmtBytes(size)})`); }
    catch (e) { if (n) n.remove(); toast(errMsg(e), { kind: 'warn', ms: 6000 }); }
  },
  removeOffline: async el => { await Offline.remove(trackOf(el).id); toast('Offline copy removed', { ms: 1500 }); },
  removeLocal: async el => {
    const t = trackOf(el); if (!t) return;
    if (!(await askConfirm({ title: 'Remove this song?', text: `“${t.title}” will be removed from SONORA, including playlists and likes. The original file on your device isn’t touched.`, okLabel: 'Remove', danger: true }))) return;
    if (curTrack() && curTrack().id === t.id) { PL.pause(); const i = Q.idx; if (Q.list.length > 1) { Q.list.splice(i, 1); Q.idx = Math.min(i, Q.list.length - 1); E.load(curTrack(), { autoplay: false }); } else { Q.list = []; Q.idx = -1; E.quiet(() => { E.d.el.removeAttribute('src'); }); renderMini(); } Bus.emit('queue'); }
    await removeLocal(t.id); toast('Removed');
  },

  /* playlists */
  plNew: async () => {
    const r = await playlistDialog(); if (!r) return;
    const p = Lib.createPlaylist(r); toast(`Created “${p.name}”`, { ms: 1800 }); go('playlist', { id: p.id });
  },
  plEdit: async el => { const p = Lib.playlist(el.dataset.id); if (!p) return; const r = await playlistDialog(p); if (r) { Lib.updatePlaylist(p.id, r); toast('Saved', { ms: 1400 }); } },
  plMenu: el => {
    const p = Lib.playlist(el.dataset.id); if (!p) return;
    Sheet.open({ title: p.name, cls: 'dialog', html: menuItems([
      { icon: 'edit', label: 'Edit name, description and cover', act: 'plEdit', data: { id: p.id } },
      { icon: 'plus', label: 'Add songs', act: 'plAddSongs', data: { id: p.id } },
      { icon: 'trash', label: 'Delete playlist', danger: true, act: 'plDelete', data: { id: p.id } }]) });
  },
  plAddSongs: el => openAddSongs(el.dataset.id),
  plReorder: el => { const v = el.closest('.view'); if (v && v._toggleReorder) v._toggleReorder(); },
  plDelete: async el => {
    const p = Lib.playlist(el.dataset.id); if (!p) return;
    if (!(await askConfirm({ title: `Delete “${p.name}”?`, text: 'The playlist is removed from this device. The songs themselves aren’t affected.', okLabel: 'Delete', danger: true }))) return;
    Lib.deletePlaylist(p.id); toast('Playlist deleted', { ms: 1800 });
    const top = UI_STACK[UI_STACK.length - 1]; if (top && top.kind === 'view' && top.name === 'playlist') popTop(false);
  },
  addSongTo: el => { const t = trackOf(el); const r = Lib.addToPlaylist(el.dataset.plid, [t]); if (r.added) toast('Added', { ms: 1200 }); },
  addToPl: el => { const p = Lib.playlist(el.dataset.plid); const r = Lib.addToPlaylist(el.dataset.plid, PENDING_ADD); toast(r.added ? `Added ${plural(r.added, 'song')} to “${p.name}”` : 'Already in that playlist', { ms: 2000 }); },
  addToNewPl: async () => { const tracks = PENDING_ADD; const r = await playlistDialog(); if (!r) return; const p = Lib.createPlaylist(r, tracks); toast(`Added to “${p.name}”`, { ms: 2000 }); },
  saveList: el => { const e = ENT.get(el.dataset.eid) || LIB.savedLists.find(x => x.id === el.dataset.eid); if (!e) return; const on = Lib.toggleSavedList(slimList(e)); toast(on ? 'Saved to your library' : 'Removed from your library', { ms: 1600 }); },
  saveMix: el => { const e = ENT.get(el.dataset.eid); if (!e) return; const p = Lib.createPlaylist({ name: `${e.name} · ${e.genre}`, desc: 'Saved from a SONORA daily mix' }, e.tracks); toast('Saved as a playlist', { ms: 1800 }); go('playlist', { id: p.id }); },
  copyToPlaylist: el => { const L = LISTS.get(el.dataset.list); if (L) openAddToPlaylist(L.tracks); },
  followArtist: el => { const id = el.dataset.aid, a = ENT.get(id) || LIB.followed.find(x => x.id === id); if (!a) return; const on = Lib.toggleFollow(a); toast(on ? `Following ${a.name}` : `Unfollowed ${a.name}`, { ms: 1600 }); },

  /* search */
  searchClear: () => { setSearch(''); const i = $('#search-input'); if (i) i.focus(); },
  searchTab: el => { SS.tab = el.dataset.tab; renderSearchBody(); },
  searchSet: el => setSearch(el.dataset.q, true),
  searchRemove: el => Lib.removeSearch(el.dataset.q),
  searchClearHistory: () => { Lib.clearSearches(); toast('Search history cleared', { ms: 1500 }); },
  searchRetry: () => SS.q && runSearch(SS.q),

  /* local files */
  addLocal: () => { const i = $('#file-local'); i.value = ''; i.click(); },
  addFolder: () => { const i = $('#file-folder'); i.value = ''; i.click(); },

  /* lyrics */
  openLyrics: el => openLyrics(trackOf(el)),
  lyAttach: el => pickFile('.lrc,.txt,text/plain', async f => { const text = await f.text(); if (!text.trim()) return toast('That file is empty.', { kind: 'warn' }); Lib.setLyrics(el.dataset.tid, text); }),
  lyPaste: async el => { const r = await askText({ title: 'Paste lyrics', label: 'Plain text or LRC format', multiline: true, okLabel: 'Save' }); if (r && r.value.trim()) Lib.setLyrics(el.dataset.tid, r.value); },
  lyRemove: el => { const t = TR.get(el.dataset.tid); if (t && t.lyr) { LIB.lyrics[t.id] = ' '; Lib.touch('lyrics'); } else Lib.setLyrics(el.dataset.tid, ''); },

  /* sleep & sound */
  openSleep: () => openSleep(),
  sleepSet: el => {
    const m = el.dataset.m;
    if (m === 'off') { Sleep.cancel(); toast('Sleep timer off', { ms: 1500 }); }
    else if (m === 'track') { Sleep.set('track'); toast('Playback will stop after this track', { ms: 2000 }); }
    else { Sleep.set(+m); toast(`Sleep timer set for ${m} minutes`, { ms: 2000 }); }
    closeTopSheet(); npTools();
  },
  openSound: () => openSound(),
  setSpeed: el => PL.setSpeed(+el.dataset.val),
  eqPreset: async el => {
    const k = el.dataset.preset;
    PREFS.eq.preset = k; PREFS.eq.gains = EQ_PRESETS[k].slice(); E.setEqGains(PREFS.eq.gains); setPref('eq', PREFS.eq);
    if (!PREFS.eq.on && k !== 'flat') await setEq(true); else Bus.emit('eq');
  },
  togglePref: async el => {
    const k = el.dataset.pref;
    if (k === 'eqOn') { await setEq(!PREFS.eq.on); return; }
    const v = !PREFS[k]; setPref(k, v);
    if (k === 'dataSaver') { applyTheme(); if (v && PREFS.crossfade) toast('Crossfade is paused while Data saver is on.', { ms: 2500 }); }
    if (k === 'useJamendo' || k === 'useArchive') { CACHE.clear(); NAVS.built.home = false; if (k === 'useJamendo' && v && !PREFS.jamendoId) toast('Add your free Jamendo client ID below to switch it on.', { ms: 4000 }); }
  },
  setPref: el => {
    const k = el.dataset.pref, v = el.dataset.val;
    setPref(k, v); applyTheme();
  },

  /* data */
  exportLib: () => {
    const json = Lib.exportJSON();
    Sheet.open({ title: 'Export library', cls: 'tall', html: `<p class="muted">Copy this text or download it as a file. Local music files aren’t included. Only their entries in playlists.</p>
      <textarea id="export-text" class="field mono" rows="10" readonly aria-label="Library backup">${esc(json)}</textarea>
      <div class="form-actions"><button type="button" class="btn ghost" id="export-copy">${ic('link')} Copy</button><button type="button" class="btn primary" id="export-dl">${ic('download')} Download file</button></div>`,
      onMount: body => {
        $('#export-copy', body).addEventListener('click', async () => toast((await copyText(json)) ? 'Copied' : 'Couldn’t copy. Select the text and copy it.', { ms: 1800 }));
        $('#export-dl', body).addEventListener('click', async () => {
          // Inside the Claude artifact viewer a plain download link is blocked; the viewer offers its own save call instead.
          let viewerSave = null;
          try { viewerSave = window.claude && typeof window.claude.use === 'function' ? await window.claude.use('downloads') : null; } catch { viewerSave = null; }
          if (viewerSave) {
            try { await viewerSave.save({ filename: `sonora-backup-${dayKey()}.json`, data: json }); toast('Backup saved.', { ms: 2200 }); }
            catch (e) { if (!e || e.code !== 'declined') toast('Couldn’t save the file here. Use Copy instead.', { kind: 'warn' }); }
            return;
          }
          try { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' })); a.download = `sonora-backup-${dayKey()}.json`; document.body.appendChild(a); a.click(); a.remove(); toast('If nothing downloaded, use Copy instead.', { ms: 3000 }); }
          catch { toast('Downloading isn’t available here. Use Copy.', { kind: 'warn' }); }
        });
      } });
  },
  importLib: () => Sheet.open({ title: 'Import library', cls: 'tall', html: `<p class="muted">Paste a SONORA backup or choose the file. Items are merged. Nothing is deleted.</p>
      <textarea id="import-text" class="field mono" rows="8" placeholder='{"app":"SONORA", …}' aria-label="Backup text"></textarea>
      <div class="form-actions"><button type="button" class="btn ghost" id="import-file">${ic('upload')} Choose file</button><button type="button" class="btn primary" id="import-go">Import</button></div>`,
    onMount: body => {
      const ta = $('#import-text', body);
      $('#import-file', body).addEventListener('click', () => pickFile('.json,application/json', async f => { ta.value = await f.text(); }));
      $('#import-go', body).addEventListener('click', () => { try { const n = Lib.importJSON(ta.value); toast(n ? `Imported ${plural(n, 'item')}` : 'Nothing new to import', { ms: 2500 }); popTop(false); } catch (e) { toast(errMsg(e), { kind: 'warn' }); } });
    } }),
  clearHistory: () => { Lib.clearHistory(); toast('History cleared', { ms: 1500 }); },
  resetListening: async () => { if (await askConfirm({ title: 'Reset listening history?', text: 'This clears your play history and listening stats. Recommendations start fresh.', okLabel: 'Reset', danger: true })) { Lib.clearHistory(); Lib.resetStats(); toast('Reset', { ms: 1500 }); } },
  wipeAll: async () => {
    if (!(await askConfirm({ title: 'Delete everything?', text: 'Playlists, likes, follows, history, settings and local music will be removed from this device. This can’t be undone.', okLabel: 'Delete all', danger: true }))) return;
    PL.pause(); LS.clearAll();
    for (const s of ['files', 'meta', 'offline']) { try { await IDB.clear(s); } catch { /* ignore */ } }
    location.reload();
  },
  openShortcuts: () => Sheet.open({ title: 'Keyboard shortcuts', cls: 'dialog', html: `<dl class="keys">
    <div><dt>Space</dt><dd>Play / pause</dd></div><div><dt>← →</dt><dd>Seek 5 seconds</dd></div><div><dt>Shift + ← →</dt><dd>Previous / next</dd></div>
    <div><dt>↑ ↓</dt><dd>Volume</dd></div><div><dt>M</dt><dd>Mute</dd></div><div><dt>L</dt><dd>Like current song</dd></div>
    <div><dt>S / R</dt><dd>Shuffle / repeat</dd></div><div><dt>N / Q</dt><dd>Now playing / queue</dd></div><div><dt>/</dt><dd>Search</dd></div><div><dt>Esc</dt><dd>Close / go back</dd></div></dl>` })
});
