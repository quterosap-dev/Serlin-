/* ==========================================================================
   SONORA — 02 providers: network layer + Audius (primary), Jamendo (optional,
   needs a free client_id), Internet Archive (optional, experimental)
   --------------------------------------------------------------------------
   Audius endpoints used (documented in Audius' public OpenAPI spec):
     GET /v1/tracks/trending?genre&time&limit&offset
     GET /v1/tracks/search?query&limit&sort_method&mood
     GET /v1/tracks/{id}/stream            (302 -> mp3; Range supported)
   Used on the strength of Audius' public REST docs, not re-read in this build
   (failures degrade gracefully):
     GET /v1/users/search?query            GET /v1/playlists/search?query
     GET /v1/playlists/trending            GET /v1/playlists/{id}/tracks
     GET /v1/users/{id}/tracks             GET /v1/users/{id}
   ========================================================================== */

const NET = { state: 'ok', failed: new Set(), online: navigator.onLine };
function setNet(state, provider) {
  if (state === 'ok') { if (provider) NET.failed.delete(provider); else NET.failed.clear(); if (!NET.failed.size) NET.state = 'ok'; }
  else if (state === 'fail') { NET.failed.add(provider); NET.state = 'fail'; }
  else NET.state = state;
  Bus.emit('net');
}

class ApiError extends Error {
  constructor(msg, { status, kind } = {}) { super(msg); this.status = status; this.kind = kind; }
}

const CACHE = new Map();
const INFLIGHT = new Map();
const CACHE_MAX = 250;

async function jget(url, { signal, ttl = 300000, provider = 'Audius' } = {}) {
  const hit = CACHE.get(url);
  if (hit && Date.now() - hit.t < ttl) return hit.v;
  if (!signal && INFLIGHT.has(url)) return INFLIGHT.get(url);
  const run = (async () => {
    let res;
    try {
      res = await fetch(url, { signal, headers: { Accept: 'application/json' } });
    } catch (e) {
      if (e && e.name === 'AbortError') throw new ApiError('aborted', { kind: 'abort' });
      if (!navigator.onLine) { NET.online = false; setNet('offline'); throw new ApiError('You are offline.', { kind: 'offline' }); }
      setNet('fail', provider);
      throw new ApiError(`Can't reach ${provider}.`, { kind: 'network' });
    }
    if (!res.ok) {
      const msg = res.status === 429 ? `${provider} is rate-limiting requests. Try again in a minute.`
        : res.status >= 500 ? `${provider} is having problems (${res.status}).`
          : `${provider} returned an error (${res.status}).`;
      throw new ApiError(msg, { status: res.status, kind: 'http' });
    }
    let j;
    try { j = await res.json(); } catch { throw new ApiError(`${provider} sent an unreadable response.`, { kind: 'parse' }); }
    setNet('ok', provider);
    CACHE.set(url, { t: Date.now(), v: j });
    if (CACHE.size > CACHE_MAX) CACHE.delete(CACHE.keys().next().value);
    return j;
  })();
  if (!signal) INFLIGHT.set(url, run);
  try { return await run; } finally { INFLIGHT.delete(url); }
}
/* stale-while-error: if the network fails but we have an older copy, use it */
async function jgetStale(url, opts) {
  try { return await jget(url, opts); } catch (e) {
    const hit = CACHE.get(url);
    if (hit && e.kind !== 'abort') return hit.v;
    throw e;
  }
}
const errMsg = e => (e && e.message) || 'Something went wrong.';

/* ---------- Audius ---------- */
function normAudiusTrack(r) {
  if (!r || !r.id) return null;
  const a = r.artwork || {}, u = r.user || {};
  const access = r.access || {};
  return rememberTrack({
    id: 'au:' + r.id, src: 'audius', rid: r.id,
    title: r.title || 'Untitled', artist: u.name || 'Unknown artist',
    artistId: u.id ? 'au:' + u.id : null, handle: u.handle || '',
    album: (r.album_backlink && r.album_backlink.playlist_name) || '',
    dur: Number(r.duration) || 0,
    art150: a['150x150'] || '', art480: a['480x480'] || '', art1000: a['1000x1000'] || '',
    genre: r.genre || '', mood: r.mood || '',
    perm: r.permalink ? (r.permalink.startsWith('http') ? r.permalink : 'https://audius.co' + r.permalink) : '',
    dl: !!access.download,
    stream: r.is_streamable !== false && access.stream !== false,
    plays: Number(r.play_count) || 0,
    rel: r.release_date || r.created_at || '',
    alt: (r.stream && r.stream.url) || '',
    uimg: (u.profile_picture && u.profile_picture['480x480']) || '', uimg150: (u.profile_picture && u.profile_picture['150x150']) || '',
    ufol: Number(u.follower_count) || 0
  });
}
function normAudiusUser(r) {
  if (!r || !r.id) return null;
  const p = r.profile_picture || {};
  return {
    id: 'au:' + r.id, src: 'audius', rid: r.id, name: r.name || r.handle || 'Unknown artist', handle: r.handle || '',
    img150: p['150x150'] || '', img480: p['480x480'] || '', followers: Number(r.follower_count) || 0,
    trackCount: Number(r.track_count) || 0, verified: !!r.is_verified,
    perm: r.handle ? 'https://audius.co/' + r.handle : ''
  };
}
function normAudiusList(r) {
  if (!r || !r.id) return null;
  const a = r.artwork || {}, u = r.user || {};
  return {
    id: 'aul:' + r.id, rid: r.id, src: 'audius', kind: r.is_album ? 'album' : 'playlist',
    name: r.playlist_name || r.name || 'Untitled', art150: a['150x150'] || '', art480: a['480x480'] || '',
    artist: u.name || '', artistId: u.id ? 'au:' + u.id : null, count: Number(r.track_count) || 0,
    desc: r.description || '',
    perm: r.permalink ? (r.permalink.startsWith('http') ? r.permalink : 'https://audius.co' + r.permalink) : ''
  };
}

const Audius = {
  name: 'Audius',
  base() { return (PREFS.audiusHost || 'https://api.audius.co').replace(/\/+$/, '') + '/v1'; },
  url(path, params = {}) {
    const u = new URLSearchParams();
    u.set('app_name', 'SONORA');
    for (const [k, v] of Object.entries(params)) {
      if (v == null || v === '') continue;
      if (Array.isArray(v)) v.forEach(x => u.append(k, x)); else u.set(k, v);
    }
    return this.base() + path + '?' + u.toString();
  },
  async data(path, params, opts) {
    const j = await jgetStale(this.url(path, params), { provider: 'Audius', ...opts });
    return j && j.data !== undefined ? j.data : j;
  },
  async trending({ genre, time = 'week', limit = 25, offset = 0 } = {}, o) {
    return arr(await this.data('/tracks/trending', { genre, time, limit, offset }, o)).map(normAudiusTrack).filter(Boolean);
  },
  async searchTracks(query, { limit = 25, offset = 0, sort = 'popular', mood } = {}, o) {
    return arr(await this.data('/tracks/search', { query, limit, offset, sort_method: sort, mood }, { ttl: 60000, ...o })).map(normAudiusTrack).filter(Boolean);
  },
  async searchUsers(query, { limit = 12 } = {}, o) {
    return arr(await this.data('/users/search', { query, limit }, { ttl: 60000, ...o })).map(normAudiusUser).filter(Boolean);
  },
  async searchLists(query, { limit = 16 } = {}, o) {
    return arr(await this.data('/playlists/search', { query, limit }, { ttl: 60000, ...o })).map(normAudiusList).filter(Boolean);
  },
  async trendingLists({ type, time = 'week', limit = 20 } = {}, o) {
    return arr(await this.data('/playlists/trending', { type, time, limit }, o)).map(normAudiusList).filter(Boolean);
  },
  async listTracks(rid, o) {
    return arr(await this.data(`/playlists/${encodeURIComponent(rid)}/tracks`, {}, o)).map(normAudiusTrack).filter(Boolean);
  },
  async userTracks(rid, { sort = 'plays', limit = 25 } = {}, o) {
    return arr(await this.data(`/users/${encodeURIComponent(rid)}/tracks`, { sort, limit }, o)).map(normAudiusTrack).filter(Boolean);
  },
  async user(rid, o) { return normAudiusUser(await this.data(`/users/${encodeURIComponent(rid)}`, {}, o)); },
  streamUrl(t) {
    const p = { };
    if (PREFS.audiusKey) p.api_key = PREFS.audiusKey;
    return this.url(`/tracks/${encodeURIComponent(t.rid)}/stream`, p);
  }
};

/* ---------- Jamendo (optional: needs a free client_id from devportal.jamendo.com) ---------- */
function normJamendoTrack(r) {
  if (!r || !r.id) return null;
  const tags = (r.musicinfo && r.musicinfo.tags && r.musicinfo.tags.genres) || [];
  return rememberTrack({
    id: 'ja:' + r.id, src: 'jamendo', rid: r.id, title: r.name || 'Untitled', artist: r.artist_name || 'Unknown artist',
    artistId: r.artist_id ? 'ja:' + r.artist_id : null, album: r.album_name || '', dur: Number(r.duration) || 0,
    art150: r.image || '', art480: r.image || r.album_image || '', genre: tags[0] || '',
    perm: r.shareurl || '', dl: !!r.audiodownload_allowed, stream: !!r.audio, audio: r.audio || '',
    license: r.license_ccurl || '', rel: r.releasedate || ''
  });
}
const Jamendo = {
  name: 'Jamendo',
  enabled() { return !!(PREFS.useJamendo && PREFS.jamendoId); },
  async tracks(params = {}, o) {
    const u = new URLSearchParams({
      client_id: PREFS.jamendoId, format: 'json', limit: params.limit || 20, audioformat: 'mp32', imagesize: 300,
      include: 'musicinfo'
    });
    for (const [k, v] of Object.entries(params)) if (v != null && v !== '' && k !== 'limit') u.set(k, v);
    const j = await jgetStale('https://api.jamendo.com/v3.0/tracks/?' + u, { provider: 'Jamendo', ttl: 120000, ...o });
    if (j && j.headers && j.headers.status === 'failed') throw new ApiError(`Jamendo: ${j.headers.error_message || 'request failed'}`, { kind: 'http' });
    return arr(j && j.results).map(normJamendoTrack).filter(Boolean);
  },
  search(q, o) { return this.tracks({ search: q, order: 'popularity_total' }, o); },
  popular(extra = {}, o) { return this.tracks({ order: 'popularity_week', ...extra }, o); }
};

/* ---------- Internet Archive (experimental, off by default; not verified against the live service) ---------- */
const Archive = {
  name: 'Internet Archive',
  enabled() { return !!PREFS.useArchive; },
  async search(q, { rows = 15 } = {}, o) {
    const lic = '(licenseurl:*creativecommons.org* OR licenseurl:*publicdomain*)';
    const qq = `(${q}) AND mediatype:audio AND ${lic}`;
    const u = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(qq)}&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=licenseurl&rows=${rows}&output=json&sort[]=downloads+desc`;
    const j = await jgetStale(u, { provider: 'Internet Archive', ttl: 120000, ...o });
    return arr(j && j.response && j.response.docs).map(d => rememberTrack({
      id: 'ia:' + d.identifier, src: 'archive', rid: d.identifier, title: d.title || d.identifier,
      artist: Array.isArray(d.creator) ? d.creator[0] : (d.creator || 'Unknown'), album: '', dur: 0,
      art480: `https://archive.org/services/img/${encodeURIComponent(d.identifier)}`, art150: `https://archive.org/services/img/${encodeURIComponent(d.identifier)}`,
      genre: '', perm: `https://archive.org/details/${encodeURIComponent(d.identifier)}`, stream: true,
      license: Array.isArray(d.licenseurl) ? d.licenseurl[0] : (d.licenseurl || '')
    }));
  },
  async resolve(t) {
    const j = await jget(`https://archive.org/metadata/${encodeURIComponent(t.rid)}`, { provider: 'Internet Archive', ttl: 600000 });
    const files = arr(j && j.files);
    const pref = ['VBR MP3', 'MP3', '128Kbps MP3', '64Kbps MP3', 'Ogg Vorbis'];
    for (const f of pref) {
      const hit = files.find(x => x.format === f);
      if (hit) return `https://archive.org/download/${encodeURIComponent(t.rid)}/${hit.name.split('/').map(encodeURIComponent).join('/')}`;
    }
    throw new ApiError('No playable audio file found for this Internet Archive item.', { kind: 'http' });
  }
};

/* ---------- aggregate helpers ---------- */
function interleave(...lists) {
  const out = [], max = Math.max(0, ...lists.map(l => l.length));
  for (let i = 0; i < max; i++) lists.forEach(l => { if (l[i]) out.push(l[i]); });
  return uniqBy(out, t => t.id);
}
const providerCount = () => 1 + (Jamendo.enabled() ? 1 : 0) + (Archive.enabled() ? 1 : 0);

/* search across every enabled provider; one provider failing never hides the others */
async function searchAll(q, { signal } = {}) {
  const o = { signal };
  const jobs = {
    tracks: Audius.searchTracks(q, { limit: 25 }, o),
    artists: Audius.searchUsers(q, {}, o),
    lists: Audius.searchLists(q, {}, o)
  };
  if (Jamendo.enabled()) jobs.jtracks = Jamendo.search(q, o);
  if (Archive.enabled()) jobs.atracks = Archive.search(q, {}, o);
  const keys = Object.keys(jobs);
  const res = await Promise.allSettled(keys.map(k => jobs[k]));
  const out = { tracks: [], artists: [], lists: [], errors: [] };
  const got = {};
  res.forEach((r, i) => {
    if (r.status === 'fulfilled') got[keys[i]] = r.value;
    else if (!(r.reason && r.reason.kind === 'abort')) out.errors.push({ part: keys[i], msg: errMsg(r.reason), kind: r.reason && r.reason.kind });
  });
  out.tracks = interleave(got.tracks || [], got.jtracks || [], got.atracks || []);
  out.artists = got.artists || [];
  out.lists = got.lists || [];
  out.aborted = res.some(r => r.status === 'rejected' && r.reason && r.reason.kind === 'abort');
  return out;
}

/* ---------- playable source resolution ---------- */
async function resolveSources(t) {
  if (t.src === 'local') {
    const blob = await getLocalBlob(t);
    if (!blob) throw new ApiError('This local file is no longer available. Add it again from your device.', { kind: 'missing' });
    return { urls: [URL.createObjectURL(blob)], blob: true };
  }
  const off = await getOfflineBlob(t.id).catch(() => null);
  if (off) return { urls: [URL.createObjectURL(off)], blob: true };
  if (t.stream === false) throw new ApiError('This track is not available for streaming.', { kind: 'unavailable' });
  if (t.src === 'audius') {
    const urls = [Audius.streamUrl(t)];
    if (t.alt && t.alt !== urls[0]) urls.push(t.alt);
    return { urls };
  }
  if (t.src === 'jamendo') return { urls: [t.audio] };
  if (t.src === 'archive') return { urls: [await Archive.resolve(t)] };
  throw new ApiError('Unknown music source.', { kind: 'unavailable' });
}
