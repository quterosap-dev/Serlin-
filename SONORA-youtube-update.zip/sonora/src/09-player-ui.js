/* ==========================================================================
   SONORA — 09 player UI: mini-player, Now Playing, queue, lyrics, sleep timer,
   sound (equalizer / speed / crossfade), add-to-playlist
   ========================================================================== */

/* ---------- small refreshers shared with lists ---------- */
function refreshRows() {
  const cur = curTrack(), playing = PS.playing;
  $$('.row[data-tid], .card[data-tid]').forEach(r => {
    const is = !!cur && r.dataset.tid === cur.id;
    r.classList.toggle('is-current', is);
    r.classList.toggle('is-playing', is && playing);
  });
}
function refreshHearts() {
  $$('[data-act="like"][data-tid]').forEach(b => {
    const t = TR.get(b.dataset.tid), on = Lib.isLiked(t);
    b.classList.toggle('on', on); b.setAttribute('aria-pressed', on);
  });
  npLike(); miniLike();
}
const playIcon = () => (PS.playing ? 'pause' : 'play');

/* ==========================================================================
   MINI PLAYER
   ========================================================================== */
function renderMini() {
  const m = $('#mini'), t = curTrack();
  if (!m) return;
  m.hidden = !t;
  document.body.classList.toggle('has-mini', !!t);
  if (!t) return;
  if (m.dataset.tid !== t.id) {
    m.dataset.tid = t.id;
    $('.mini-art', m).innerHTML = artEl(t, 'sm');
    $('.mini-title', m).textContent = t.title;
    $('.mini-sub', m).textContent = t.artist;
  }
  miniState(); miniLike(); miniTime();
}
function miniState() {
  const m = $('#mini'); if (!m || m.hidden) return;
  const b = $('.mini-play', m);
  b.innerHTML = PS.buffering && PS.playing ? `<span class="spinner" aria-hidden="true"></span>` : ic(playIcon());
  b.setAttribute('aria-label', PS.playing ? 'Pause' : 'Play');
  m.classList.toggle('is-err', !!PS.error);
  const sub = $('.mini-sub', m), t = curTrack();
  if (t) sub.textContent = PS.error ? PS.error : PS.waiting ? 'Reconnecting…' : t.artist;
}
function miniLike() { const b = $('#mini .mini-like'); if (!b) return; const on = Lib.isLiked(curTrack()); b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); }
function miniTime() {
  const i = $('#mini .mini-bar i'); if (!i) return;
  const d = PS.dur || (curTrack() && curTrack().dur) || 0;
  i.style.width = d ? clamp(PS.pos / d * 100, 0, 100) + '%' : '0%';
}

/* ==========================================================================
   NOW PLAYING
   ========================================================================== */
const NPS = { seeking: false, bgFlip: false, lastTid: null };
function openNP() {
  if (!curTrack() || UI_STACK.some(i => i.kind === 'np')) return;
  const el = $('#np'); el.hidden = false;
  requestAnimationFrame(() => el.classList.add('in'));
  npRender(true);
  pushUI({ kind: 'np', el, close() { el.classList.remove('in'); setTimeout(() => { if (!el.classList.contains('in')) el.hidden = true; }, 320); } });
  setTimeout(() => { const b = $('#np .np-close'); b && b.focus({ preventScroll: true }); }, 340);
}
function closeKind(kind) {
  if (!UI_STACK.some(i => i.kind === kind)) return;
  for (;;) { const top = UI_STACK[UI_STACK.length - 1]; popTop(false); if (!top || top.kind === kind) break; }
}
const closeNP = () => closeKind('np');

function ctxLabel() {
  const c = Q.ctx;
  if (!c) return 'Your queue';
  return c.name || (c.type === 'search' ? 'Search results' : 'Your queue');
}
function npRender(full) {
  const t = curTrack(); if (!t) return;
  $('#np-ctx').textContent = ctxLabel();
  $('#np-title').textContent = t.title;
  $('#np-artist').textContent = t.artist;
  $('#np-artist').setAttribute('aria-label', t.artistId ? `Go to artist ${t.artist}` : `Artist ${t.artist}`);
  $('#np-artist').disabled = !t.artistId;
  $('#np-album').textContent = t.album || (t.src === 'audius' ? 'Audius' : t.src === 'jamendo' ? 'Jamendo' : t.src === 'archive' ? 'Internet Archive' : 'On this device');
  if (NPS.lastTid !== t.id) {
    NPS.lastTid = t.id;
    const art = $('#np-art');
    art.innerHTML = artEl(t, 'lg', 'np-artimg');
    art.classList.remove('pop'); void art.offsetWidth; art.classList.add('pop');
    npBackground(t);
  }
  npState(); npLike(); npTime(); npTools();
}
async function npBackground(t) {
  const url = artUrl(t, 'md'), h = hueOf(t.id), s = 62;
  const layer = $(NPS.bgFlip ? '.np-bg-b' : '.np-bg-a'), other = $(NPS.bgFlip ? '.np-bg-a' : '.np-bg-b');
  NPS.bgFlip = !NPS.bgFlip;
  const apply = (hh, ss) => {
    layer.style.setProperty('--c1', `hsl(${hh} ${ss}% 36%)`);
    layer.style.setProperty('--c2', `hsl(${(hh + 34) % 360} ${Math.max(30, ss - 14)}% 12%)`);
    layer.innerHTML = url && !PREFS.dataSaver ? `<img src="${esc(url)}" alt="" class="np-bg-img" decoding="async">` : '';
    layer.classList.add('on'); other.classList.remove('on');
  };
  apply(h, s);
  const rgb = await sampleColor(url);
  if (rgb && curTrack() && curTrack().id === t.id) {
    const [hh, ss] = rgbToHs(rgb);
    layer.style.setProperty('--c1', `hsl(${hh} ${clamp(ss, 35, 75)}% 36%)`);
    layer.style.setProperty('--c2', `hsl(${(hh + 34) % 360} ${clamp(ss - 12, 25, 60)}% 12%)`);
  }
}
function sampleColor(url) {
  return new Promise(res => {
    if (!url || PREFS.dataSaver) return res(null);
    const im = new Image(); im.crossOrigin = 'anonymous';
    const to = setTimeout(() => res(null), 2500);
    im.onload = () => {
      clearTimeout(to);
      try {
        const c = document.createElement('canvas'); c.width = c.height = 8;
        const g = c.getContext('2d'); g.drawImage(im, 0, 0, 8, 8);
        const d = g.getImageData(0, 0, 8, 8).data; let r = 0, gg = 0, b = 0, n = 0;
        for (let i = 0; i < d.length; i += 4) { const w = 1 + (Math.max(d[i], d[i + 1], d[i + 2]) - Math.min(d[i], d[i + 1], d[i + 2])) / 64; r += d[i] * w; gg += d[i + 1] * w; b += d[i + 2] * w; n += w; }
        res([r / n, gg / n, b / n]);
      } catch { res(null); }
    };
    im.onerror = () => { clearTimeout(to); res(null); };
    im.src = url;
  });
}
function rgbToHs([r, g, b]) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, l = (mx + mn) / 2;
  let h = 0;
  if (d) { h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h = Math.round(h * 60); if (h < 0) h += 360; }
  const s = d ? d / (1 - Math.abs(2 * l - 1)) : 0;
  return [h, Math.round(s * 100)];
}
function npState() {
  const play = $('#np-play'); if (!play) return;
  play.innerHTML = PS.buffering && PS.playing ? `<span class="spinner big" aria-hidden="true"></span>` : ic(playIcon());
  play.setAttribute('aria-label', PS.playing ? 'Pause' : 'Play');
  const sh = $('#np-shuffle'), rp = $('#np-repeat');
  sh.classList.toggle('on', !!PREFS.shuffle); sh.setAttribute('aria-pressed', !!PREFS.shuffle);
  rp.classList.toggle('on', PREFS.repeat !== 'off'); rp.classList.toggle('one', PREFS.repeat === 'one');
  rp.setAttribute('aria-label', `Repeat: ${PREFS.repeat}`); rp.setAttribute('aria-pressed', PREFS.repeat !== 'off');
  const mute = $('#np-mute'); mute.innerHTML = ic(PREFS.muted || PREFS.volume === 0 ? 'volume-x' : 'volume');
  const vol = $('#np-vol'); if (document.activeElement !== vol) vol.value = Math.round((PREFS.muted ? 0 : PREFS.volume) * 100);
  const st = $('#np-status');
  if (PS.error) st.innerHTML = `<span class="st-err">${ic('alert')} ${esc(PS.error)}</span> <button type="button" class="link-btn" data-act="npRetry">Try again</button>`;
  else if (PS.waiting) st.innerHTML = `<span class="st-wait"><span class="spinner" aria-hidden="true"></span> Waiting for connection. Playback resumes where it stopped.</span>`;
  else if (PS.buffering && PS.playing) st.innerHTML = `<span class="st-wait"><span class="spinner" aria-hidden="true"></span> Buffering…</span>`;
  else st.textContent = '';
}
function npLike() {
  const b = $('#np-like'); if (!b) return;
  const on = Lib.isLiked(curTrack());
  b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); b.setAttribute('aria-label', on ? 'Unlike' : 'Like');
}
function npTime() {
  const t = curTrack(); if (!t) return;
  const dur = PS.dur || t.dur || 0, seek = $('#np-seek'); if (!seek) return;
  $('#np-dur').textContent = fmtTime(dur);
  seek.disabled = !dur;
  if (!NPS.seeking) {
    $('#np-pos').textContent = fmtTime(PS.pos);
    seek.value = dur ? Math.round(clamp(PS.pos / dur, 0, 1) * 1000) : 0;
    seek.style.setProperty('--p', (seek.value / 10) + '%');
    seek.setAttribute('aria-valuetext', `${fmtTime(PS.pos)} of ${fmtTime(dur)}`);
  }
}
function npTools() {
  const q = $('#np-queue-count'); if (q) q.textContent = PL.upcomingCount() || '';
  const sl = $('#np-sleep'); if (sl) { sl.classList.toggle('on', !!Sleep.mode); const lab = $('span', sl); if (lab) lab.textContent = Sleep.mode === 'time' ? fmtTime(Sleep.remaining() / 1000) : Sleep.mode === 'track' ? 'End' : 'Sleep'; }
  const sp = $('#np-sound'); if (sp) sp.classList.toggle('on', PREFS.eq.on || PREFS.speed !== 1 || PREFS.crossfade > 0);
}
function wireNP() {
  const seek = $('#np-seek');
  seek.addEventListener('pointerdown', () => { NPS.seeking = true; });
  seek.addEventListener('input', () => {
    NPS.seeking = true;
    const dur = PS.dur || (curTrack() && curTrack().dur) || 0;
    $('#np-pos').textContent = fmtTime(seek.value / 1000 * dur);
    seek.style.setProperty('--p', (seek.value / 10) + '%');
  });
  seek.addEventListener('change', () => {
    const dur = PS.dur || (curTrack() && curTrack().dur) || 0;
    if (dur) PL.seek(seek.value / 1000 * dur);
    NPS.seeking = false;
  });
  seek.addEventListener('pointerup', () => { setTimeout(() => { NPS.seeking = false; }, 0); });
  $('#np-vol').addEventListener('input', e => PL.setVolume(e.target.value / 100));
}

/* ==========================================================================
   QUEUE
   ========================================================================== */
function queueRow(t, i) {
  const cur = i === Q.idx, past = i < Q.idx;
  return `<div class="row q-row ${cur ? 'is-current' : ''} ${cur && PS.playing ? 'is-playing' : ''} ${past ? 'is-past' : ''} ${isUnavail(t) ? 'is-unavail' : ''}" data-act="queueJump" data-i="${i}" data-tid="${esc(t.id)}" role="button" tabindex="0">
    <button class="row-grip" type="button" data-grip aria-label="Drag to reorder">${ic('grip')}</button>
    <div class="row-art-wrap">${artEl(t, 'sm', 'row-art')}<span class="eqbars" aria-hidden="true"><i></i><i></i><i></i></span></div>
    <div class="row-main"><div class="row-title">${esc(t.title)}</div><div class="row-sub"><span>${esc(t.artist)}</span></div></div>
    ${cur ? '<span class="badge">Now</span>' : `<button class="icon-btn" type="button" data-act="queueRemove" data-i="${i}" aria-label="Remove ${esc(t.title)} from queue">${ic('x')}</button>`}</div>`;
}
function openQueue() {
  if (!Q.list.length) { toast('Your queue is empty.'); return; }
  Sheet.open({
    title: 'Queue', cls: 'tall',
    html: `<div class="queue-meta"><span class="muted" id="q-count"></span><button type="button" class="link-btn" data-act="queueClear">Clear upcoming</button></div><div id="q-list" class="rows"></div>`,
    onMount: body => {
      const list = $('#q-list', body);
      const draw = () => {
        const y = list.scrollTop;
        $('#q-count', body).textContent = `${plural(Q.list.length, 'song')} · ${PL.upcomingCount()} up next${PREFS.shuffle ? ' · shuffled' : ''}`;
        list.innerHTML = Q.list.map(queueRow).join('');
        list.scrollTop = y;
      };
      draw();
      const cur = $('.is-current', list); if (cur) cur.scrollIntoView({ block: 'center' });
      makeSortable(list, (from, to) => PL.moveInQueue(from, to), '.q-row');
      watch(body, 'queue', draw);
      watch(body, 'player:state', () => { $$('.q-row', list).forEach((r, i) => { r.classList.toggle('is-playing', i === Q.idx && PS.playing); }); });
    }
  });
}

/* ==========================================================================
   LYRICS (only lyrics the user supplies or that are embedded in their files)
   ========================================================================== */
function openLyrics(track) {
  const t = track || curTrack(); if (!t) return;
  Sheet.open({
    title: 'Lyrics', cls: 'tall',
    html: `<div id="ly-body" class="ly-body"></div>`,
    onMount: body => {
      const box = $('#ly-body', body);
      let parsed = null, active = -1;
      const draw = () => {
        const text = lyricsFor(t); parsed = parseLyrics(text); active = -1;
        const isCur = curTrack() && curTrack().id === t.id;
        if (!text) {
          box.innerHTML = `<div class="empty compact">${ic('text', 'empty-ic')}<h3>No lyrics for this song</h3>
            <p>Audius doesn’t provide lyrics, and no licensed lyrics service is connected to SONORA. You can add your own: attach an .lrc file (it scrolls in time) or a text file, or paste lyrics.${t.src === 'local' ? ' Lyrics embedded in your audio files are picked up automatically.' : ''}</p>
            <div class="btn-pair"><button type="button" class="btn primary small" data-act="lyAttach" data-tid="${esc(t.id)}">${ic('upload')} Attach file</button><button type="button" class="btn ghost small" data-act="lyPaste" data-tid="${esc(t.id)}">Paste lyrics</button></div></div>`;
          return;
        }
        box.innerHTML = `<div class="ly-head"><strong>${esc(t.title)}</strong><span class="muted"> · ${esc(t.artist)}${parsed.synced ? ' · synced' : ''}</span></div>
          <div class="ly-lines ${parsed.synced ? 'synced' : ''}">${parsed.lines.map((l, i) => `<p class="ly" data-i="${i}">${esc(l.text) || '&nbsp;'}</p>`).join('')}</div>
          <div class="btn-pair"><button type="button" class="btn ghost small" data-act="lyAttach" data-tid="${esc(t.id)}">Replace</button><button type="button" class="btn ghost small danger" data-act="lyRemove" data-tid="${esc(t.id)}">Remove</button></div>
          ${isCur ? '' : '<p class="muted">Play this song to follow along.</p>'}`;
      };
      const follow = () => {
        if (!parsed || !parsed.synced || !curTrack() || curTrack().id !== t.id) return;
        let idx = -1; for (let i = 0; i < parsed.lines.length; i++) { if (parsed.lines[i].t <= PS.pos + 0.15) idx = i; else break; }
        if (idx === active) return;
        active = idx;
        $$('.ly', box).forEach((p, i) => p.classList.toggle('on', i === idx));
        const p = $(`.ly[data-i="${idx}"]`, box); if (p) p.scrollIntoView({ block: 'center', behavior: 'smooth' });
      };
      draw();
      watch(body, 'lib', k => { if (k === 'lyrics') draw(); });
      watch(body, 'player:time', follow);
    }
  });
}
function pickFile(accept, handler) {
  const i = document.createElement('input'); i.type = 'file'; i.accept = accept; i.hidden = true;
  document.body.appendChild(i);
  i.addEventListener('change', async () => { try { if (i.files[0]) await handler(i.files[0]); } finally { i.remove(); } });
  i.addEventListener('cancel', () => i.remove());
  i.click();
}

/* ==========================================================================
   SLEEP TIMER
   ========================================================================== */
function openSleep() {
  Sheet.open({
    title: 'Sleep timer', cls: 'dialog',
    html: `${Sleep.mode ? `<p class="muted" id="sleep-status"></p>` : '<p class="muted">Stop playback automatically. The volume fades out at the end.</p>'}
      ${menuItems([5, 15, 30, 45, 60].map(m => ({ icon: 'moon', label: `${m} minutes`, act: 'sleepSet', data: { m } })).concat([
        { icon: 'music', label: 'End of this track', act: 'sleepSet', data: { m: 'track' } },
        Sleep.mode ? { icon: 'x', label: 'Turn off timer', act: 'sleepSet', data: { m: 'off' } } : null]))}`,
    onMount: body => {
      const st = $('#sleep-status', body);
      const draw = () => { if (st) st.textContent = Sleep.mode === 'track' ? 'Playback stops when this track ends.' : Sleep.mode === 'time' ? `Playback stops in ${fmtTime(Sleep.remaining() / 1000)}.` : ''; };
      draw(); watch(body, 'sleep:tick', draw);
    }
  });
}

/* ==========================================================================
   SOUND: equalizer, speed, crossfade
   ========================================================================== */
function openSound() {
  const speeds = [0.75, 1, 1.25, 1.5, 2];
  Sheet.open({
    title: 'Sound', cls: 'tall',
    html: `<div id="sound-body"></div>`,
    onMount: body => {
      const box = $('#sound-body', body);
      const draw = () => {
        const eq = PREFS.eq;
        box.innerHTML = `
          <section class="snd-sec"><div class="snd-head"><h4>Playback speed</h4><span class="muted">${PREFS.speed}×</span></div>
            <div class="chips">${speeds.map(s => `<button type="button" class="chip ${PREFS.speed === s ? 'on' : ''}" data-act="setSpeed" data-val="${s}" aria-pressed="${PREFS.speed === s}">${s}×</button>`).join('')}</div>
            <p class="muted snd-note">Pitch stays the same.</p></section>
          <section class="snd-sec"><div class="snd-head"><h4>Equalizer</h4>${toggleCtl('eqOn', eq.on, 'Equalizer')}</div>
            <div class="chips wrap">${Object.keys(EQ_PRESETS).map(k => `<button type="button" class="chip ${eq.preset === k ? 'on' : ''}" data-act="eqPreset" data-preset="${k}" aria-pressed="${eq.preset === k}">${k === 'lofi' ? 'Lo-fi' : k[0].toUpperCase() + k.slice(1)}</button>`).join('')}</div>
            <div class="eq-bands ${eq.on ? '' : 'off'}">${EQ_BANDS.map((b, i) => `<label class="eq-band"><span class="eq-val" id="eqv${i}">${eq.gains[i] > 0 ? '+' : ''}${eq.gains[i]}</span>
              <input type="range" min="-12" max="12" step="1" value="${eq.gains[i]}" data-range="eq" data-i="${i}" aria-label="${b.label} gain in decibels" orient="vertical"><span class="eq-f">${b.label}</span></label>`).join('')}</div>
            <p class="muted snd-note">Works for files on your device. For online music it only works when the music server allows audio processing. SONORA tests this and switches the equalizer off if it doesn’t.</p></section>
          <section class="snd-sec"><div class="snd-head"><h4>Crossfade</h4><span class="muted" id="snd-cf">${PREFS.crossfade ? PREFS.crossfade + ' s' : 'Off'}</span></div>
            <input type="range" min="0" max="12" step="1" value="${PREFS.crossfade}" data-range="crossfade" aria-label="Crossfade seconds" ${PREFS.dataSaver ? 'disabled' : ''}>
            <p class="muted snd-note">${PREFS.dataSaver ? 'Turned off while Data saver is on.' : 'Blends the end of a song into the next one.'}</p></section>`;
      };
      draw();
      watch(body, 'eq', draw);
      watch(body, 'pref', k => { if (k === 'speed' || k === 'eq') draw(); });
    }
  });
}
document.addEventListener('input', e => {
  const r = e.target.closest && e.target.closest('[data-range]'); if (!r) return;
  const v = +r.value, k = r.dataset.range;
  if (k === 'eq') {
    const i = +r.dataset.i; PREFS.eq.gains[i] = v; PREFS.eq.preset = 'custom';
    E.setEqGains(PREFS.eq.gains); const o = $('#eqv' + i); if (o) o.textContent = (v > 0 ? '+' : '') + v;
    $$('[data-act="eqPreset"]').forEach(b => { b.classList.remove('on'); b.setAttribute('aria-pressed', 'false'); });
  } else if (k === 'crossfade') {
    const o = $('#cf-out'), o2 = $('#snd-cf'); const txt = v ? v + ' s' : 'Off'; if (o) o.textContent = txt; if (o2) o2.textContent = txt;
  }
});
document.addEventListener('change', e => {
  const r = e.target.closest && e.target.closest('[data-range]'); if (r) {
    const v = +r.value, k = r.dataset.range;
    if (k === 'eq') setPref('eq', PREFS.eq);
    else if (k === 'crossfade') { setPref('crossfade', v); npTools(); }
    return;
  }
  const f = e.target.closest && e.target.closest('[data-field]'); if (!f) return;
  const k = f.dataset.field; let v = f.value.trim();
  if (k === 'audiusHost') {
    if (!/^https?:\/\/[^\s]+$/i.test(v)) { toast('Enter a full address starting with https://', { kind: 'warn' }); f.value = PREFS.audiusHost; return; }
    v = v.replace(/\/+$/, ''); CACHE.clear();
  }
  if (k === 'jamendoId') CACHE.clear();
  setPref(k, v); toast('Saved.');
  if (k === 'jamendoId' || k === 'audiusHost') { NAVS.built.home = false; NAVS.built.explore = false; }
});

/* ==========================================================================
   ADD TO PLAYLIST
   ========================================================================== */
let PENDING_ADD = [];
function openAddToPlaylist(tracks) {
  PENDING_ADD = arr(tracks).filter(Boolean);
  if (!PENDING_ADD.length) return;
  const pls = LIB.playlists.slice().sort((a, b) => b.updatedAt - a.updatedAt);
  Sheet.open({
    title: 'Add to playlist', cls: 'tall',
    html: `<div class="menu"><button type="button" class="menu-item" data-act="addToNewPl" data-close>${ic('plus')}<span>New playlist</span></button>
      ${pls.map(p => `<button type="button" class="menu-item pl-item" data-act="addToPl" data-plid="${esc(p.id)}" data-close><span class="mini-thumb">${plArt(p)}</span><span>${esc(p.name)}</span><small>${plural(p.tracks.length, 'song')}</small></button>`).join('')}</div>
      ${pls.length ? '' : '<p class="muted hint">You have no playlists yet. Create one above.</p>'}`
  });
}
