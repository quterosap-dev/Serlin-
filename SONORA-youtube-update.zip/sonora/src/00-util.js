/* ==========================================================================
   SONORA — 00 util: DOM helpers, formatting, event bus, icons, toasts
   ========================================================================== */
'use strict';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const uid = (p = 'id') => p + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const now = () => Date.now();
const arr = v => (Array.isArray(v) ? v : []);

function debounce(fn, ms) {
  let t;
  const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  d.cancel = () => clearTimeout(t);
  return d;
}

function throttle(fn, ms) {
  let last = 0, timer = null;
  return (...a) => {
    const n = Date.now();
    if (n - last >= ms) { last = n; fn(...a); }
    else if (!timer) timer = setTimeout(() => { timer = null; last = Date.now(); fn(...a); }, ms - (n - last));
  };
}

/* ---------- formatting ---------- */
function fmtTime(s) {
  if (!isFinite(s) || s < 0) s = 0;
  s = Math.floor(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}` : `${m}:${String(sec).padStart(2, '0')}`;
}
function fmtDur(s) {
  s = Math.round(s || 0);
  const h = Math.floor(s / 3600), m = Math.round((s % 3600) / 60);
  if (h && m) return `${h} hr ${m} min`;
  if (h) return `${h} hr`;
  return `${Math.max(1, m)} min`;
}
function fmtNum(n) {
  n = Number(n) || 0;
  if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace(/\.0$/, '') + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(n >= 1e4 ? 0 : 1).replace(/\.0$/, '') + 'K';
  return String(n);
}
function plural(n, one, many) { return `${n} ${n === 1 ? one : (many || one + 's')}`; }
function fmtBytes(b) {
  if (!b) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return `${b.toFixed(b >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
}
function dayKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function greeting() {
  const h = new Date().getHours();
  if (h < 5) return 'Good night';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

/* ---------- colour helpers (artwork fallbacks, dynamic backgrounds) ---------- */
function hashStr(s) {
  let h = 2166136261;
  s = String(s);
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function hueOf(seed) { return hashStr(seed) % 360; }
function gradFor(seed) {
  const h = hashStr(seed), h1 = h % 360, h2 = (h1 + 38 + ((h >> 8) % 70)) % 360;
  return `linear-gradient(135deg, hsl(${h1} 72% 52%), hsl(${h2} 70% 30%))`;
}
function shuffled(a) {
  const r = a.slice();
  for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; }
  return r;
}
function uniqBy(list, keyFn) {
  const seen = new Set(), out = [];
  for (const x of list) { const k = keyFn(x); if (k == null || seen.has(k)) continue; seen.add(k); out.push(x); }
  return out;
}

/* ---------- event bus ---------- */
const Bus = {
  m: {},
  on(e, f) { (this.m[e] = this.m[e] || []).push(f); return () => this.off(e, f); },
  off(e, f) { this.m[e] = (this.m[e] || []).filter(x => x !== f); },
  emit(e, ...a) { (this.m[e] || []).slice().forEach(f => { try { f(...a); } catch (err) { console.error('[bus]', e, err); } }); }
};

/* ---------- icons (inline sprite lives in the HTML template) ---------- */
const ic = (name, cls = '') => `<svg class="ic ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;

/* ---------- toasts ---------- */
const Toast = {
  el: null,
  show(msg, opts = {}) {
    if (!this.el) this.el = $('#toasts');
    if (!this.el) return;
    const t = document.createElement('div');
    t.className = 'toast' + (opts.kind ? ' ' + opts.kind : '');
    t.innerHTML = `<span class="toast-msg">${esc(msg)}</span>` +
      (opts.action ? `<button class="toast-act" type="button">${esc(opts.action.label)}</button>` : '');
    if (opts.action) t.querySelector('.toast-act').addEventListener('click', () => { t.remove(); opts.action.fn(); });
    while (this.el.children.length >= 3) this.el.firstChild.remove();
    this.el.appendChild(t);
    requestAnimationFrame(() => t.classList.add('in'));
    const ms = opts.ms ?? 3600;
    setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 250); }, ms);
    return t;
  }
};
const toast = (m, o) => Toast.show(m, o);

/* copy text with a fallback for browsers/frames that refuse the async clipboard API */
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); return true; } catch { /* fall through */ }
  try {
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
    document.body.appendChild(ta); ta.select();
    const ok = document.execCommand('copy'); ta.remove(); return ok;
  } catch { return false; }
}

/* read a file and return a downscaled square JPEG data URL (playlist covers) */
async function imageToCover(file, size = 480, q = 0.82) {
  const bmp = await createImageBitmap(file);
  const s = Math.min(bmp.width, bmp.height);
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d');
  g.drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, size, size);
  bmp.close && bmp.close();
  return c.toDataURL('image/jpeg', q);
}
