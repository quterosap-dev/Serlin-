/* ==========================================================================
   SONORA — 08 library views: Library, playlists, albums/mixes, artists,
   Settings, Listening stats
   ========================================================================== */

/* ---------- shared bits ---------- */
function heroDetail({ art, eyebrow, title, desc = '', meta = '', byHtml = '' }) {
  return `<div class="hero-detail"><div class="hero-art">${art}</div><div class="hero-text">
    <span class="eyebrow">${esc(eyebrow)}</span><h1 class="hero-title">${esc(title)}</h1>
    ${byHtml}${desc ? `<p class="hero-desc">${esc(desc)}</p>` : ''}<p class="hero-meta">${esc(meta)}</p></div></div>`;
}
const likedArt = () => `<div class="art liked-art"><span class="art-ch">${ic('heart')}</span></div>`;
function sortTracks(list, s) {
  if (s === 'az') return list.slice().sort((a, b) => a.title.localeCompare(b.title));
  if (s === 'artist') return list.slice().sort((a, b) => a.artist.localeCompare(b.artist) || a.title.localeCompare(b.title));
  return list;
}
const sumDur = tracks => tracks.reduce((n, t) => n + (t.dur || 0), 0);
function plCard(p) {
  const n = p.tracks.length;
  return `<div class="card" data-act="openPlaylist" data-id="${esc(p.id)}" role="button" tabindex="0" aria-label="Open playlist ${esc(p.name)}">
    <div class="card-art">${plArt(p)}<span class="card-play">${ic('play')}</span></div>
    <div class="card-title">${esc(p.name)}</div><div class="card-sub">Playlist · ${plural(n, 'song')}</div></div>`;
}

/* ==========================================================================
   LIBRARY
   ========================================================================== */
const LST = { tab: 'playlists', sort: 'recent', q: '' };
const LIB_TABS = [['playlists', 'Playlists'], ['liked', 'Liked songs'], ['albums', 'Albums'], ['artists', 'Artists'], ['recent', 'Recent'], ['downloads', 'Downloads'], ['local', 'On device']];
const TRACK_TABS = ['liked', 'downloads', 'local'];

function buildLibrary(el) {
  el.innerHTML = `
    ${topbar({ title: 'Your Library', actions: `<button class="icon-btn" type="button" data-act="libAdd" aria-label="Create or add">${ic('plus')}</button><button class="icon-btn" type="button" data-act="openStats" aria-label="Listening stats">${ic('chart')}</button>` })}
    <div class="chips scroll" id="lib-tabs" role="tablist"></div>
    <div class="toolbar"><div class="search-field small">${ic('search')}<input id="lib-filter" type="search" autocomplete="off" placeholder="Filter this list" aria-label="Filter library" value="${esc(LST.q)}"></div><div class="chips" id="lib-sort" aria-label="Sort"></div></div>
    <div class="pad" id="lib-body"></div>`;
  $('#lib-filter', el).addEventListener('input', e => { LST.q = e.target.value; renderLibBody(); });
  renderLibTabs(); renderLibBody();
}
function renderLibTabs() {
  const t = $('#lib-tabs'); if (!t) return;
  t.innerHTML = LIB_TABS.map(([k, l]) => `<button type="button" role="tab" class="chip ${LST.tab === k ? 'on' : ''}" data-act="libTab" data-tab="${k}" aria-selected="${LST.tab === k}">${l}</button>`).join('');
  const s = $('#lib-sort');
  const opts = TRACK_TABS.includes(LST.tab) ? [['recent', 'Recent'], ['az', 'A–Z'], ['artist', 'Artist']] : (['playlists', 'albums', 'artists'].includes(LST.tab) ? [['recent', 'Recent'], ['az', 'A–Z']] : []);
  if (opts.length && !opts.some(o => o[0] === LST.sort)) LST.sort = 'recent';
  s.innerHTML = opts.map(([k, l]) => `<button type="button" class="chip small ${LST.sort === k ? 'on' : ''}" data-act="libSort" data-sort="${k}" aria-pressed="${LST.sort === k}">${l}</button>`).join('');
  const f = $('#lib-filter'); if (f) f.closest('.toolbar').classList.toggle('no-sort', !opts.length);
}
function renderLibBody() {
  const body = $('#lib-body'); if (!body) return;
  const q = LST.q.trim().toLowerCase(), tab = LST.tab;
  const hit = (...f) => !q || f.join(' ').toLowerCase().includes(q);
  const trackList = (tracks, name, empty) => {
    let list = tracks.filter(t => hit(t.title, t.artist, t.album || ''));
    list = sortTracks(list, LST.sort);
    if (!list.length) return q ? emptyState({ icon: 'search', title: 'No matches', text: `Nothing in this list matches “${LST.q}”.` }) : empty;
    const key = regList(list, { type: 'library', name });
    return `<div class="action-row"><button type="button" class="btn primary" data-act="playAll" data-list="${key}">${ic('play')} Play</button><button type="button" class="btn ghost" data-act="shuffleAll" data-list="${key}">${ic('shuffle')} Shuffle</button><span class="muted count">${plural(list.length, 'song')} · ${fmtDur(sumDur(list))}</span></div>
      <div class="rows" data-list="${key}">${list.map((t, i) => trackRow(t, { list: key, i })).join('')}</div>`;
  };
  if (tab === 'playlists') {
    let pls = LIB.playlists.filter(p => hit(p.name, p.desc));
    let saved = LIB.savedLists.filter(l => l.kind === 'playlist' && hit(l.name, l.artist));
    if (LST.sort === 'az') { pls = pls.slice().sort((a, b) => a.name.localeCompare(b.name)); saved = saved.slice().sort((a, b) => a.name.localeCompare(b.name)); }
    else pls = pls.slice().sort((a, b) => b.updatedAt - a.updatedAt);
    const likedCard = hit('liked songs') ? `<div class="card" data-act="openPlaylist" data-id="liked" role="button" tabindex="0" aria-label="Open Liked songs"><div class="card-art">${likedArt()}<span class="card-play">${ic('play')}</span></div><div class="card-title">Liked songs</div><div class="card-sub">Playlist · ${plural(LIB.liked.length, 'song')}</div></div>` : '';
    const newCard = q ? '' : `<button type="button" class="card new-card" data-act="plNew" aria-label="Create a new playlist"><div class="card-art"><div class="art new-art">${ic('plus')}</div></div><div class="card-title">New playlist</div><div class="card-sub">Name it, add a cover</div></button>`;
    body.innerHTML = `<div class="grid-cards">${newCard}${likedCard}${pls.map(plCard).join('')}${saved.map(listCard).join('')}</div>` +
      (!LIB.playlists.length && !q ? `<p class="muted hint">Create a playlist, then add songs from any song’s ⋯ menu.</p>` : '');
  } else if (tab === 'liked') {
    body.innerHTML = trackList(LIB.liked.map(x => x.t), 'Liked songs', emptyState({ icon: 'heart', title: 'No liked songs yet', text: 'Tap the heart on any song to keep it here.', action: { label: 'Find music', act: 'tab', data: { tab: 'search' } } }));
  } else if (tab === 'albums') {
    let l = LIB.savedLists.filter(x => x.kind === 'album' && hit(x.name, x.artist));
    if (LST.sort === 'az') l = l.slice().sort((a, b) => a.name.localeCompare(b.name));
    body.innerHTML = l.length ? `<div class="grid-cards">${l.map(listCard).join('')}</div>` : emptyState({ icon: 'disc', title: q ? 'No matches' : 'No saved albums', text: q ? '' : 'Open an album and tap Save to keep it here.', action: q ? null : { label: 'Browse albums', act: 'openCat', data: { cat: 'cat:albums' } } });
  } else if (tab === 'artists') {
    let a = LIB.followed.filter(x => hit(x.name));
    if (LST.sort === 'az') a = a.slice().sort((x, y) => x.name.localeCompare(y.name));
    body.innerHTML = a.length ? `<div class="grid-cards">${a.map(artistCard).join('')}</div>` : emptyState({ icon: 'user', title: q ? 'No matches' : 'No followed artists', text: q ? '' : 'Follow an artist from their page.', action: q ? null : { label: 'Popular artists', act: 'openCat', data: { cat: 'cat:artists' } } });
  } else if (tab === 'recent') {
    const list = uniqBy(LIB.history.map(x => x.t), t => t.id).filter(t => hit(t.title, t.artist));
    if (!list.length) { body.innerHTML = q ? emptyState({ icon: 'search', title: 'No matches' }) : emptyState({ icon: 'clock', title: 'Nothing played yet', text: 'Your listening history appears here.' }); return; }
    const key = regList(list, { type: 'library', name: 'Recently played' });
    body.innerHTML = `<div class="action-row"><button type="button" class="btn primary" data-act="playAll" data-list="${key}">${ic('play')} Play</button><button type="button" class="btn ghost" data-act="clearHistory">${ic('trash')} Clear history</button></div>
      <div class="rows" data-list="${key}">${list.map((t, i) => trackRow(t, { list: key, i })).join('')}</div>`;
  } else if (tab === 'downloads') {
    body.innerHTML = trackList(LIB.downloads, 'Downloads', emptyState({ icon: 'download', title: 'No downloads', text: 'Some artists on Audius allow downloads. When they do, a song’s ⋯ menu shows “Save for offline”. Songs that aren’t downloadable can only be streamed.' }));
  } else if (tab === 'local') {
    const supportsDir = 'webkitdirectory' in document.createElement('input');
    const empty = emptyState({ icon: 'folder', title: 'Play music from this device', text: 'Choose MP3, WAV, FLAC, M4A or other audio files. They stay on your device. SONORA never uploads them.', action: { label: 'Choose files', act: 'addLocal' } });
    if (!LOCAL.length) { body.innerHTML = empty; return; }
    const bar = `<div class="action-row"><button type="button" class="btn ghost" data-act="addLocal">${ic('upload')} Add music</button>${supportsDir ? `<button type="button" class="btn ghost" data-act="addFolder">${ic('folder')} Add folder</button>` : ''}
      <span class="muted count">${LOCAL.length ? plural(LOCAL.length, 'song') + ' · ' + fmtBytes(LOCAL.reduce((n, t) => n + (t.size || 0), 0)) : ''}</span></div>`;
    const sess = LOCAL.some(t => t.session) ? `<p class="notice-inline">${ic('info')} Some files are only held for this session${PREFS.rememberLocal ? ' because device storage was unavailable or full' : ' because “Remember local music” is off'}.</p>` : '';
    body.innerHTML = bar + sess + trackList(LOCAL, 'On this device', empty);
  }
}

/* ==========================================================================
   PLAYLIST (user) + Liked songs
   ========================================================================== */
function buildPlaylist(el, { id }) {
  let reorder = false;
  const get = () => id === 'liked'
    ? { id: 'liked', name: 'Liked songs', desc: '', cover: '', tracks: LIB.liked.map(x => x.t), virtual: true }
    : Lib.playlist(id);
  const render = () => {
    const y = el.scrollTop, p = get();
    if (!p) { el.innerHTML = topbar({ back: true }) + `<div class="pad">${emptyState({ icon: 'music', title: 'Playlist not found', text: 'It may have been deleted.' })}</div>`; return; }
    const n = p.tracks.length, ctx = { type: 'playlist', id: p.id, name: p.name };
    const key = regList(p.tracks, ctx);
    el.innerHTML = `${topbar({ back: true, actions: p.virtual ? '' : `<button class="icon-btn" type="button" data-act="plEdit" data-id="${esc(p.id)}" aria-label="Edit playlist details">${ic('edit')}</button><button class="icon-btn" type="button" data-act="plMenu" data-id="${esc(p.id)}" aria-label="Playlist options">${ic('more')}</button>` })}
      <div class="pad">${heroDetail({ art: p.virtual ? likedArt() : plArt(p), eyebrow: 'Playlist', title: p.name, desc: p.desc, meta: `${plural(n, 'song')}${n ? ' · ' + fmtDur(sumDur(p.tracks)) : ''}` })}
      <div class="action-row">
        <button type="button" class="btn primary" data-act="playAll" data-list="${key}" ${n ? '' : 'disabled'}>${ic('play')} Play</button>
        <button type="button" class="btn ghost" data-act="shuffleAll" data-list="${key}" ${n ? '' : 'disabled'}>${ic('shuffle')} Shuffle</button>
        ${p.virtual ? '' : `<button type="button" class="btn ghost" data-act="plAddSongs" data-id="${esc(p.id)}">${ic('plus')} Add songs</button>`}
        ${!p.virtual && n > 1 ? `<button type="button" class="btn ghost ${reorder ? 'on' : ''}" data-act="plReorder" aria-pressed="${reorder}">${ic('grip')} ${reorder ? 'Done' : 'Reorder'}</button>` : ''}
      </div>
      ${n ? `<div class="rows ${reorder ? 'reorder' : ''}" data-list="${key}">${p.tracks.map((t, i) => trackRow(t, { list: key, i, plid: p.virtual ? '' : p.id, grip: reorder })).join('')}</div>`
        : emptyState({ icon: 'music', title: p.virtual ? 'No liked songs yet' : 'This playlist is empty', text: p.virtual ? 'Tap the heart on any song.' : 'Add songs from search, or from any song’s ⋯ menu.', action: p.virtual ? null : { label: 'Add songs', act: 'plAddSongs', data: { id: p.id } } })}
      </div>`;
    el.scrollTop = y;
    if (reorder && !p.virtual) makeSortable($('.rows', el), (from, to) => Lib.moveInPlaylist(p.id, from, to));
  };
  el._toggleReorder = () => { reorder = !reorder; render(); };
  render();
  watch(el, 'lib', k => { if (['playlists', 'liked', 'all', 'local'].includes(k)) render(); });
  watch(el, 'player:track', () => { /* row highlight handled globally */ });
}

/* "Add songs" sheet: search + your library, tap + to add */
function openAddSongs(plid) {
  const p = Lib.playlist(plid); if (!p) return;
  let seq = 0;
  Sheet.open({
    title: `Add to ${p.name}`, cls: 'tall',
    html: `<div class="search-field">${ic('search')}<input id="addsongs-q" type="search" autocomplete="off" placeholder="Search songs to add" aria-label="Search songs to add"></div><div id="addsongs-res" class="rows"></div>`,
    onMount: body => {
      const resBox = $('#addsongs-res', body), inp = $('#addsongs-q', body);
      const draw = (tracks, note) => {
        const have = new Set((Lib.playlist(plid) || { tracks: [] }).tracks.map(t => t.id));
        const key = regList(tracks, { type: 'search' });
        resBox.innerHTML = (note ? `<p class="muted">${esc(note)}</p>` : '') + tracks.map((t, i) => `<div class="row" data-tid="${esc(t.id)}">
          <div class="row-art-wrap">${artEl(t, 'sm', 'row-art')}</div>
          <div class="row-main"><div class="row-title">${esc(t.title)}</div><div class="row-sub"><span>${esc(t.artist)}</span></div></div>
          <button type="button" class="btn small ${have.has(t.id) ? 'ghost on' : 'primary'}" data-act="addSongTo" data-tid="${esc(t.id)}" data-plid="${esc(plid)}" ${have.has(t.id) ? 'disabled' : ''}>${have.has(t.id) ? 'Added' : 'Add'}</button></div>`).join('');
      };
      const lib = uniqBy([...LOCAL, ...LIB.liked.map(x => x.t), ...LIB.history.map(x => x.t)], t => t.id).slice(0, 12);
      draw(lib, lib.length ? 'From your library. Search to find more.' : 'Type to search.');
      const run = debounce(async q => {
        const my = ++seq; if (!q) { draw(lib, 'From your library. Search to find more.'); return; }
        resBox.innerHTML = skelRows(4);
        const r = await searchAll(q);
        if (my !== seq) return;
        const mine = libraryMatches(q).tracks;
        const all = uniqBy([...mine, ...r.tracks], t => t.id).slice(0, 40);
        if (!all.length) resBox.innerHTML = r.errors.length ? errorState({ kind: r.errors[0].kind, message: r.errors[0].msg }) : emptyState({ icon: 'search', title: 'No songs found' });
        else draw(all);
      }, 300);
      inp.addEventListener('input', () => run(inp.value.trim()));
      watch(body, 'lib', k => { if (k === 'playlists') { const cur = $$('[data-act="addSongTo"]', body); const p2 = Lib.playlist(plid); if (!p2) return; const have = new Set(p2.tracks.map(t => t.id)); cur.forEach(b => { if (have.has(b.dataset.tid)) { b.disabled = true; b.textContent = 'Added'; b.className = 'btn small ghost on'; } }); } });
    }
  });
}

/* create / edit playlist dialog with optional cover upload */
async function playlistDialog(existing) {
  let cover = existing ? existing.cover : '';
  const res = await askText({
    title: existing ? 'Edit playlist' : 'New playlist', label: 'Name', value: existing ? existing.name : '', placeholder: 'My playlist', okLabel: existing ? 'Save' : 'Create',
    extra: `<label class="field-label" for="ask-desc">Description (optional)</label><textarea id="ask-desc" class="field" rows="2" maxlength="300" placeholder="What is this playlist for?">${esc(existing ? existing.desc : '')}</textarea>
      <div class="cover-pick"><div class="cover-prev" id="cover-prev">${cover ? `<img src="${esc(cover)}" alt="">` : ic('music')}</div>
      <div><button type="button" class="btn ghost small" id="cover-btn">${ic('upload')} ${cover ? 'Change cover' : 'Add cover image'}</button>
      <button type="button" class="btn ghost small" id="cover-clear" ${cover ? '' : 'hidden'}>Remove</button><input type="file" id="cover-file" accept="image/*" hidden></div></div>`,
    onMount: body => {
      const file = $('#cover-file', body), prev = $('#cover-prev', body), clr = $('#cover-clear', body);
      $('#cover-btn', body).addEventListener('click', () => file.click());
      clr.addEventListener('click', () => { cover = ''; prev.innerHTML = ic('music'); clr.hidden = true; });
      file.addEventListener('change', async () => {
        if (!file.files[0]) return;
        try { cover = await imageToCover(file.files[0]); prev.innerHTML = `<img src="${cover}" alt="">`; clr.hidden = false; }
        catch { toast('That image couldn’t be read. Try a JPEG or PNG.', { kind: 'warn' }); }
      });
    }
  });
  if (!res) return null;
  return { name: res.value, desc: $('#ask-desc', res.root) ? $('#ask-desc', res.root).value : '', cover };
}

/* ==========================================================================
   ALBUM / PLAYLIST (Audius) and Daily Mix
   ========================================================================== */
function buildListView(el, { id }) {
  const e = ENT.get(id) || LIB.savedLists.find(x => x.id === id);
  if (!e) { el.innerHTML = topbar({ back: true }) + `<div class="pad">${emptyState({ icon: 'disc', title: 'Not found', text: 'Open it again from Home or Search.' })}</div>`; return; }
  rememberEnt(e);
  if (e.kind !== 'mix') Lib.addRecentItem(e.kind, e);
  const isMix = e.kind === 'mix';
  let tracks = isMix ? e.tracks : null, err = null;
  const draw = () => {
    const y = el.scrollTop;
    const saved = !isMix && Lib.isSavedList(e.id);
    const eyebrow = isMix ? 'Made for you' : e.kind === 'album' ? 'Album' : 'Playlist';
    const key = tracks ? regList(tracks, { type: 'list', id: e.id, name: e.name }) : '';
    const by = e.artist ? `<p class="hero-by">By ${e.artistId ? `<button type="button" class="link-btn" data-act="openArtistById" data-aid="${esc(e.artistId)}" data-name="${esc(e.artist)}">${esc(e.artist)}</button>` : esc(e.artist)}</p>` : '';
    el.innerHTML = `${topbar({ back: true })}
      <div class="pad">${heroDetail({ art: isMix ? mixArt(e) : artEl(e, 'lg'), eyebrow, title: e.name, desc: isMix ? `${e.personal ? 'Built from your listening' : 'A starter mix from popular ' + e.genre + ' tracks'}. Generated on this device.` : e.desc, byHtml: by, meta: tracks ? `${plural(tracks.length, 'song')}${sumDur(tracks) ? ' · ' + fmtDur(sumDur(tracks)) : ''}` : (e.count ? plural(e.count, 'song') : '') })}
      <div class="action-row">
        <button type="button" class="btn primary" data-act="playAll" data-list="${key}" ${tracks && tracks.length ? '' : 'disabled'}>${ic('play')} Play</button>
        <button type="button" class="btn ghost" data-act="shuffleAll" data-list="${key}" ${tracks && tracks.length ? '' : 'disabled'}>${ic('shuffle')} Shuffle</button>
        ${isMix ? `<button type="button" class="btn ghost" data-act="saveMix" data-eid="${esc(e.id)}">${ic('plus')} Save as playlist</button>`
          : `<button type="button" class="btn ghost ${saved ? 'on' : ''}" data-act="saveList" data-eid="${esc(e.id)}" aria-pressed="${saved}">${ic('heart')} ${saved ? 'Saved' : 'Save'}</button>
             <button type="button" class="btn ghost" data-act="copyToPlaylist" data-eid="${esc(e.id)}" data-list="${key}" ${tracks && tracks.length ? '' : 'disabled'}>${ic('list')} Copy to my playlist</button>`}
      </div>
      ${err ? errorState(err, { act: 'retryList', data: { eid: e.id } }) : tracks === null ? skelRows(8)
        : tracks.length ? `<div class="rows" data-list="${key}">${tracks.map((t, i) => trackRow(t, { list: key, i, numbered: !isMix && e.kind === 'album' })).join('')}</div>`
          : emptyState({ icon: 'music', title: 'No tracks', text: 'This list has no playable tracks right now.' })}
      ${e.perm ? `<p class="attrib"><a href="${esc(e.perm)}" target="_blank" rel="noopener">Open on Audius</a></p>` : ''}</div>`;
    el.scrollTop = y;
  };
  el._reload = async () => {
    err = null; tracks = null; draw();
    try { tracks = await Audius.listTracks(e.rid); } catch (x) { err = x; }
    if (el.isConnected) draw();
  };
  draw();
  if (!isMix) el._reload();
  watch(el, 'lib', k => { if (k === 'saved') draw(); });
}

/* ==========================================================================
   ARTIST
   ========================================================================== */
function buildArtist(el, { id }) {
  let a = ENT.get(id) || LIB.followed.find(x => x.id === id);
  if (!a) { el.innerHTML = topbar({ back: true }) + `<div class="pad">${emptyState({ icon: 'user', title: 'Artist not found' })}</div>`; return; }
  rememberEnt(a);
  Lib.addRecentItem('artist', { id: a.id, rid: a.rid, src: a.src, name: a.name, handle: a.handle, img150: a.img150, img480: a.img480, followers: a.followers });
  let tracks = null, err = null;
  const draw = () => {
    const y = el.scrollTop, following = Lib.isFollowing(a.id);
    const key = tracks ? regList(tracks, { type: 'artist', id: a.id, name: a.name }) : '';
    el.innerHTML = `${topbar({ back: true })}
      <div class="pad"><div class="hero-detail artist-hero"><div class="hero-art round">${artEl({ id: a.id, name: a.name, img150: a.img150, img480: a.img480 }, 'lg', 'round')}</div>
        <div class="hero-text"><span class="eyebrow">Artist</span><h1 class="hero-title">${esc(a.name)}</h1>
        <p class="hero-meta">${a.followers ? fmtNum(a.followers) + ' followers' : ''}${a.handle ? (a.followers ? ' · ' : '') + '@' + esc(a.handle) : ''}</p></div></div>
      <div class="action-row">
        <button type="button" class="btn primary" data-act="playAll" data-list="${key}" ${tracks && tracks.length ? '' : 'disabled'}>${ic('play')} Play</button>
        <button type="button" class="btn ghost" data-act="shuffleAll" data-list="${key}" ${tracks && tracks.length ? '' : 'disabled'}>${ic('shuffle')} Shuffle</button>
        <button type="button" class="btn ghost ${following ? 'on' : ''}" data-act="followArtist" data-aid="${esc(a.id)}" aria-pressed="${following}">${ic(following ? 'check' : 'plus')} ${following ? 'Following' : 'Follow'}</button></div>
      <section class="sec">${sectionHead('Popular tracks')}
      ${err ? errorState(err, { act: 'retryArtist', data: { aid: a.id } }) : tracks === null ? skelRows(6)
        : tracks.length ? `<div class="rows" data-list="${key}">${tracks.map((t, i) => trackRow(t, { list: key, i })).join('')}</div>` : emptyState({ icon: 'music', title: 'No tracks found', text: 'This artist has no playable tracks right now.' })}</section>
      ${a.perm || a.handle ? `<p class="attrib"><a href="${esc(a.perm || 'https://audius.co/' + a.handle)}" target="_blank" rel="noopener">Open on Audius</a></p>` : ''}</div>`;
    el.scrollTop = y;
  };
  el._reload = async () => {
    err = null; tracks = null; draw();
    try {
      tracks = a.src === 'jamendo' ? await Jamendo.tracks({ artist_id: a.rid, order: 'popularity_total', limit: 25 }) : await Audius.userTracks(a.rid, { limit: 30 });
      if (a.src === 'audius') Audius.user(a.rid).then(u => { if (u && el.isConnected) { a = { ...a, ...u, id: a.id }; rememberEnt(a); draw(); } }).catch(() => { });
    } catch (x) { err = x; }
    if (el.isConnected) draw();
  };
  draw(); el._reload();
  watch(el, 'lib', k => { if (k === 'followed') draw(); });
}

/* ==========================================================================
   SETTINGS
   ========================================================================== */
const ACCENTS = [['ember', 'Ember', '#ff6a3d'], ['iris', 'Iris', '#8f7cff'], ['lagoon', 'Lagoon', '#2fd1b4'], ['sun', 'Sun', '#ffb21e']];
const setRow = (label, desc, ctl, id = '') => `<div class="set-row" ${id ? `id="${id}"` : ''}><div class="set-text"><div class="set-label">${label}</div>${desc ? `<div class="set-desc">${desc}</div>` : ''}</div><div class="set-ctl">${ctl}</div></div>`;
const toggleCtl = (pref, on, label) => `<button type="button" role="switch" class="switch ${on ? 'on' : ''}" aria-checked="${on}" aria-label="${esc(label)}" data-act="togglePref" data-pref="${pref}"><i></i></button>`;
const segCtl = (pref, opts, cur) => `<div class="seg" role="group">${opts.map(([v, l]) => `<button type="button" class="${String(cur) === String(v) ? 'on' : ''}" data-act="setPref" data-pref="${pref}" data-val="${v}" aria-pressed="${String(cur) === String(v)}">${l}</button>`).join('')}</div>`;

function buildSettings(el) {
  const draw = () => {
    const y = el.scrollTop;
    el.innerHTML = `${topbar({ back: true, title: 'Settings' })}<div class="pad settings">
      <section class="set-sec"><h2>Appearance</h2>
        ${setRow('Theme', '', segCtl('theme', [['dark', 'Dark'], ['light', 'Light'], ['system', 'System']], PREFS.theme))}
        ${setRow('Accent colour', '', `<div class="swatches" role="group" aria-label="Accent colour">${ACCENTS.map(([k, l, c]) => `<button type="button" class="swatch ${PREFS.accent === k ? 'on' : ''}" style="--c:${c}" data-act="setPref" data-pref="accent" data-val="${k}" aria-label="${l}" aria-pressed="${PREFS.accent === k}"></button>`).join('')}</div>`)}
      </section>
      <section class="set-sec"><h2>Playback</h2>
        ${setRow('Sound', 'Equalizer and playback speed', `<button type="button" class="btn ghost small" data-act="openSound">${ic('sliders')} Open</button>`)}
        ${setRow('Crossfade', 'Blend the end of one song into the next. Off in Data saver.', `<div class="range-wrap"><input type="range" min="0" max="12" step="1" value="${PREFS.crossfade}" data-range="crossfade" aria-label="Crossfade seconds"><output id="cf-out">${PREFS.crossfade ? PREFS.crossfade + ' s' : 'Off'}</output></div>`)}
        ${setRow('Skip unavailable tracks', 'Automatically move on when a track can’t be played', toggleCtl('autoSkip', PREFS.autoSkip, 'Skip unavailable tracks'))}
        ${setRow('Data saver', 'Smaller artwork and no preloading. Audius sends one audio quality, so audio data use doesn’t change.', toggleCtl('dataSaver', PREFS.dataSaver, 'Data saver'))}
        ${setRow('Sleep timer', Sleep.mode ? (Sleep.mode === 'track' ? 'Stops after this track' : `Stops in ${fmtDur(Sleep.remaining() / 1000)}`) : 'Stop playback after a set time', `<button type="button" class="btn ghost small" data-act="openSleep">${ic('moon')} ${Sleep.mode ? 'Change' : 'Set'}</button>`)}
      </section>
      <section class="set-sec"><h2>Music sources</h2>
        ${setRow('Audius', 'Primary source. Free, no account needed. Every play counts for the artist.', '<span class="pill ok">On</span>')}
        ${setRow('Audius server', 'Advanced. Leave as is unless Audius asks you to change it.', `<input class="field small" type="url" inputmode="url" data-field="audiusHost" value="${esc(PREFS.audiusHost)}" aria-label="Audius API server">`)}
        ${setRow('Jamendo', 'Free Creative Commons music. Needs a free client ID from <a href="https://devportal.jamendo.com" target="_blank" rel="noopener">devportal.jamendo.com</a>. Songs only. Check Jamendo’s terms before sharing your build.', toggleCtl('useJamendo', PREFS.useJamendo, 'Use Jamendo'))}
        ${PREFS.useJamendo ? setRow('Jamendo client ID', PREFS.jamendoId ? 'Saved on this device only.' : 'Paste your client ID to switch Jamendo on.', `<input class="field small" type="text" autocomplete="off" spellcheck="false" data-field="jamendoId" value="${esc(PREFS.jamendoId)}" placeholder="e.g. 1a2b3c4d" aria-label="Jamendo client ID">`) : ''}
        ${setRow('Internet Archive', 'Experimental. Searches Creative Commons and public-domain audio. Not verified against the live service.', toggleCtl('useArchive', PREFS.useArchive, 'Use Internet Archive'))}
      </section>
      <section class="set-sec"><h2>Your data</h2>
        ${setRow('Remember local music', 'Keep imported files in this browser’s storage so they’re there next time. They’re copies and never leave your device.', toggleCtl('rememberLocal', PREFS.rememberLocal, 'Remember local music'))}
        ${setRow('Storage used', '', '<span id="storage-est" class="muted">Checking…</span>')}
        ${setRow('Back up or move your library', 'Playlists, likes, follows and saved albums as a JSON file or text.', `<div class="btn-pair"><button type="button" class="btn ghost small" data-act="exportLib">${ic('download')} Export</button><button type="button" class="btn ghost small" data-act="importLib">${ic('upload')} Import</button></div>`)}
        ${setRow('Search history', `${plural(LIB.searches.length, 'search', 'searches')} saved`, `<button type="button" class="btn ghost small" data-act="searchClearHistory">Clear</button>`)}
        ${setRow('Listening history and stats', `${plural(LIB.history.length, 'entry', 'entries')} · ${fmtDur(LIB.stats.seconds)} listened`, `<div class="btn-pair"><button type="button" class="btn ghost small" data-act="openStats">View</button><button type="button" class="btn ghost small danger" data-act="resetListening">Reset</button></div>`)}
        ${setRow('Delete everything', 'Removes playlists, likes, history, settings and local music from this device.', `<button type="button" class="btn danger small" data-act="wipeAll">${ic('trash')} Delete all</button>`)}
        ${LS.ok ? '' : `<p class="notice-inline warn">${ic('alert')} Browser storage is blocked here, so nothing will be kept after you close SONORA.</p>`}
      </section>
      <section class="set-sec"><h2>Account</h2>
        <div class="account-card"><div class="avatar">${ic('user')}</div><div><div class="set-label">Using SONORA without an account</div>
        <div class="set-desc">Everything is stored on this device. Accounts are planned for a later version: email and Google sign-in, profiles, playlists saved in the cloud, sync across devices and listening history. They’ll use a free-tier backend such as Supabase or Firebase. See the architecture notes for limits and setup.</div></div></div>
        <div class="btn-pair stack"><button type="button" class="btn ghost" disabled aria-disabled="true">Sign in with email (coming later)</button><button type="button" class="btn ghost" disabled aria-disabled="true">Continue with Google (coming later)</button></div>
      </section>
      <section class="set-sec"><h2>Keyboard shortcuts</h2><dl class="keys">
        <div><dt>Space</dt><dd>Play / pause</dd></div><div><dt>← →</dt><dd>Seek 5 seconds</dd></div><div><dt>Shift + ← →</dt><dd>Previous / next</dd></div>
        <div><dt>↑ ↓</dt><dd>Volume</dd></div><div><dt>M</dt><dd>Mute</dd></div><div><dt>L</dt><dd>Like current song</dd></div>
        <div><dt>S / R</dt><dd>Shuffle / repeat</dd></div><div><dt>N / Q</dt><dd>Now playing / queue</dd></div>
        <div><dt>/</dt><dd>Search</dd></div><div><dt>Esc</dt><dd>Close / go back</dd></div></dl></section>
      <section class="set-sec"><h2>About</h2>
        <p class="set-desc">SONORA 1.0 · a free, open web music app.</p>
        <p class="set-desc">Streaming from <a href="https://audius.co" target="_blank" rel="noopener">Audius</a> through its public API. Optional: <a href="https://www.jamendo.com" target="_blank" rel="noopener">Jamendo</a> and the <a href="https://archive.org" target="_blank" rel="noopener">Internet Archive</a>. Audio and artwork belong to their artists. SONORA is not affiliated with any of these services.</p>
        <p class="set-desc">Lyrics: no licensed lyrics service is connected. You can attach your own .lrc or text lyrics to a song.</p></section>
    </div>`;
    el.scrollTop = y;
    if (navigator.storage && navigator.storage.estimate) navigator.storage.estimate().then(e => { const s = $('#storage-est', el); if (s) s.textContent = `${fmtBytes(e.usage || 0)}${e.quota ? ' of ' + fmtBytes(e.quota) + ' available' : ''}`; }).catch(() => { const s = $('#storage-est', el); if (s) s.textContent = 'Unknown'; });
    else { const s = $('#storage-est', el); if (s) s.textContent = 'Unknown'; }
  };
  draw();
  watch(el, 'pref', k => { if (k !== 'volume' && k !== 'muted' && k !== 'speed' && k !== 'shuffle' && k !== 'repeat' && k !== 'eq') draw(); });
  watch(el, 'lib', k => { if (['searches', 'history', 'stats', 'all'].includes(k)) draw(); });
  watch(el, 'sleep', draw);
}

/* ==========================================================================
   LISTENING STATS
   ========================================================================== */
function buildStats(el) {
  const draw = () => {
    const s = LIB.stats, days = [];
    for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push({ k: dayKey(d), label: d.toLocaleDateString(undefined, { weekday: 'short' }), sec: s.byDay[dayKey(d)] || 0 }); }
    const max = Math.max(60, ...days.map(d => d.sec));
    const topA = Object.entries(s.artists).sort((a, b) => b[1].n - a[1].n).slice(0, 5);
    const topG = Object.entries(s.genres).sort((a, b) => b[1] - a[1]).slice(0, 5);
    const none = !s.seconds && !s.plays;
    const bars = (rows, fmt) => { const m = Math.max(1, ...rows.map(r => r[1])); return `<ul class="hbars">${rows.map(([k, v]) => `<li><span class="hb-label">${esc(k)}</span><span class="hb-track"><i style="width:${(v / m) * 100}%"></i></span><span class="hb-val">${fmt(v)}</span></li>`).join('')}</ul>`; };
    el.innerHTML = `${topbar({ back: true, title: 'Listening stats' })}<div class="pad">
      ${none ? emptyState({ icon: 'chart', title: 'No listening yet', text: 'Play some music and your stats will build up here. They stay on this device.' }) : `
      <div class="stat-grid">
        <div class="stat"><span class="stat-n">${fmtDur(s.seconds)}</span><span class="stat-l">Time listened</span></div>
        <div class="stat"><span class="stat-n">${s.plays}</span><span class="stat-l">Songs played</span></div>
        <div class="stat"><span class="stat-n">${LIB.liked.length}</span><span class="stat-l">Liked songs</span></div>
        <div class="stat"><span class="stat-n">${LIB.playlists.length}</span><span class="stat-l">Playlists</span></div></div>
      <section class="sec">${sectionHead('Last 7 days')}<div class="daybars" role="img" aria-label="Minutes listened per day">${days.map(d => `<div class="db"><div class="db-col"><i style="height:${Math.max(2, d.sec / max * 100)}%" title="${Math.round(d.sec / 60)} min"></i></div><span class="db-min">${Math.round(d.sec / 60)}</span><span class="db-day">${d.label}</span></div>`).join('')}</div><p class="muted">Minutes listened per day.</p></section>
      ${topA.length ? `<section class="sec">${sectionHead('Top artists')}${bars(topA.map(([k, v]) => [k, v.n]), v => plural(v, 'play'))}</section>` : ''}
      ${topG.length ? `<section class="sec">${sectionHead('Top genres')}${bars(topG, v => plural(v, 'play'))}</section>` : ''}`}</div>`;
  };
  draw(); watch(el, 'lib', k => { if (k === 'stats' || k === 'all') draw(); });
}

TAB_BUILDERS.library = buildLibrary;
VIEW_BUILDERS.playlist = buildPlaylist;
VIEW_BUILDERS.list = buildListView;
VIEW_BUILDERS.artist = buildArtist;
VIEW_BUILDERS.settings = buildSettings;
VIEW_BUILDERS.stats = buildStats;
