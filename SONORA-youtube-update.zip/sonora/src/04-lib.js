/* ==========================================================================
   SONORA — 04 library operations (likes, playlists, follows, history, stats)
   All mutations stamp updatedAt, write tombstones for deletions, save, and
   emit 'lib' so the UI can refresh. No UI code in here.
   ========================================================================== */

const Lib = {
  touch(kind) { LIB.updatedAt = now(); saveLib(); Bus.emit('lib', kind); },
  tomb(type, id) { LIB.tombstones.push({ type, id, at: now() }); if (LIB.tombstones.length > 500) LIB.tombstones.shift(); },

  /* ----- likes ----- */
  isLiked(t) { return !!t && LIB.liked.some(x => x.t.id === t.id); },
  toggleLike(t) {
    if (!t) return false;
    const i = LIB.liked.findIndex(x => x.t.id === t.id);
    if (i >= 0) { LIB.liked.splice(i, 1); this.tomb('like', t.id); this.touch('liked'); return false; }
    LIB.liked.unshift({ t: slim(t), at: now() });
    this.touch('liked');
    return true;
  },

  /* ----- playlists ----- */
  playlist(id) { return LIB.playlists.find(p => p.id === id); },
  createPlaylist({ name, desc = '', cover = '' }, tracks = []) {
    const p = {
      id: uid('pl'), name: (name || '').trim() || `My playlist #${LIB.playlists.length + 1}`, desc: desc.trim(), cover,
      tracks: uniqBy(tracks.map(slim), t => t.id), created: now(), updatedAt: now()
    };
    LIB.playlists.unshift(p);
    this.touch('playlists');
    return p;
  },
  updatePlaylist(id, patch) {
    const p = this.playlist(id); if (!p) return;
    if (patch.name !== undefined) p.name = patch.name.trim() || p.name;
    if (patch.desc !== undefined) p.desc = patch.desc.trim();
    if (patch.cover !== undefined) p.cover = patch.cover;
    p.updatedAt = now();
    this.touch('playlists');
  },
  deletePlaylist(id) {
    const i = LIB.playlists.findIndex(p => p.id === id);
    if (i < 0) return;
    LIB.playlists.splice(i, 1); this.tomb('playlist', id); this.touch('playlists');
  },
  addToPlaylist(id, tracks) {
    const p = this.playlist(id); if (!p) return { added: 0, dupes: 0 };
    const have = new Set(p.tracks.map(t => t.id));
    let added = 0, dupes = 0;
    for (const t of tracks) { if (have.has(t.id)) { dupes++; continue; } p.tracks.push(slim(t)); have.add(t.id); added++; }
    if (added) { p.updatedAt = now(); this.touch('playlists'); }
    return { added, dupes };
  },
  removeFromPlaylist(id, index) {
    const p = this.playlist(id); if (!p || index < 0 || index >= p.tracks.length) return;
    p.tracks.splice(index, 1); p.updatedAt = now(); this.touch('playlists');
  },
  moveInPlaylist(id, from, to) {
    const p = this.playlist(id); if (!p) return;
    to = clamp(to, 0, p.tracks.length - 1);
    if (from === to || from < 0 || from >= p.tracks.length) return;
    const [x] = p.tracks.splice(from, 1); p.tracks.splice(to, 0, x);
    p.updatedAt = now(); this.touch('playlists');
  },

  /* ----- saved Audius playlists / albums ----- */
  isSavedList(id) { return LIB.savedLists.some(x => x.id === id); },
  toggleSavedList(l) {
    const i = LIB.savedLists.findIndex(x => x.id === l.id);
    if (i >= 0) { LIB.savedLists.splice(i, 1); this.tomb('savedList', l.id); this.touch('saved'); return false; }
    LIB.savedLists.unshift({ ...l, at: now() }); this.touch('saved'); return true;
  },

  /* ----- followed artists ----- */
  isFollowing(id) { return LIB.followed.some(a => a.id === id); },
  toggleFollow(a) {
    const i = LIB.followed.findIndex(x => x.id === a.id);
    if (i >= 0) { LIB.followed.splice(i, 1); this.tomb('follow', a.id); this.touch('followed'); return false; }
    LIB.followed.unshift({ id: a.id, rid: a.rid, src: a.src, name: a.name, handle: a.handle, img150: a.img150, img480: a.img480, followers: a.followers, at: now() });
    this.touch('followed'); return true;
  },

  /* ----- history & stats ----- */
  pushHistory(t) {
    if (!t) return;
    const top = LIB.history[0];
    if (!(top && top.t.id === t.id && now() - top.at < 15000)) LIB.history.unshift({ t: slim(t), at: now() });
    if (LIB.history.length > 150) LIB.history.length = 150;
    this.touch('history');
  },
  clearHistory() { LIB.history = []; this.touch('history'); },
  addSeconds(sec) {
    const s = LIB.stats; s.seconds += sec;
    const k = dayKey(); s.byDay[k] = (s.byDay[k] || 0) + sec;
    const keys = Object.keys(s.byDay).sort();
    while (keys.length > 60) delete s.byDay[keys.shift()];
    // persisted by the player's periodic session save (not per tick)
  },
  countPlay(t) {
    const s = LIB.stats; s.plays++;
    if (t.artist) { const a = s.artists[t.artist] = s.artists[t.artist] || { n: 0, s: 0 }; a.n++; }
    if (t.genre) s.genres[t.genre] = (s.genres[t.genre] || 0) + 1;
    saveLib(); Bus.emit('lib', 'stats');
  },
  resetStats() { LIB.stats = LIB_DEFAULTS().stats; this.touch('stats'); },

  /* ----- searches & recently opened items ----- */
  addSearch(q) {
    q = (q || '').trim(); if (!q) return;
    LIB.searches = [q, ...LIB.searches.filter(x => x.toLowerCase() !== q.toLowerCase())].slice(0, 15);
    this.touch('searches');
  },
  removeSearch(q) { LIB.searches = LIB.searches.filter(x => x !== q); this.touch('searches'); },
  clearSearches() { LIB.searches = []; LIB.recentItems = []; this.touch('searches'); },
  addRecentItem(type, data) {
    const key = `${type}:${data.id}`;
    LIB.recentItems = [{ type, data, at: now() }, ...LIB.recentItems.filter(x => `${x.type}:${x.data.id}` !== key)].slice(0, 12);
    this.touch('searches');
  },

  /* ----- lyrics ----- */
  setLyrics(id, text) { if (text) LIB.lyrics[id] = text; else delete LIB.lyrics[id]; this.touch('lyrics'); },

  /* ----- derived taste profile used for recommendations ----- */
  taste() {
    const g = {}, a = {};
    const bump = (map, key, w) => { if (key) map[key] = (map[key] || 0) + w; };
    LIB.history.slice(0, 80).forEach(x => { bump(g, x.t.genre, 1); bump(a, x.t.artistId ? `${x.t.artistId}|${x.t.artist}` : null, 1); });
    LIB.liked.slice(0, 80).forEach(x => { bump(g, x.t.genre, 2); bump(a, x.t.artistId ? `${x.t.artistId}|${x.t.artist}` : null, 2); });
    const top = m => Object.entries(m).sort((x, y) => y[1] - x[1]).map(e => e[0]);
    return { genres: top(g), artists: top(a).map(s => { const [id, ...n] = s.split('|'); return { id, name: n.join('|') }; }) };
  },

  /* ----- backup / restore (also the seed of cloud sync) ----- */
  exportJSON() {
    const copy = JSON.parse(JSON.stringify(LIB));
    return JSON.stringify({ app: 'SONORA', version: 1, exportedAt: new Date().toISOString(), prefs: { ...PREFS, jamendoId: '' }, library: copy }, null, 2);
  },
  importJSON(text) {
    let j;
    try { j = JSON.parse(text); } catch { throw new Error('That is not valid JSON.'); }
    if (!j || j.app !== 'SONORA' || !j.library) throw new Error('This file is not a SONORA backup.');
    const src = j.library;
    let n = 0;
    const mergeBy = (key, getId) => {
      const have = new Set(LIB[key].map(getId));
      arr(src[key]).forEach(x => { const id = getId(x); if (id && !have.has(id)) { LIB[key].push(x); have.add(id); n++; } });
    };
    mergeBy('liked', x => x.t && x.t.id);
    mergeBy('playlists', x => x.id);
    mergeBy('savedLists', x => x.id);
    mergeBy('followed', x => x.id);
    arr(src.searches).forEach(q => { if (!LIB.searches.includes(q)) LIB.searches.push(q); });
    Object.assign(LIB.lyrics, src.lyrics || {});
    this.touch('all');
    return n;
  }
};
