/* ==========================================================================
   SONORA — 05 player: queue, audio engine (two decks for crossfade), network
   recovery, Media Session, sleep timer, equalizer, speed, session restore.
   The engine sits behind PL (public API). A native Media3 engine can replace
   E later without touching the UI (see docs/ANDROID.md).
   ========================================================================== */

const Q = { list: [], orig: [], idx: -1, ctx: null };
const PS = { playing: false, buffering: false, waiting: false, pos: 0, dur: 0, error: null };
const UNAVAIL = new Set();
const curTrack = () => Q.list[Q.idx] || null;
const isUnavail = t => !t || UNAVAIL.has(t.id) || t.stream === false;
const effVol = () => (PREFS.muted ? 0 : clamp(PREFS.volume, 0, 1));

const EQ_BANDS = [
  { f: 60, label: '60 Hz', type: 'lowshelf' }, { f: 230, label: '230 Hz', type: 'peaking' }, { f: 910, label: '910 Hz', type: 'peaking' },
  { f: 3600, label: '3.6 kHz', type: 'peaking' }, { f: 14000, label: '14 kHz', type: 'highshelf' }
];
const EQ_PRESETS = {
  flat: [0, 0, 0, 0, 0], bass: [7, 4, 0, -1, -2], vocal: [-3, -1, 3, 4, 0], treble: [-2, -1, 0, 4, 7],
  acoustic: [3, 2, 1, 2, 3], electronic: [5, 3, -1, 2, 5], lofi: [4, 2, -2, -3, -5]
};

/* ---------- navigation inside the queue ---------- */
function nextIndex(auto) {
  const n = Q.list.length;
  if (!n) return -1;
  if (auto && PREFS.repeat === 'one') return Q.idx;
  for (let k = 1; k <= n; k++) {
    let i = Q.idx + k;
    if (i >= n) { if (PREFS.repeat !== 'all') return -1; i %= n; }
    if (i === Q.idx) return isUnavail(Q.list[i]) ? -1 : i;
    if (!isUnavail(Q.list[i])) return i;
  }
  return -1;
}
function prevIndex() {
  const n = Q.list.length;
  if (!n) return -1;
  for (let k = 1; k <= n; k++) {
    let i = Q.idx - k;
    if (i < 0) { if (PREFS.repeat !== 'all') return -1; i += n; }
    if (!isUnavail(Q.list[i])) return i;
  }
  return -1;
}
function goTo(i) {
  if (i < 0 || i >= Q.list.length) return;
  Q.idx = i;
  E.load(Q.list[i], { autoplay: true });
  Bus.emit('queue');
}

/* ---------- engine ---------- */
const E = {
  decks: [], a: 0, loadId: 0, mute: false, mt: null, failStreak: 0, fading: null, cors: false,
  lastTick: 0, retryN: 0, rt: null, stallT: null, resumePos: 0, graph: null,
  get d() { return this.decks[this.a]; },
  get o() { return this.decks[1 - this.a]; },
  /* events caused by our own src/pause changes are ignored for a moment */
  quiet(fn) { this.mute = true; try { fn(); } finally { clearTimeout(this.mt); this.mt = setTimeout(() => { this.mute = false; }, 150); } },
  tryPlay(d) {
    if (this.graph && this.graph.ctx.state === 'suspended') this.graph.ctx.resume().catch(() => { });
    const p = d.el.play();
    if (p && p.catch) p.catch(err => {
      if (err && err.name === 'AbortError') return;
      if (err && err.name === 'NotAllowedError') { PS.playing = false; Bus.emit('player:state'); toast('Tap play to start playback.'); }
      else console.warn('[play]', err);
    });
  },
  setSrc(d, urls, pos, isBlob) {
    if (d.blobUrl) { URL.revokeObjectURL(d.blobUrl); d.blobUrl = null; }
    d.urls = urls; d.ci = 0;
    if (isBlob) d.blobUrl = urls[0];
    this.loadCand(d, pos);
  },
  loadCand(d, pos) {
    this.quiet(() => { d.el.src = d.urls[d.ci]; d.el.playbackRate = PREFS.speed; d.el.volume = effVol(); });
    if (pos > 0) d.el.addEventListener('loadedmetadata', () => { try { d.el.currentTime = pos; } catch { /* not seekable */ } }, { once: true });
  },
  async load(t, { pos = 0, autoplay = true } = {}) {
    const id = ++this.loadId;
    this.cancelFade();
    clearTimeout(this.rt); this.clearStall();
    const d = this.d;
    this.quiet(() => d.el.pause());
    d.track = t; d.started = false; d.counted = false; d.listened = 0;
    PS.error = null; PS.pos = pos; PS.dur = t.dur || 0; PS.buffering = true; PS.waiting = false; PS.playing = !!autoplay;
    this.lastTick = 0; this.retryN = 0;
    Bus.emit('player:track'); Bus.emit('player:state'); MS.meta(); MS.state();
    let src;
    try { src = await resolveSources(t); } catch (e) {
      if (id !== this.loadId) return;
      failTrack(t, errMsg(e), true); return;
    }
    if (id !== this.loadId) { if (src.blob) URL.revokeObjectURL(src.urls[0]); return; }
    this.setSrc(d, src.urls, pos, src.blob);
    if (autoplay) this.tryPlay(d);
  },
  seek(sec) {
    const d = this.d; if (!d.el.src) return;
    const dur = isFinite(d.el.duration) ? d.el.duration : PS.dur;
    sec = clamp(sec, 0, dur || sec);
    try { d.el.currentTime = sec; } catch { return; }
    PS.pos = sec; this.lastTick = 0; Bus.emit('player:time'); MS.position();
  },
  /* ----- recovery ----- */
  stallWatch() {
    if (this.stallT || !PS.playing) return;
    this.stallT = setTimeout(() => { this.stallT = null; if (PS.playing && PS.buffering) this.waitNet(this.d); }, 10000);
  },
  clearStall() { clearTimeout(this.stallT); this.stallT = null; },
  waitNet(d) {
    PS.waiting = true; PS.buffering = true;
    this.resumePos = Math.max(PS.pos, d.el.currentTime || 0);
    Bus.emit('player:state');
    this.scheduleRetry();
  },
  scheduleRetry() {
    clearTimeout(this.rt);
    const delays = [2000, 4000, 8000, 15000, 30000];
    if (this.retryN >= delays.length) { PS.waiting = false; failTrack(curTrack(), 'Connection problem. Playback paused; tap play to try again.', false); return; }
    this.rt = setTimeout(() => this.retryNow(), delays[this.retryN++]);
  },
  retryNow() {
    clearTimeout(this.rt);
    const d = this.d;
    if (!d.track || !PS.waiting) return;
    if (!navigator.onLine) { this.scheduleRetry(); return; }
    this.loadCand(d, this.resumePos);
    if (PS.playing) this.tryPlay(d);
  },
  /* ----- crossfade ----- */
  cancelFade() {
    const F = this.fading; if (!F) return;
    clearInterval(F.iv); this.fading = null;
    this.quiet(() => { F.o.el.pause(); F.o.el.removeAttribute('src'); F.o.el.load(); });
    if (F.o.blobUrl) { URL.revokeObjectURL(F.o.blobUrl); F.o.blobUrl = null; }
    applyVolume();
  },
  /* ----- equalizer ----- */
  ensureGraph() {
    if (this.graph) return this.graph;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Error('Web Audio is not supported in this browser.');
    const ctx = new AC(), input = ctx.createGain();
    let prev = input;
    const filters = EQ_BANDS.map((b, i) => {
      const f = ctx.createBiquadFilter();
      f.type = b.type; f.frequency.value = b.f; if (b.type === 'peaking') f.Q.value = 1;
      f.gain.value = PREFS.eq.gains[i] || 0;
      prev.connect(f); prev = f; return f;
    });
    prev.connect(ctx.destination);
    return (this.graph = { ctx, input, filters });
  },
  setEqGains(gains) { if (!this.graph) return; this.graph.filters.forEach((f, i) => { f.gain.value = gains[i] || 0; }); },
  async enableEQ() {
    try { this.ensureGraph(); await this.graph.ctx.resume(); } catch (e) { toast(errMsg(e), { kind: 'warn' }); return false; }
    this.rebuild(true); return true;
  },
  disableEQ() { this.rebuild(false); },
  rebuild(cors) {
    const t = this.d && this.d.track, pos = PS.pos, was = PS.playing;
    this.cancelFade();
    this.decks.forEach(destroyDeck);
    this.decks = [mkDeck(cors), mkDeck(cors)]; this.a = 0; this.cors = cors;
    if (cors) this.decks.forEach(d => { d.node = this.graph.ctx.createMediaElementSource(d.el); d.node.connect(this.graph.input); });
    applyVolume();
    if (t) { this.d.track = t; if (PS.playing || pos > 0 || PS.dur) this.load(t, { pos, autoplay: was }); }
  }
};

function destroyDeck(d) {
  if (!d) return;
  E.quiet(() => { try { d.el.pause(); d.el.removeAttribute('src'); d.el.load(); } catch { /* ignore */ } });
  if (d.blobUrl) { URL.revokeObjectURL(d.blobUrl); d.blobUrl = null; }
  try { d.node && d.node.disconnect(); } catch { /* ignore */ }
  d.dead = true;
}

function mkDeck(cors) {
  const el = new Audio();
  el.preload = 'auto'; el.setAttribute('playsinline', '');
  if ('preservesPitch' in el) el.preservesPitch = true;
  if (cors) el.crossOrigin = 'anonymous';
  const d = { el, track: null, urls: [], ci: 0, blobUrl: null, cors: !!cors, started: false, counted: false, listened: 0, node: null, dead: false };
  const act = fn => e => { if (!d.dead && E.d === d) fn(e); };
  el.addEventListener('loadstart', act(() => { PS.buffering = true; Bus.emit('player:state'); }));
  el.addEventListener('waiting', act(() => { E.lastTick = 0; PS.buffering = true; E.stallWatch(); Bus.emit('player:state'); }));
  el.addEventListener('stalled', act(() => { E.stallWatch(); }));
  el.addEventListener('seeking', act(() => { E.lastTick = 0; }));
  el.addEventListener('canplay', act(() => { PS.buffering = false; Bus.emit('player:state'); }));
  el.addEventListener('playing', act(() => {
    PS.buffering = false; PS.waiting = false; PS.error = null; E.failStreak = 0; E.clearStall(); E.retryN = 0;
    onStarted(d); MS.state(); Bus.emit('player:state');
  }));
  el.addEventListener('play', act(() => { if (!PS.playing) { PS.playing = true; MS.state(); Bus.emit('player:state'); } }));
  el.addEventListener('pause', act(() => {
    E.lastTick = 0;
    if (E.mute || el.ended || E.fading) return;
    if (PS.playing) { PS.playing = false; MS.state(); Bus.emit('player:state'); }   // paused by the system (audio focus, headset, call)
  }));
  el.addEventListener('timeupdate', act(() => onTime(d)));
  el.addEventListener('durationchange', act(() => {
    if (isFinite(el.duration) && el.duration > 0) { PS.dur = el.duration; Bus.emit('player:time'); MS.position(); }
  }));
  el.addEventListener('ended', act(() => onEnded()));
  el.addEventListener('error', act(() => onDeckError(d)));
  return d;
}

function onStarted(d) {
  if (d.started || !d.track) return;
  d.started = true;
  Lib.pushHistory(d.track);
  Bus.emit('player:started', d.track);
}

function saveSessionNow() {
  const t = curTrack(); if (!t) return;
  const start = Math.max(0, Math.min(Q.idx - 20, Q.list.length - 100));
  LS.set('session', { list: Q.list.slice(start, start + 100).map(slim), idx: Q.idx - start, pos: PS.pos, ctx: Q.ctx, shuffled: Q.orig.length > 0 });
  saveLibNow();
}
const saveSession = throttle(saveSessionNow, 5000);           // periodic while playing
// Always persist the exact position when the page is hidden or closed, so a restart resumes where you stopped.
addEventListener('pagehide', saveSessionNow);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveSessionNow(); });

function onTime(d) {
  const t = d.track, cur = d.el.currentTime, n = performance.now();
  PS.pos = cur;
  if (PS.playing && E.lastTick) {
    const dt = (n - E.lastTick) / 1000;
    if (dt > 0 && dt < 2) {
      Lib.addSeconds(dt); d.listened += dt;
      if (!d.counted && t && (d.listened >= 30 || (PS.dur > 0 && PS.dur < 60 && d.listened >= PS.dur * 0.5))) { d.counted = true; Lib.countPlay(t); }
    }
  }
  E.lastTick = n;
  Bus.emit('player:time');
  maybeCrossfade();
  saveSession();
  if (Math.floor(cur) % 15 === 0) MS.position();
}

function onEnded() {
  if (E.fading) { finishFade(); return; }
  if (Sleep.mode === 'track') { Sleep.cancel(); PS.playing = false; Bus.emit('player:state'); toast('Sleep timer: playback stopped.'); return; }
  if (PREFS.repeat === 'one') { E.d.el.currentTime = 0; E.tryPlay(E.d); return; }
  const ni = nextIndex(true);
  if (ni < 0) { PS.playing = false; PS.pos = 0; MS.state(); Bus.emit('player:state'); Bus.emit('player:time'); return; }
  goTo(ni);
}

function onDeckError(d) {
  if (!d.el.getAttribute('src')) return;
  const code = d.el.error && d.el.error.code, t = d.track;
  if (!t) return;
  if (!navigator.onLine || code === 2) { E.waitNet(d); return; }
  if (d.ci + 1 < d.urls.length) { d.ci++; E.loadCand(d, PS.pos); if (PS.playing) E.tryPlay(d); return; }
  if (d.cors && t.src !== 'local') {
    // The server does not allow audio processing (CORS). Fall back to plain playback and turn the equalizer off.
    PREFS.eq.on = false; setPref('eq', PREFS.eq); E.disableEQ(); Bus.emit('eq');
    toast('The equalizer needs audio sources that allow processing. This one doesn’t, so it was switched off.', { kind: 'warn', ms: 6000 });
    return;
  }
  failTrack(t, code === 3 ? 'This audio file is damaged or in a format your browser can’t decode.' : 'This track is unavailable right now.', true);
}

function failTrack(t, msg, permanent) {
  PS.error = msg; PS.playing = false; PS.buffering = false; PS.waiting = false;
  if (permanent && t) UNAVAIL.add(t.id);
  E.failStreak++;
  MS.state(); Bus.emit('player:state'); Bus.emit('player:error', t, msg); Bus.emit('queue');
  const ni = nextIndex(false), hasNext = ni >= 0 && ni !== Q.idx;
  if (permanent && PREFS.autoSkip && hasNext && E.failStreak < 3) {
    toast(`${msg} Skipping to the next track.`, { kind: 'warn' });
    setTimeout(() => { if (curTrack() === t && PS.error) goTo(nextIndex(false)); }, 1100);
  } else {
    toast(E.failStreak >= 3 ? 'Several tracks in a row failed, so playback stopped.' : msg, { kind: 'warn', action: hasNext ? { label: 'Skip', fn: () => PL.next() } : null });
  }
}

/* ---------- crossfade ---------- */
function maybeCrossfade() {
  const cf = PREFS.crossfade;
  if (!cf || PREFS.dataSaver || E.fading || !PS.playing) return;
  const el = E.d.el;
  if (!isFinite(el.duration) || el.duration < cf * 3 || el.duration - el.currentTime > cf) return;
  if (PREFS.repeat === 'one' || Sleep.mode === 'track') return;
  const ni = nextIndex(true);
  if (ni < 0 || ni === Q.idx) return;
  startFade(ni, cf);
}
async function startFade(ni, secs) {
  const t = Q.list[ni], o = E.o, F = (E.fading = { ni, t, o, d: E.d, iv: null });
  let src;
  try { src = await resolveSources(t); } catch { if (E.fading === F) E.fading = null; return; }
  if (E.fading !== F) { if (src.blob) URL.revokeObjectURL(src.urls[0]); return; }
  o.track = t; o.started = false; o.counted = false; o.listened = 0;
  if (o.blobUrl) URL.revokeObjectURL(o.blobUrl);
  o.blobUrl = src.blob ? src.urls[0] : null; o.urls = src.urls; o.ci = 0;
  E.quiet(() => { o.el.src = src.urls[0]; o.el.volume = 0; o.el.playbackRate = PREFS.speed; });
  try { await o.el.play(); } catch { if (E.fading === F) E.cancelFade(); return; }
  if (E.fading !== F) return;
  const vol = effVol(), t0 = performance.now();
  F.iv = setInterval(() => {
    const x = clamp((performance.now() - t0) / (secs * 1000), 0, 1);
    F.d.el.volume = vol * Math.cos(x * Math.PI / 2);
    o.el.volume = vol * Math.sin(x * Math.PI / 2);
    if (x >= 1) finishFade();
  }, 80);
}
function finishFade() {
  const F = E.fading; if (!F) return;
  clearInterval(F.iv); E.fading = null;
  const old = F.d;
  E.quiet(() => { old.el.pause(); old.el.removeAttribute('src'); old.el.load(); });
  if (old.blobUrl) { URL.revokeObjectURL(old.blobUrl); old.blobUrl = null; }
  E.a = 1 - E.a;
  Q.idx = F.ni;
  PS.pos = E.d.el.currentTime; PS.dur = isFinite(E.d.el.duration) ? E.d.el.duration : (F.t.dur || 0);
  PS.error = null; E.lastTick = 0;
  applyVolume(); onStarted(E.d);
  Bus.emit('player:track'); Bus.emit('player:state'); Bus.emit('queue'); MS.meta(); MS.state();
}

/* ---------- volume ---------- */
function applyVolume() {
  if (E.fading || Sleep.fadeIv) return;
  E.decks.forEach(d => { d.el.volume = effVol(); });
}

/* ---------- sleep timer ---------- */
const Sleep = {
  mode: null, endAt: 0, timer: null, fadeIv: null,
  set(m) {
    this.cancel();
    if (m === 'track') this.mode = 'track';
    else { this.mode = 'time'; this.endAt = now() + m * 60000; this.timer = setInterval(() => this.tick(), 1000); }
    Bus.emit('sleep');
  },
  remaining() { return this.mode === 'time' ? Math.max(0, this.endAt - now()) : 0; },
  tick() {
    if (this.remaining() <= 0) this.fadeOut();
    Bus.emit('sleep:tick');
  },
  fadeOut() {
    clearInterval(this.timer); this.timer = null;
    const start = effVol(); let k = 0;
    this.fadeIv = setInterval(() => {
      k++; E.decks.forEach(d => { d.el.volume = start * Math.max(0, 1 - k / 20); });
      if (k >= 20) {
        clearInterval(this.fadeIv); this.fadeIv = null; this.mode = null;
        PL.pause(); applyVolume(); Bus.emit('sleep'); toast('Sleep timer finished. Playback stopped.');
      }
    }, 200);
  },
  cancel() {
    clearInterval(this.timer); this.timer = null;
    if (this.fadeIv) { clearInterval(this.fadeIv); this.fadeIv = null; applyVolume(); }
    const was = this.mode; this.mode = null; this.endAt = 0;
    if (was) Bus.emit('sleep');
  }
};

/* ---------- Media Session (lock-screen / notification controls where supported) ---------- */
const MS = {
  ok: 'mediaSession' in navigator,
  init() {
    if (!this.ok) return;
    const h = (a, f) => { try { navigator.mediaSession.setActionHandler(a, f); } catch { /* unsupported action */ } };
    h('play', () => PL.resumePlayback());
    h('pause', () => PL.pause());
    h('previoustrack', () => PL.prev());
    h('nexttrack', () => PL.next());
    h('seekto', e => { if (e.seekTime != null) PL.seek(e.seekTime); });
    h('seekbackward', e => PL.seekRel(-(e.seekOffset || 10)));
    h('seekforward', e => PL.seekRel(e.seekOffset || 10));
    h('stop', () => PL.pause());
  },
  meta() {
    const t = curTrack(); if (!this.ok || !t) return;
    const art = artUrl(t, 'lg');
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: t.title, artist: t.artist, album: t.album || (t.src === 'audius' ? 'Audius' : t.src === 'jamendo' ? 'Jamendo' : ''),
        artwork: art ? [{ src: art, sizes: '512x512' }] : []
      });
    } catch { /* ignore */ }
  },
  state() { if (this.ok) { try { navigator.mediaSession.playbackState = curTrack() ? (PS.playing ? 'playing' : 'paused') : 'none'; } catch { /* ignore */ } } },
  position() {
    if (!this.ok || !PS.dur || !isFinite(PS.dur)) return;
    try { navigator.mediaSession.setPositionState({ duration: PS.dur, position: clamp(PS.pos, 0, PS.dur), playbackRate: PREFS.speed }); } catch { /* ignore */ }
  }
};

/* ---------- public player API ---------- */
const PL = {
  init() {
    E.decks = [mkDeck(false), mkDeck(false)];
    // the equalizer setting is remembered: rebuild the engine with the audio graph so the UI never claims EQ is on when it isn't
    if (PREFS.eq.on) { try { E.ensureGraph(); E.rebuild(true); } catch { PREFS.eq.on = false; setPref('eq', PREFS.eq); } }
    applyVolume(); MS.init();
    addEventListener('online', () => { NET.online = true; setNet('ok'); if (PS.waiting) E.retryNow(); Bus.emit('net'); });
    addEventListener('offline', () => { NET.online = false; setNet('offline'); });
    // restore the last session paused (never autoplay on launch)
    const s = LS.get('session', null);
    if (s && Array.isArray(s.list) && s.list.length && s.list[s.idx]) {
      Q.list = rememberTracks(s.list); Q.idx = s.idx; Q.ctx = s.ctx || null;
      if (PREFS.shuffle && s.shuffled) Q.orig = Q.list.slice();
      const t = Q.list[Q.idx]; E.d.track = t; PS.pos = s.pos || 0; PS.dur = t.dur || 0;
      MS.meta(); MS.state();
    }
  },
  get track() { return curTrack(); },

  play(list, idx = 0, ctx = null, opts = {}) {
    list = arr(list).filter(Boolean);
    if (!list.length) return;
    let i = clamp(idx, 0, list.length - 1);
    if (opts.shuffle) { PREFS.shuffle = true; setPref('shuffle', true); const ok = list.map((t, k) => k).filter(k => !isUnavail(list[k])); i = ok.length ? ok[Math.floor(Math.random() * ok.length)] : 0; }
    if (isUnavail(list[i])) { const k = list.findIndex(t => !isUnavail(t)); if (k < 0) { toast('None of these tracks can be played right now.', { kind: 'warn' }); return; } i = k; }
    Q.ctx = ctx; Q.list = list.slice(); Q.orig = []; Q.idx = i;
    E.failStreak = 0;
    if (PREFS.shuffle) this.applyShuffle();
    E.load(Q.list[Q.idx], { autoplay: true });
    Bus.emit('queue');
  },
  playTrack(t, ctx) { this.play([t], 0, ctx || { type: 'track', name: t.title }); },
  applyShuffle() {
    const cur = curTrack(); if (!cur) return;
    Q.orig = Q.list.slice();
    Q.list = [cur, ...shuffled(Q.list.filter((_, k) => k !== Q.idx))]; Q.idx = 0;
  },
  toggleShuffle() {
    const on = !PREFS.shuffle; setPref('shuffle', on);
    if (Q.list.length) {
      if (on) this.applyShuffle();
      else if (Q.orig.length) { const cur = curTrack(); Q.list = Q.orig; Q.orig = []; Q.idx = Math.max(0, Q.list.findIndex(t => t.id === (cur && cur.id))); }
    }
    Bus.emit('queue'); Bus.emit('player:state');
  },
  cycleRepeat() {
    const next = { off: 'all', all: 'one', one: 'off' }[PREFS.repeat] || 'off';
    setPref('repeat', next); Bus.emit('player:state');
    return next;
  },
  toggle() { if (!curTrack()) return; if (PS.playing) this.pause(); else this.resumePlayback(); },
  pause() {
    if (E.fading) finishFade();
    PS.playing = false; E.quiet(() => E.d.el.pause()); MS.state(); Bus.emit('player:state'); saveSessionNow();
  },
  resumePlayback() {
    const t = curTrack(); if (!t) return;
    const d = E.d;
    PS.playing = true;
    if (PS.error || !d.el.getAttribute('src') || d.track !== t) { E.failStreak = 0; UNAVAIL.delete(t.id); E.load(t, { pos: PS.error ? PS.pos : (PS.pos || 0), autoplay: true }); return; }
    if (d.el.ended) d.el.currentTime = 0;
    E.tryPlay(d); MS.state(); Bus.emit('player:state');
  },
  next() {
    if (E.fading) finishFade();
    const ni = nextIndex(false);
    if (ni >= 0) { E.failStreak = 0; goTo(ni); }
    else if (Q.list.length) { E.seek(0); this.pause(); toast('End of queue.'); }
  },
  prev() {
    if (E.fading) finishFade();
    if (PS.pos > 3 || prevIndex() < 0) { E.seek(0); if (!PS.playing && curTrack()) this.resumePlayback(); return; }
    goTo(prevIndex());
  },
  seek(s) { E.seek(s); },
  seekRel(d) { E.seek(PS.pos + d); },
  setVolume(v) { setPref('volume', clamp(v, 0, 1)); if (v > 0 && PREFS.muted) setPref('muted', false); applyVolume(); Bus.emit('player:state'); },
  toggleMute() { setPref('muted', !PREFS.muted); applyVolume(); Bus.emit('player:state'); },
  setSpeed(s) { setPref('speed', s); E.decks.forEach(d => { d.el.playbackRate = s; }); MS.position(); Bus.emit('player:state'); },

  /* ----- queue editing ----- */
  addNext(t) {
    if (!curTrack()) { this.playTrack(t); return; }
    Q.list.splice(Q.idx + 1, 0, t);
    if (Q.orig.length) { const k = Q.orig.findIndex(x => x.id === curTrack().id); Q.orig.splice(k + 1, 0, t); }
    Bus.emit('queue');
  },
  addToQueue(t) {
    if (!curTrack()) { this.playTrack(t); return; }
    Q.list.push(t); if (Q.orig.length) Q.orig.push(t);
    Bus.emit('queue');
  },
  removeFromQueue(i) {
    if (i < 0 || i >= Q.list.length || i === Q.idx) return;
    const [x] = Q.list.splice(i, 1);
    if (i < Q.idx) Q.idx--;
    if (Q.orig.length) { const k = Q.orig.findIndex(y => y.id === x.id); if (k >= 0) Q.orig.splice(k, 1); }
    Bus.emit('queue');
  },
  moveInQueue(from, to) {
    if (from === to || from < 0 || to < 0 || from >= Q.list.length || to >= Q.list.length) return;
    const cur = curTrack();
    const [x] = Q.list.splice(from, 1); Q.list.splice(to, 0, x);
    Q.idx = Q.list.indexOf(cur);
    Bus.emit('queue');
  },
  clearUpcoming() { Q.list.length = Q.idx + 1; if (Q.orig.length) Q.orig = Q.list.slice(); Bus.emit('queue'); },
  jump(i) { if (i === Q.idx) { this.toggle(); return; } E.failStreak = 0; UNAVAIL.delete(Q.list[i] && Q.list[i].id); goTo(i); },

  upcomingCount() { return Math.max(0, Q.list.length - Q.idx - 1); }
};

/* a restored-but-not-started track is "paused", not "empty" */
const hasSession = () => !!curTrack();
