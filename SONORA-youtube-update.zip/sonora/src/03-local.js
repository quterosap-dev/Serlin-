/* ==========================================================================
   SONORA — 03 local music: tag readers (ID3v2, FLAC, MP4/M4A), LRC parser,
   import pipeline, blob access, offline copies of downloadable tracks.
   Nothing here ever leaves the device.
   ========================================================================== */

const AUDIO_EXT = /\.(mp3|wav|wave|flac|m4a|m4b|aac|ogg|oga|opus|webm|weba|mp4|3gp|amr|aif|aiff)$/i;
const isAudioFile = f => (f.type && f.type.startsWith('audio/')) || AUDIO_EXT.test(f.name);

const LOCAL = [];                    // local track objects (metadata only)
const SESSION_BLOBS = new Map();     // used when "remember local music" is off, or IndexedDB is unavailable

/* ---------- byte helpers ---------- */
const readAt = async (file, off, len) => new Uint8Array(await file.slice(off, off + len).arrayBuffer());
const u32be = (u, o) => ((u[o] << 24) | (u[o + 1] << 16) | (u[o + 2] << 8) | u[o + 3]) >>> 0;
const u32le = (u, o) => (u[o] | (u[o + 1] << 8) | (u[o + 2] << 16) | (u[o + 3] << 24)) >>> 0;
const syncsafe = (u, o) => ((u[o] & 127) << 21) | ((u[o + 1] & 127) << 14) | ((u[o + 2] & 127) << 7) | (u[o + 3] & 127);
const ascii = (u, o, n) => String.fromCharCode(...u.subarray(o, o + n));
const utf8 = u => new TextDecoder('utf-8').decode(u);

function decodeText(u, enc) {
  let s;
  if (enc === 1 || enc === 2) {
    let label = enc === 2 ? 'utf-16be' : 'utf-16le', b = u;
    if (u.length >= 2 && u[0] === 0xFF && u[1] === 0xFE) { label = 'utf-16le'; b = u.subarray(2); }
    else if (u.length >= 2 && u[0] === 0xFE && u[1] === 0xFF) { label = 'utf-16be'; b = u.subarray(2); }
    s = new TextDecoder(label).decode(b);
  } else if (enc === 3) s = utf8(u);
  else s = new TextDecoder('windows-1252').decode(u);
  return s.replace(/\u0000+$/g, '').replace(/^﻿/, '');
}
/* find the end of a terminated string inside an ID3 frame */
function termIdx(u, start, enc) {
  if (enc === 1 || enc === 2) { for (let i = start; i + 1 < u.length; i += 2) if (u[i] === 0 && u[i + 1] === 0) return i; return u.length; }
  for (let i = start; i < u.length; i++) if (u[i] === 0) return i;
  return u.length;
}
const termLen = enc => (enc === 1 || enc === 2 ? 2 : 1);
const blobUrlFromBytes = (bytes, mime) => new Blob([bytes], { type: mime || 'image/jpeg' });

/* downscale embedded cover art to a small data URL so metadata stays light */
async function coverToSmallDataUrl(blob, size = 320) {
  try {
    const bmp = await createImageBitmap(blob);
    const s = Math.min(bmp.width, bmp.height);
    const c = document.createElement('canvas'); c.width = c.height = Math.min(size, s);
    c.getContext('2d').drawImage(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s, 0, 0, c.width, c.height);
    bmp.close && bmp.close();
    return c.toDataURL('image/jpeg', 0.8);
  } catch { return ''; }
}

/* ---------- ID3v2 (MP3, some others) ---------- */
function parseID3(u) {
  if (u.length < 10 || ascii(u, 0, 3) !== 'ID3') return null;
  const ver = u[3], flags = u[5], size = syncsafe(u, 6);
  let p = 10; const end = Math.min(u.length, 10 + size);
  if (flags & 0x40) { p += ver === 4 ? syncsafe(u, p) : u32be(u, p) + 4; }
  const tags = {};
  while (p + 10 <= end) {
    const id = ascii(u, p, 4);
    if (!/^[A-Z0-9]{4}$/.test(id)) break;
    const fsz = ver === 4 ? syncsafe(u, p + 4) : u32be(u, p + 4);
    p += 10;
    if (fsz <= 0 || p + fsz > u.length) break;
    const f = u.subarray(p, p + fsz); p += fsz;
    const enc = f[0];
    if (id[0] === 'T' && id !== 'TXXX') {
      const v = decodeText(f.subarray(1), enc);
      if (id === 'TIT2') tags.title = v;
      else if (id === 'TPE1') tags.artist = v;
      else if (id === 'TALB') tags.album = v;
      else if (id === 'TCON') tags.genre = v.replace(/^\((\d+)\)/, '').trim() || v;
      else if (id === 'TRCK') tags.no = parseInt(v, 10) || undefined;
      else if (id === 'TYER' || id === 'TDRC') tags.year = String(v).slice(0, 4);
      else if (id === 'TLEN') tags.durMs = parseInt(v, 10) || undefined;
    } else if (id === 'TXXX') {
      // user text frame: some taggers store lyrics here (description "LYRICS" / "UNSYNCED LYRICS")
      const t0 = termIdx(f, 1, enc);
      const desc = decodeText(f.subarray(1, t0), enc).toUpperCase().replace(/\s+/g, '');
      if (['LYRICS', 'UNSYNCEDLYRICS', 'USLT'].includes(desc) && !tags.lyrics) tags.lyrics = decodeText(f.subarray(t0 + termLen(enc)), enc);
    } else if (id === 'USLT') {
      const t0 = termIdx(f, 4, enc);
      tags.lyrics = decodeText(f.subarray(t0 + termLen(enc)), enc);
    } else if (id === 'APIC' && !tags.picture) {
      const m0 = termIdx(f, 1, 0);
      const mime = ascii(f, 1, m0 - 1) || 'image/jpeg';
      const d0 = termIdx(f, m0 + 2, enc);
      tags.picture = { mime, bytes: f.subarray(d0 + termLen(enc)) };
    }
  }
  return { tags, totalSize: 10 + size };
}

/* ---------- FLAC ---------- */
function parseFlac(u) {
  if (u.length < 8 || ascii(u, 0, 4) !== 'fLaC') return null;
  const tags = {}; let p = 4;
  while (p + 4 <= u.length) {
    const last = u[p] & 0x80, type = u[p] & 0x7F, len = (u[p + 1] << 16) | (u[p + 2] << 8) | u[p + 3];
    p += 4;
    if (p + len > u.length) break;
    const b = u.subarray(p, p + len);
    if (type === 0 && len >= 18) {
      const sr = (b[10] << 12) | (b[11] << 4) | (b[12] >> 4);
      const total = (b[13] & 0x0F) * 4294967296 + u32be(b, 14);
      if (sr) tags.durSec = total / sr;
    } else if (type === 4) {
      let q = 4 + u32le(b, 0); const n = u32le(b, q); q += 4;
      for (let i = 0; i < n && q + 4 <= b.length; i++) {
        const l = u32le(b, q); q += 4;
        const kv = utf8(b.subarray(q, q + l)); q += l;
        const eq = kv.indexOf('=');
        if (eq < 0) continue;
        const k = kv.slice(0, eq).toUpperCase(), v = kv.slice(eq + 1);
        if (k === 'TITLE') tags.title = v; else if (k === 'ARTIST') tags.artist = v; else if (k === 'ALBUM') tags.album = v;
        else if (k === 'GENRE') tags.genre = v; else if (k === 'TRACKNUMBER') tags.no = parseInt(v, 10) || undefined;
        else if (k === 'DATE') tags.year = v.slice(0, 4); else if (k === 'LYRICS' || k === 'UNSYNCEDLYRICS') tags.lyrics = v;
      }
    } else if (type === 6 && !tags.picture) {
      let q = 4; const ml = u32be(b, q); q += 4;
      const mime = ascii(b, q, ml); q += ml;
      const dl = u32be(b, q); q += 4 + dl + 16;
      const n = u32be(b, q); q += 4;
      tags.picture = { mime, bytes: b.subarray(q, q + n) };
    }
    p += len;
    if (last) break;
  }
  return { tags };
}

/* ---------- MP4 / M4A ---------- */
async function parseMp4(file) {
  const tags = {}; let off = 0;
  const size = file.size;
  while (off + 8 <= size) {
    const h = await readAt(file, off, 16);
    let sz = u32be(h, 0); const type = ascii(h, 4, 4);
    if (sz === 1) sz = u32be(h, 8) * 4294967296 + u32be(h, 12);
    if (sz === 0) sz = size - off;
    if (sz < 8) break;
    if (type === 'moov' && sz < 64 * 1024 * 1024) {
      const moov = await readAt(file, off, sz);
      walkMp4(moov, 8, moov.length, tags);
      break;
    }
    off += sz;
  }
  return Object.keys(tags).length ? { tags } : null;
}
function walkMp4(u, start, end, tags) {
  let p = start;
  while (p + 8 <= end) {
    const sz = u32be(u, p), type = ascii(u, p + 4, 4);
    if (sz < 8 || p + sz > end) break;
    if (type === 'mvhd') {
      const v = u[p + 8];
      const ts = v === 1 ? u32be(u, p + 28) : u32be(u, p + 20);
      const du = v === 1 ? u32be(u, p + 36) : u32be(u, p + 24);
      if (ts) tags.durSec = du / ts;
    } else if (type === 'moov' || type === 'udta' || type === 'ilst') walkMp4(u, p + 8, p + sz, tags);
    else if (type === 'meta') walkMp4(u, p + 12, p + sz, tags);
    else if (['©nam', '©ART', '©alb', '©gen', '©day', 'covr', '©lyr', 'aART'].includes(type)) {
      // child 'data' atom: 8 header + 1 version + 3 flags + 4 reserved
      const dsz = u32be(u, p + 8);
      if (ascii(u, p + 12, 4) === 'data' && dsz >= 16) {
        const flags = (u[p + 17] << 8) | u[p + 18];
        const payload = u.subarray(p + 24, p + 8 + dsz);
        if (type === 'covr') tags.picture = tags.picture || { mime: flags === 14 ? 'image/png' : 'image/jpeg', bytes: payload };
        else {
          const v = utf8(payload);
          if (type === '©nam') tags.title = v; else if (type === '©ART') tags.artist = v; else if (type === 'aART') tags.artist = tags.artist || v;
          else if (type === '©alb') tags.album = v; else if (type === '©gen') tags.genre = v; else if (type === '©day') tags.year = v.slice(0, 4);
          else if (type === '©lyr') tags.lyrics = v;
        }
      }
    }
    p += sz;
  }
}

/* ---------- unified reader with filename fallback ---------- */
function titleFromFilename(name) {
  let base = name.replace(/\.[^.]+$/, '').replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
  base = base.replace(/^\d{1,3}\s*[-.)]\s*/, '');
  const m = base.match(/^(.+?)\s+-\s+(.+)$/);
  return m ? { artist: m[1].trim(), title: m[2].trim() } : { title: base, artist: '' };
}
async function readMeta(file) {
  let res = null;
  try {
    const head = await readAt(file, 0, 16);
    if (ascii(head, 0, 3) === 'ID3') {
      const size = 10 + syncsafe(head, 6);
      res = parseID3(await readAt(file, 0, Math.min(size, 12 * 1024 * 1024)));
    } else if (ascii(head, 0, 4) === 'fLaC') {
      res = parseFlac(await readAt(file, 0, Math.min(file.size, 6 * 1024 * 1024)));
    } else if (ascii(head, 4, 4) === 'ftyp') {
      res = await parseMp4(file);
    }
  } catch (e) { console.warn('[meta]', file.name, e); }
  const tags = (res && res.tags) || {};
  const fb = titleFromFilename(file.name);
  const out = {
    title: (tags.title || fb.title || file.name).trim(), artist: (tags.artist || fb.artist || 'Unknown artist').trim(),
    album: (tags.album || '').trim(), genre: (tags.genre || '').trim(), year: tags.year, no: tags.no,
    durHint: tags.durSec || (tags.durMs ? tags.durMs / 1000 : 0), lyrics: tags.lyrics || ''
  };
  if (tags.picture && tags.picture.bytes && tags.picture.bytes.length > 100) {
    out.art = await coverToSmallDataUrl(blobUrlFromBytes(tags.picture.bytes, tags.picture.mime));
  }
  return out;
}

/* duration + proof that this browser can decode the file */
function probeAudio(file) {
  return new Promise(resolve => {
    const url = URL.createObjectURL(file), a = new Audio();
    let done = false;
    const fin = (ok, dur) => { if (done) return; done = true; URL.revokeObjectURL(url); a.removeAttribute('src'); resolve({ ok, dur }); };
    a.preload = 'metadata';
    a.onloadedmetadata = () => fin(true, isFinite(a.duration) ? a.duration : 0);
    a.onerror = () => fin(false, 0);
    setTimeout(() => fin(false, 0), 15000);
    a.src = url;
  });
}

/* ---------- LRC / lyrics ---------- */
function parseLyrics(text) {
  if (!text) return { synced: false, lines: [] };
  const lines = [], re = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;
  for (const raw of String(text).split(/\r?\n/)) {
    const stamps = [...raw.matchAll(re)];
    if (!stamps.length) continue;
    const body = raw.replace(re, '').trim();
    for (const m of stamps) {
      const frac = m[3] ? parseInt(m[3].padEnd(3, '0').slice(0, 3), 10) / 1000 : 0;
      lines.push({ t: parseInt(m[1], 10) * 60 + parseInt(m[2], 10) + frac, text: body });
    }
  }
  if (lines.length >= 2) { lines.sort((a, b) => a.t - b.t); return { synced: true, lines }; }
  return { synced: false, lines: String(text).split(/\r?\n/).map(x => ({ t: 0, text: x.replace(/^\[[a-z]{2,}:.*\]$/i, '').trimEnd() })) };
}
function lyricsFor(t) {
  if (!t) return '';
  const u = LIB.lyrics[t.id];
  if (u !== undefined) return String(u).trim() ? u : '';   // a blank entry means "removed"
  return t.lyr || '';
}

/* ---------- local library persistence ---------- */
async function getLocalBlob(t) {
  if (SESSION_BLOBS.has(t.id)) return SESSION_BLOBS.get(t.id);
  try { return await IDB.get('files', t.id); } catch { return null; }
}
async function getOfflineBlob(id) {
  try { return await IDB.get('offline', id); } catch { return null; }
}
async function loadLocalLibrary() {
  try {
    const metas = await IDB.all('meta');
    metas.forEach(m => { if (m && m.id && !LOCAL.some(x => x.id === m.id)) { LOCAL.push(rememberTrack(m)); } });
    LOCAL.sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
  } catch (e) { console.warn('[local] load', e); }
}

async function importFiles(fileList, { onProgress } = {}) {
  const files = Array.from(fileList || []).filter(isAudioFile);
  const skipped = Array.from(fileList || []).length - files.length;
  const res = { added: [], dupes: 0, failed: [], skipped };
  let i = 0;
  for (const f of files) {
    i++;
    onProgress && onProgress(i, files.length, f.name);
    const id = 'lo:' + hashStr(`${f.name}|${f.size}|${f.lastModified}`).toString(36);
    if (LOCAL.some(x => x.id === id)) { res.dupes++; continue; }
    const probe = await probeAudio(f);
    if (!probe.ok) { res.failed.push(f.name); continue; }
    const meta = await readMeta(f);
    const t = {
      id, src: 'local', title: meta.title, artist: meta.artist, album: meta.album, genre: meta.genre, year: meta.year, no: meta.no,
      dur: probe.dur || meta.durHint || 0, art480: meta.art || '', art150: meta.art || '', stream: true,
      localKey: f.name, lyr: meta.lyrics || '', addedAt: Date.now(), size: f.size
    };
    let persisted = false;
    if (PREFS.rememberLocal && IDB.ok) {
      try { await IDB.put('files', id, f); await IDB.put('meta', id, t); persisted = true; }
      catch (e) { try { await IDB.del('files', id); } catch { /* ignore */ } }
    }
    if (!persisted) SESSION_BLOBS.set(id, f);
    t.session = !persisted;
    LOCAL.unshift(rememberTrack(t));
    res.added.push(t);
  }
  if (res.added.length) Bus.emit('local');
  return res;
}
async function removeLocal(id) {
  const i = LOCAL.findIndex(x => x.id === id);
  if (i >= 0) LOCAL.splice(i, 1);
  SESSION_BLOBS.delete(id);
  try { await IDB.del('files', id); await IDB.del('meta', id); } catch { /* ignore */ }
  // drop from the library too
  LIB.liked = LIB.liked.filter(x => x.t.id !== id);
  LIB.playlists.forEach(p => { p.tracks = p.tracks.filter(t => t.id !== id); });
  LIB.history = LIB.history.filter(x => x.t.id !== id);
  delete LIB.lyrics[id];
  saveLib(); Bus.emit('local'); Bus.emit('lib', 'all');
}

/* ---------- offline copies (only for tracks whose artist allows downloads) ---------- */
const Offline = {
  has(id) { return LIB.downloads.some(t => t.id === id); },
  async save(t, onProgress) {
    if (t.src === 'local') throw new Error('Local files are already on your device.');
    if (!t.dl) throw new Error('The artist has not enabled downloads for this track.');
    const { urls } = await resolveSources(t);
    let res;
    try { res = await fetch(urls[0]); } catch { throw new Error("Couldn't download — the server blocked the request or you're offline."); }
    if (!res.ok) throw new Error(`Download failed (${res.status}).`);
    let blob;
    if (res.body && onProgress && res.headers.get('content-length')) {
      const total = +res.headers.get('content-length'), rd = res.body.getReader(), parts = []; let got = 0;
      for (;;) { const { done, value } = await rd.read(); if (done) break; parts.push(value); got += value.length; onProgress(got / total); }
      blob = new Blob(parts, { type: res.headers.get('content-type') || 'audio/mpeg' });
    } else blob = await res.blob();
    if (!blob.size) throw new Error('The download was empty.');
    await IDB.put('offline', t.id, blob);
    if (!Offline.has(t.id)) LIB.downloads.unshift(slim(t));
    saveLib(); Bus.emit('lib', 'downloads');
    return blob.size;
  },
  async remove(id) {
    try { await IDB.del('offline', id); } catch { /* ignore */ }
    LIB.downloads = LIB.downloads.filter(t => t.id !== id);
    saveLib(); Bus.emit('lib', 'downloads');
  }
};
