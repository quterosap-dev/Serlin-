#!/usr/bin/env node
/* SONORA build — no dependencies.
 *   node build.js
 * Produces:
 *   dist/index.html     full standalone document (the real streaming build; host it anywhere / wrap with Capacitor)
 *   dist/artifact.html  fragment for the Claude Artifact viewer (no doctype/html/head/body)
 *   dist/manifest.webmanifest, dist/sw.js, dist/icons/*.svg (PWA bits; PNG icons come from test/make-icons.js if Chromium exists)
 */
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const SRC = path.join(ROOT, 'src');
const DIST = path.join(ROOT, 'dist');
fs.mkdirSync(DIST, { recursive: true });

const read = f => fs.readFileSync(path.join(SRC, f), 'utf8');
const jsFiles = fs.readdirSync(SRC).filter(f => /^\d\d-.*\.js$/.test(f)).sort();
const css = read('styles.css');
let shell = read('shell.html');

/* --- icon + logo placeholders in the shell --- */
const iconSvg = name => `<svg class="ic" aria-hidden="true"><use href="#i-${name}"/></svg>`;
const logoSvg = `<svg class="logo" viewBox="0 0 64 64" aria-hidden="true"><use href="#logo"/></svg>`;
shell = shell.replace(/__ic_([a-z0-9-]+)__/g, (_, n) => iconSvg(n)).replace(/__logo__/g, logoSvg);
const leftover = shell.match(/__[a-z_-]+__/g);
if (leftover) { console.error('Unreplaced placeholders:', [...new Set(leftover)]); process.exit(1); }

/* --- scripts: plain global-scope concatenation, wrapped in one IIFE-free block so `const` stays script-scoped --- */
const js = jsFiles.map(f => `/* ---- ${f} ---- */\n${read(f)}`).join('\n');
// A literal "</script" inside JS would end the tag early.
if (/<\/script/i.test(js)) { console.error('JS contains "</script" — escape it.'); process.exit(1); }

const FONTS = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Sora:wght@500;600;700&display=swap';
const THEME_BOOT = `try{var p=JSON.parse(localStorage.getItem('sonora.prefs')||'{}');var r=document.documentElement;if(p.theme==='light'||p.theme==='dark')r.setAttribute('data-theme',p.theme);if(p.accent&&p.accent!=='ember')r.setAttribute('data-accent',p.accent)}catch(e){}`;

const pkg = { name: 'SONORA', version: '1.0.0' };
const stamp = new Date().toISOString().slice(0, 10);

/* --- full document --- */
const full = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>SONORA</title>
<meta name="description" content="SONORA — a free music player for the open web. Streams from Audius, plays your own files.">
<meta name="theme-color" content="#0e0e11">
<meta name="color-scheme" content="dark light">
<meta name="application-name" content="SONORA">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="SONORA">
<link rel="manifest" href="manifest.webmanifest">
<link rel="icon" href="icons/icon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="icons/icon-192.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="${FONTS}">
<script>${THEME_BOOT}</script>
<style>
${css}
</style>
</head>
<body>
${shell}
<script>
${js}
</script>
</body>
</html>
`;
fs.writeFileSync(path.join(DIST, 'index.html'), full);

/* --- artifact fragment --- */
const frag = `<title>SONORA</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="${FONTS}">
<style>
${css}
</style>
${shell}
<script>
${js}
</script>
`;
fs.writeFileSync(path.join(DIST, 'artifact.html'), frag);

/* --- PWA manifest + service worker + icon --- */
const iconSvgFile = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
<defs><linearGradient id="g" x1="6" y1="4" x2="58" y2="60" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ff9a3d"/><stop offset=".5" stop-color="#ff3d7f"/><stop offset="1" stop-color="#7c5cff"/></linearGradient></defs>
<rect width="64" height="64" rx="18" fill="url(#g)"/>
<path d="M43.5 20.5c-3.4-4.3-10.4-5.4-15.2-2.6-5 2.9-5.4 9 .2 12.3 5 2.9 12.4 3.4 13.6 9.2 1.2 5.8-4.4 9.6-10.2 8.9-4-.5-7-2.5-8.7-5.4" fill="none" stroke="#fff" stroke-width="5.4" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M49 28.5c2.2 2.3 2.2 6.7 0 9" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="3.4" stroke-linecap="round"/>
<path d="M54 25c3.6 3.9 3.6 11.1 0 15" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="3" stroke-linecap="round"/>
</svg>
`;
fs.mkdirSync(path.join(DIST, 'icons'), { recursive: true });
fs.writeFileSync(path.join(DIST, 'icons', 'icon.svg'), iconSvgFile);

fs.writeFileSync(path.join(DIST, 'manifest.webmanifest'), JSON.stringify({
  name: 'SONORA', short_name: 'SONORA', description: 'Free music streaming and local music player.',
  start_url: './', scope: './', display: 'standalone', orientation: 'portrait-primary',
  background_color: '#0e0e11', theme_color: '#0e0e11', categories: ['music', 'entertainment'],
  icons: [
    { src: 'icons/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
    { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
    { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
    { src: 'icons/icon-maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
  ]
}, null, 2));

/* Service worker: caches ONLY the app shell. It never touches audio or API requests, so streaming and
   Range requests go straight to the network and no copyrighted audio is stored by the worker. */
fs.writeFileSync(path.join(DIST, 'sw.js'), `/* SONORA service worker — app shell only. v${stamp} */
const CACHE = 'sonora-shell-${stamp}';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icons/icon.svg'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('sonora-shell-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;   // never intercept cross-origin (API, audio, fonts)
  if (req.headers.has('range')) return;                                  // never intercept media range requests
  e.respondWith(fetch(req).then(res => {
    if (res.ok && (req.mode === 'navigate' || SHELL.some(s => url.pathname.endsWith(s.replace('./', '')) ))) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); }
    return res;
  }).catch(() => caches.match(req).then(r => r || (req.mode === 'navigate' ? caches.match('index.html') : Response.error()))));
});
`);

const kb = f => (fs.statSync(path.join(DIST, f)).size / 1024).toFixed(1) + ' KB';
console.log(`built: ${jsFiles.length} scripts | index.html ${kb('index.html')} | artifact.html ${kb('artifact.html')}`);
