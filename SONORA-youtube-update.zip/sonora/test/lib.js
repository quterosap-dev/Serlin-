/* Minimal test framework: each test gets a fresh browser context (clean storage). */
const { newPage, APP, ctl } = require('./harness');
const fs = require('fs');
const W = ms => new Promise(r => setTimeout(r, ms));
const results = [];
let H = null, only = null;
function init(h, filter) { H = h; only = filter ? new RegExp(filter, 'i') : null; }
async function test(name, fn, opts = {}) {
  if (only && !only.test(name)) return;
  const errors = [];
  const t0 = Date.now();
  let env;
  try {
    await ctl('reset=1');
    env = await newPage(H.browser, { errors, ...opts });
    const page = env.page;
    if (!opts.noGoto) { await page.goto(APP + '/index.html'); await page.waitForFunction(() => window.SONORA, null, { timeout: 8000 }); }
    await fn(page, env.ctx, errors);
    const bad = errors.filter(e => !/ERR_TUNNEL_CONNECTION_FAILED|fonts\.(googleapis|gstatic)|net::ERR_(INTERNET_DISCONNECTED|FAILED|ABORTED)|Failed to load resource/.test(e));
    if (bad.length && !opts.allowErrors) throw new Error('unexpected console/page errors: ' + bad.join(' | ').slice(0, 400));
    results.push({ name, ok: true, ms: Date.now() - t0 });
    console.log('  ✓', name, `(${((Date.now() - t0) / 1000).toFixed(1)}s)`);
  } catch (e) {
    results.push({ name, ok: false, ms: Date.now() - t0, err: String(e.message || e).split('\n')[0].slice(0, 500) });
    console.log('  ✗', name, '\n      ', String(e.message || e).split('\n').slice(0, 3).join('\n       '));
    try { if (env) await env.page.screenshot({ path: `shots/FAIL-${name.replace(/\W+/g, '_').slice(0, 40)}.png` }); } catch { }
  } finally { try { if (env) await env.ctx.close(); } catch { } }
}
function expect(cond, msg) { if (!cond) throw new Error('expect failed: ' + msg); }
function eq(a, b, msg) { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${msg || 'eq'}: got ${JSON.stringify(a)} want ${JSON.stringify(b)}`); }
const ev = (page, fn, arg) => page.evaluate(fn, arg);
const audio = page => page.evaluate(() => { const e = SONORA.E.d.el; return { t: e.currentTime, paused: e.paused, src: e.currentSrc, rs: e.readyState, dur: e.duration, rate: e.playbackRate, vol: e.volume, muted: e.muted, ended: e.ended }; });
async function until(page, fn, arg, timeout = 8000) { return page.waitForFunction(fn, arg, { timeout }); }
function report(file) {
  const pass = results.filter(r => r.ok).length;
  console.log(`\n${pass}/${results.length} passed`);
  results.filter(r => !r.ok).forEach(r => console.log(' FAIL:', r.name, '-', r.err));
  if (file) fs.writeFileSync(file, JSON.stringify(results, null, 1));
  return results.every(r => r.ok);
}
module.exports = { init, test, expect, eq, ev, audio, until, report, W, results };
