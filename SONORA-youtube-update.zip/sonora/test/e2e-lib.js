/* E2E group 2: playlists, library, likes, follows, saved albums, local files, offline downloads, lyrics, backup/restore. */
const { boot, mlog, ctl, MOCK, APP } = require('./harness');
const T = require('./lib');
const { test, expect, eq, ev, audio, until, W } = T;
const path = require('path'), fs = require('fs');
const A = p => path.join(__dirname, 'assets', p);

const openLib = async (page, tab) => { await page.click('.nav-btn[data-tab="library"]'); await W(200); if (tab) { await page.click(`[data-act="libTab"][data-tab="${tab}"]`); await W(200); } };
const searchFor = async (page, q) => { await page.click('.nav-btn[data-tab="search"]'); await page.fill('#search-input', q); await until(page, () => document.querySelectorAll('#search-body .row-title').length >= 1, null, 8000); };
const importLocal = async (page, files) => { await page.setInputFiles('#file-local', files.map(f => A('local/' + f))); await until(page, () => SONORA.LOCAL.length >= 1 || /not audio|couldn/i.test(document.querySelector('#toasts').innerText), null, 15000); await W(600); };

(async () => {
  const h = await boot();
  T.init(h, process.argv[2]);
  console.log('E2E lib — against local mock Audius at', MOCK);

  /* ---------------- playlists ---------------- */
  await test('playlist: create (name+description+cover upload) via the real dialog', async (page) => {
    await openLib(page, 'playlists');
    await page.click('[data-act="plNew"]');
    await page.fill('#ask-input', 'Road Trip');
    await page.fill('#ask-desc', 'Songs for driving');
    await page.setInputFiles('#cover-file', A('cover/cover1.png'));
    await until(page, () => document.querySelector('#cover-prev img'), null, 6000);
    await page.click('#ask-form button[type="submit"]'); await W(500);
    const p = await ev(page, () => SONORA.LIB.playlists[0]);
    eq(p.name, 'Road Trip', 'name'); eq(p.desc, 'Songs for driving', 'description');
    expect(/^data:image\//.test(p.cover) && p.cover.length < 400000, 'cover stored as a downscaled data URL (' + p.cover.length + ' chars)');
    expect(await ev(page, () => SONORA.UI_STACK.some(i => i.name === 'playlist')), 'opened the new playlist');
    expect(await ev(page, () => /This playlist is empty/.test(document.body.innerText)), 'empty state shown');
    eq(await ev(page, () => document.querySelector('[data-act="playAll"]').disabled), true, 'Play disabled while empty');
  });

  await test('playlist: add songs (sheet search), remove, reorder (menu + drag), rename, play, shuffle, delete', async (page) => {
    await ev(page, () => SONORA.Lib.createPlaylist({ name: 'Mix A', desc: '' }));
    await openLib(page, 'playlists');
    await page.click('.grid-cards .card:has-text("Mix A")'); await W(400);
    // add 4 songs through the "Add songs" sheet (real search against the API)
    await page.click('.action-row [data-act="plAddSongs"]'); await W(400);
    await page.fill('#addsongs-q', 'harbor');
    await until(page, () => document.querySelectorAll('[data-act="addSongTo"]:not([disabled])').length >= 4, null, 8000);
    for (let i = 0; i < 4; i++) { await page.click('[data-act="addSongTo"]:not([disabled]) >> nth=0'); await W(120); }
    await page.keyboard.press('Escape'); await W(400);
    const ids = await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Mix A').tracks.map(t => t.id));
    eq(ids.length, 4, 'four songs added'); eq(new Set(ids).size, 4, 'no duplicates');
    // reorder via the track menu "Move down" on the first row
    await page.click('.rows .row >> nth=0 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="moveDown"]'); await W(300);
    let ids2 = await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Mix A').tracks.map(t => t.id));
    eq(ids2[1], ids[0], 'first track moved down one place'); eq(ids2[0], ids[1], 'second track moved up');
    // reorder via real pointer drag on the grip (touch/mouse)
    await page.click('[data-act="plReorder"]'); await W(300);
    const g = await page.locator('.rows.reorder .row >> nth=0 >> [data-grip]').boundingBox();
    const r3 = await page.locator('.rows.reorder .row >> nth=2').boundingBox();
    await page.mouse.move(g.x + g.width / 2, g.y + g.height / 2); await page.mouse.down();
    await page.mouse.move(g.x + g.width / 2, g.y + g.height / 2 + 12, { steps: 3 });
    await page.mouse.move(g.x + g.width / 2, r3.y + r3.height * 0.7, { steps: 10 }); await page.mouse.up(); await W(400);
    const ids3 = await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Mix A').tracks.map(t => t.id));
    expect(JSON.stringify(ids3) !== JSON.stringify(ids2) && ids3.slice().sort().join() === ids2.slice().sort().join(), 'drag changed the order without losing tracks: ' + ids3);
    eq(ids3[2], ids2[0], 'dragged first row landed in third place');
    await page.click('[data-act="plReorder"]'); await W(200);
    // remove one via the menu
    await page.click('.rows .row >> nth=1 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="menuRemovePl"]'); await W(300);
    eq(await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Mix A').tracks.length), 3, 'removed from playlist');
    // rename + description via the edit dialog
    await page.click('.topbar [data-act="plEdit"]'); await W(400);
    eq(await ev(page, () => document.querySelector('#ask-input').value), 'Mix A', 'dialog prefilled');
    await page.fill('#ask-input', 'Mix Renamed'); await page.fill('#ask-desc', 'now with a description');
    await page.click('#ask-form button[type="submit"]'); await W(400);
    const pl = await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Mix Renamed'));
    expect(pl && pl.desc === 'now with a description', 'renamed + described'); expect(await ev(page, () => /Mix Renamed/.test([...document.querySelectorAll('.view')].filter(v => !v.hidden).pop().innerText)), 'UI shows new name');
    // play + shuffle
    await page.click('.action-row [data-act="playAll"]');
    await until(page, () => SONORA.E.d.el.currentTime > 0.4, null, 9000);
    eq(await ev(page, () => SONORA.Q.ctx.type), 'playlist', 'queue context is the playlist'); eq(await ev(page, () => SONORA.Q.list.length), 3, 'queue = playlist');
    await page.click('.action-row [data-act="shuffleAll"]'); await until(page, () => SONORA.PREFS.shuffle === true, null, 4000);
    // persistence across reload
    await page.reload(); await page.waitForFunction(() => window.SONORA);
    eq(await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Mix Renamed').tracks.length), 3, 'playlist survived reload');
    // delete
    await openLib(page, 'playlists'); await page.click('.grid-cards .card:has-text("Mix Renamed")'); await W(400);
    await page.click('.topbar [data-act="plMenu"]'); await W(300);
    await page.click('[data-act="plDelete"]'); await W(300);
    await page.click('#confirm-ok'); await W(500);
    expect(await ev(page, () => !SONORA.LIB.playlists.some(p => p.name === 'Mix Renamed')), 'deleted');
    expect(await ev(page, () => !SONORA.UI_STACK.some(i => i.name === 'playlist')), 'left the deleted playlist view');
  });

  await test('add to playlist from a song menu (existing + brand-new), duplicates are not added twice', async (page) => {
    await ev(page, () => SONORA.Lib.createPlaylist({ name: 'Existing', desc: '' }));
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    await page.click('#sh-trending .card >> nth=0 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="menuAddPl"]'); await W(400);
    await page.click('.sheet [data-act="addToPl"]'); await W(400);
    eq(await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Existing').tracks.length), 1, 'added to existing');
    await page.click('#sh-trending .card >> nth=0 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="menuAddPl"]'); await W(400); await page.click('.sheet [data-act="addToPl"]'); await W(400);
    eq(await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Existing').tracks.length), 1, 'duplicate ignored');
    await page.click('#sh-trending .card >> nth=3 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="menuAddPl"]'); await W(400); await page.click('.sheet [data-act="addToNewPl"]'); await W(500);
    await page.fill('#ask-input', 'Fresh One'); await page.click('#ask-form button[type="submit"]'); await W(500);
    eq(await ev(page, () => SONORA.LIB.playlists.find(p => p.name === 'Fresh One').tracks.length), 1, 'new playlist created with the song');
  });

  /* ---------------- likes, library views ---------------- */
  await test('likes: persist, appear in Library → Liked, sort A–Z, filter, unlike', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 30 }); ['au:T1', 'au:T4', 'au:T6', 'au:T10'].forEach(id => SONORA.Lib.toggleLike(ts.find(t => t.id === id))); });
    await page.reload(); await page.waitForFunction(() => window.SONORA);
    eq(await ev(page, () => SONORA.LIB.liked.length), 4, 'likes survived reload');
    await openLib(page, 'liked');
    eq(await ev(page, () => document.querySelectorAll('#lib-body .row').length), 4, 'liked rows shown');
    await page.click('[data-act="libSort"][data-sort="az"]'); await W(250);
    const titles = await ev(page, () => [...document.querySelectorAll('#lib-body .row-title')].map(e => e.textContent));
    eq(titles, titles.slice().sort((a, b) => a.localeCompare(b)), 'sorted A–Z');
    await page.fill('#lib-filter', 'mid'); await W(250);
    eq(await ev(page, () => document.querySelectorAll('#lib-body .row').length), 1, 'filter narrows list');
    await page.fill('#lib-filter', 'zzz'); await W(250);
    expect(await ev(page, () => /No matches/.test(document.querySelector('#lib-body').innerText)), 'no-match state');
    await page.fill('#lib-filter', ''); await W(250);
    await page.click('#lib-body .row >> nth=0 >> .row-like'); await W(300);
    eq(await ev(page, () => SONORA.LIB.liked.length), 3, 'unliked via heart');
    // the virtual "Liked songs" playlist opens and plays
    await openLib(page, 'playlists'); await page.click('.card[data-id="liked"]'); await W(400);
    await page.click('.action-row [data-act="playAll"]'); await until(page, () => SONORA.E.d.el.currentTime > 0.4, null, 9000);
    eq(await ev(page, () => SONORA.Q.list.length), 3, 'liked playlist plays');
  });

  await test('artist page: tracks load, follow persists and shows in Library → Artists', async (page) => {
    await searchFor(page, 'neon');
    await page.click('#search-body [data-act="openEntity"] >> nth=0'); await W(900);
    await until(page, () => document.querySelectorAll('.view:last-of-type .row-title, .view .rows .row').length >= 2, null, 8000);
    await page.click('[data-act="followArtist"]'); await W(300);
    eq(await ev(page, () => SONORA.LIB.followed.length), 1, 'followed');
    await page.reload(); await page.waitForFunction(() => window.SONORA);
    eq(await ev(page, () => SONORA.LIB.followed.length), 1, 'follow persisted');
    await openLib(page, 'artists');
    expect(await ev(page, () => /Neon Harbor/.test(document.querySelector('#lib-body').innerText)), 'artist in library');
    await page.click('#lib-body [data-act="openEntity"], #lib-body [data-act="openArtistById"]'); await W(900);
    await page.click('[data-act="followArtist"]'); await W(300);
    eq(await ev(page, () => SONORA.LIB.followed.length), 0, 'unfollowed');
  });

  await test('album page: open from search, play all, save to library; empty album handled', async (page) => {
    await searchFor(page, 'harbor');
    await page.click('[data-act="searchTab"][data-tab="albums"]'); await W(300);
    await page.click('#search-body [data-act="openEntity"] >> nth=0'); await W(900);
    await until(page, () => document.querySelectorAll('.view .rows .row').length >= 3, null, 8000);
    await page.click('.view [data-act="playAll"]'); await until(page, () => SONORA.E.d.el.currentTime > 0.4, null, 9000);
    expect(await ev(page, () => SONORA.Q.list.length >= 3), 'album queued');
    await page.click('.view [data-act="saveList"]'); await W(300);
    eq(await ev(page, () => SONORA.LIB.savedLists.filter(l => l.kind === 'album').length), 1, 'album saved');
    await openLib(page, 'albums'); await W(200);
    expect(await ev(page, () => document.querySelectorAll('#lib-body .card').length === 1), 'in Library → Albums');
    // empty album
    await page.click('.nav-btn[data-tab="search"]'); await page.fill('#search-input', 'empty');
    await until(page, () => document.querySelector('#search-body [data-act="openEntity"]'), null, 8000);
    await page.click('[data-act="searchTab"][data-tab="albums"]'); await W(300);
    await page.click('#search-body [data-act="openEntity"] >> nth=0'); await W(900);
    await until(page, () => /no songs|empty|nothing/i.test(document.querySelector('.view:last-of-type, #views').innerText), null, 6000);
    eq(await ev(page, () => document.querySelector('.view [data-act="playAll"]').disabled), true, 'Play disabled for an empty album');
  });

  await test('explore: every genre / language / category tile opens without errors and shows songs or an honest empty note', async (page) => {
    await page.click('.nav-btn[data-tab="explore"]'); await W(500);
    const cats = await ev(page, () => [...document.querySelectorAll('#tab-explore [data-act="openCat"]')].map(e => e.dataset.cat));
    expect(cats.length >= 12, 'explore has many tiles: ' + cats.length);
    const bad = [];
    for (const c of cats) {
      await ev(page, c => SONORA.ACT.openCat({ dataset: { cat: c } }), c);
      try { await until(page, () => { const v = [...document.querySelectorAll('.view')].pop(); return v && !v.querySelector('.skel, .skeleton') && v.querySelector('.row, .card, .empty, .shelf-note, .notice-inline'); }, null, 6000); }
      catch { bad.push(c + ' (timed out)'); }
      await page.goBack(); await W(150);
    }
    eq(bad, [], 'categories that never settled (' + cats.length + ' tried)');
    eq(await ev(page, () => SONORA.UI_STACK.length), 0, 'stack balanced after visiting all tiles');
  });

  /* ---------------- local music ---------------- */
  await test('local import: real files, tags parsed (ID3 / FLAC / MP4), covers extracted, junk rejected', async (page) => {
    await page.click('.nav-btn[data-tab="library"]');
    await importLocal(page, ['tagged.mp3', 'Plain Wave File.wav', 'lossless.flac', 'aac-sunrise.m4a', 'untagged_song-name.mp3', 'notes.txt', 'corrupt.mp3']);
    const L = await ev(page, () => SONORA.LOCAL.map(t => ({ title: t.title, artist: t.artist, album: t.album, dur: Math.round(t.dur || 0), cover: !!(t.art150 || t.art480), genre: t.genre, year: t.year })));
    const by = n => L.find(x => x.title === n);
    const mp3 = by('Ember Test Tone'); expect(mp3, 'ID3 title parsed: ' + JSON.stringify(L));
    eq(mp3.artist, 'Test Artist', 'ID3 artist'); eq(mp3.album, 'Sine Waves Vol. 1', 'ID3 album'); expect(mp3.cover, 'ID3 APIC cover extracted'); expect(Math.abs(mp3.dur - 12) <= 1, 'duration ' + mp3.dur);
    const flac = by('Lossless Lagoon'); expect(flac, 'FLAC Vorbis title parsed'); eq(flac.artist, 'Flac Artist', 'FLAC artist'); expect(flac.cover, 'FLAC picture extracted'); expect(Math.abs(flac.dur - 10) <= 1, 'flac duration');
    expect(by('Plain Wave File'), 'WAV falls back to the file name'); expect(by('untagged song-name') || by('untagged_song-name') || L.some(x => /untagged/i.test(x.title)), 'untagged mp3 uses file name');
    const canAac = await ev(page, () => !!document.createElement('audio').canPlayType('audio/mp4; codecs="mp4a.40.2"'));
    if (canAac) { const m = by('Aac Sunrise'); expect(m && m.artist === 'M4A Artist' && m.album === 'Mobile Tests', 'MP4 atoms parsed'); expect(m.cover, 'MP4 covr extracted'); }
    else console.log('      (note: this Chromium build has no AAC decoder; m4a is expected to be reported as unplayable here)');
    expect(!L.some(x => /notes/i.test(x.title)), 'notes.txt rejected'); expect(!L.some(x => /corrupt/i.test(x.title)), 'corrupt.mp3 rejected (cannot be decoded)');
    expect(await ev(page, () => /not audio|couldn.t be played/i.test(document.querySelector('#toasts').innerText)), 'user told about rejected files: ' + await ev(page, () => document.querySelector('#toasts').innerText));
    // shown in the On device tab
    await page.click('[data-act="libTab"][data-tab="local"]'); await W(300);
    expect(await ev(page, () => document.querySelectorAll('#lib-body .row').length >= 3), 'rows in On device');
  });

  await test('local playback: real decode, survives reload (IndexedDB), works fully offline', async (page, ctx) => {
    await importLocal(page, ['tagged.mp3', 'lossless.flac']);
    await openLib(page, 'local');
    await page.click('#lib-body .row:has-text("Ember Test Tone")');
    await until(page, () => SONORA.E.d.el.currentTime > 1 && !SONORA.E.d.el.paused, null, 8000);
    let a = await audio(page); expect(a.src.startsWith('blob:'), 'plays from a blob URL, not a network URL'); expect(Math.abs(a.dur - 12) < 1, 'real duration ' + a.dur);
    await page.reload(); await page.waitForFunction(() => window.SONORA && SONORA.LOCAL.length === 2, null, { timeout: 8000 });
    eq(await ev(page, () => SONORA.LOCAL.length), 2, 'library restored from IndexedDB');
    // offline: stop the network entirely, then play FLAC
    await ctx.setOffline(true); await ev(page, () => window.dispatchEvent(new Event('offline')));
    await openLib(page, 'local');
    await page.click('#lib-body .row:has-text("Lossless Lagoon")');
    await until(page, () => SONORA.E.d.el.currentTime > 1 && !SONORA.E.d.el.paused, null, 8000);
    expect(await ev(page, () => !document.querySelector('#netbar').hidden), 'offline bar visible while playing local music');
    await ctx.setOffline(false);
  }, { allowErrors: true });

  await test('local lyrics: embedded USLT shown; .lrc attach scrolls in sync; remove works', async (page) => {
    await importLocal(page, ['tagged.mp3']);
    await openLib(page, 'local'); await page.click('#lib-body .row:has-text("Ember Test Tone")');
    await until(page, () => SONORA.E.d.el.currentTime > 0.3, null, 8000);
    await page.click('.mini-main'); await W(500); await page.click('#np [data-act="npLyrics"]'); await W(500);
    expect(await ev(page, () => /embedded lyrics line one/.test(document.querySelector('#ly-body').innerText)), 'embedded lyrics displayed');
    const [fc] = await Promise.all([page.waitForEvent('filechooser'), page.click('#ly-body [data-act="lyAttach"]')]);
    await fc.setFiles(A('local/tagged.lrc')); await W(600);
    expect(await ev(page, () => document.querySelector('.ly-lines.synced')), 'LRC parsed as synced');
    await ev(page, () => { SONORA.E.d.el.currentTime = 3.4; }); await W(700);
    eq(await ev(page, () => document.querySelector('.ly.on') && document.querySelector('.ly.on').textContent), 'Second synced line', 'current line highlighted at 3.4s');
    await page.click('#ly-body [data-act="lyRemove"]'); await W(400);
    expect(await ev(page, () => /No lyrics for this song/.test(document.querySelector('#ly-body').innerText)), 'lyrics removed');
  });

  await test('lyrics: a genuine ID3 USLT frame (UTF-16 + BOM, accents, ♪) is decoded', async (page) => {
    await importLocal(page, ['uslt-utf16.mp3']);
    const t = await ev(page, () => SONORA.LOCAL[0]);
    eq(t.title, 'Uslt Song é♪', 'UTF-16 title decoded'); eq(t.artist, 'Lyric Artist', 'artist');
    eq(t.lyr, 'Héllo wörld ♪\nLine two of the USLT lyrics', 'USLT lyrics decoded');
    await openLib(page, 'local'); await page.click('#lib-body .row >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.3, null, 8000);
    await page.click('.mini-main'); await W(500); await page.click('#np [data-act="npLyrics"]'); await W(500);
    expect(await ev(page, () => /Line two of the USLT lyrics/.test(document.querySelector('#ly-body').innerText)), 'shown in the lyrics sheet');
  });

  await test('local remove: confirm dialog, entry + playlist membership gone, persists', async (page) => {
    await importLocal(page, ['tagged.mp3', 'lossless.flac']);
    await ev(page, () => { const p = SONORA.Lib.createPlaylist({ name: 'WithLocal', desc: '' }, [SONORA.LOCAL[0]]); });
    await openLib(page, 'local');
    await page.click('#lib-body .row:has-text("Ember Test Tone") [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="removeLocal"]'); await W(300); await page.click('#confirm-ok'); await W(700);
    eq(await ev(page, () => SONORA.LOCAL.length), 1, 'one local song left');
    await page.reload(); await page.waitForFunction(() => window.SONORA && SONORA.LOCAL.length === 1, null, { timeout: 8000 });
    eq(await ev(page, () => SONORA.LOCAL.length), 1, 'still one after reload');
  });

  /* ---------------- offline downloads ---------------- */
  await test('offline download (artist-permitted track): saved to IndexedDB and plays with the network off', async (page, ctx) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    // T1 allows downloads in the mock; T2 does not → menu must not offer it
    await page.click('#sh-trending .card >> nth=1 >> [data-act="trackMenu"]'); await W(300);
    eq(await ev(page, () => !!document.querySelector('[data-act="saveOffline"]')), false, 'no download item for a non-downloadable track');
    await page.keyboard.press('Escape'); await W(300);
    await page.click('#sh-trending .card >> nth=0 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="saveOffline"]');
    await until(page, () => SONORA.LIB.downloads.length === 1, null, 12000);
    expect(await ev(page, async () => { const k = await SONORA.IDB.keys('offline'); return k.length === 1; }), 'blob stored in IndexedDB');
    await ctx.setOffline(true); await ev(page, () => window.dispatchEvent(new Event('offline')));
    await openLib(page, 'downloads');
    await page.click('#lib-body .row >> nth=0');
    await until(page, () => SONORA.E.d.el.currentTime > 1 && !SONORA.E.d.el.paused, null, 9000);
    expect((await audio(page)).src.startsWith('blob:'), 'played from the offline blob');
    await ctx.setOffline(false);
  }, { allowErrors: true });

  /* ---------------- backup / restore ---------------- */
  await test('export → wipe everything → import restores playlists, likes, follows', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 30 }); SONORA.Lib.toggleLike(ts[0]); SONORA.Lib.createPlaylist({ name: 'Backed Up', desc: 'x' }, [ts[1], ts[3]]); });
    const json = await ev(page, () => SONORA.Lib.exportJSON());
    const parsed = JSON.parse(json); eq(parsed.app, 'SONORA', 'export is tagged'); expect(parsed.library.playlists.length === 1 && parsed.library.liked.length === 1, 'export content');
    // wipe through the real settings button + confirm
    await page.click('[data-act="openSettings"]'); await W(400);
    await page.click('[data-act="wipeAll"]'); await W(300); await page.click('#confirm-ok');
    await page.waitForFunction(() => window.SONORA && SONORA.LIB.playlists.length === 0, null, { timeout: 8000 });
    eq(await ev(page, () => SONORA.LIB.liked.length), 0, 'everything wiped');
    // import through the real sheet
    await page.click('.nav-btn[data-tab="library"]'); await page.click('[data-act="libAdd"]'); await W(300); await page.click('[data-act="importLib"]'); await W(400);
    await page.fill('#import-text', 'this is not json'); await page.click('#import-go'); await W(300);
    expect(await ev(page, () => /not valid JSON|not a SONORA backup/i.test(document.querySelector('#toasts').innerText)), 'garbage import gives an error toast, no crash: ' + await ev(page, () => document.querySelector('#toasts').innerText));
    // valid JSON that is not a SONORA backup
    await page.fill('#import-text', '{"hello":1}'); await page.click('#import-go'); await W(300);
    expect(await ev(page, () => /not a SONORA backup/i.test(document.querySelector('#toasts').innerText)), 'wrong-shaped JSON rejected');
    await page.fill('#import-text', json); await page.click('#import-go'); await W(500);
    eq(await ev(page, () => SONORA.LIB.playlists.map(p => p.name)), ['Backed Up'], 'playlist restored'); eq(await ev(page, () => SONORA.LIB.liked.length), 1, 'like restored');
    // second import is idempotent
    await page.click('[data-act="libAdd"]'); await W(300); await page.click('[data-act="importLib"]'); await W(300); await page.fill('#import-text', json); await page.click('#import-go'); await W(400);
    eq(await ev(page, () => SONORA.LIB.playlists.length), 1, 'import does not duplicate');
  });

  await test('export "Download file": real browser download normally; the viewer\'s downloads capability when present', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 5 }); SONORA.Lib.createPlaylist({ name: 'Exported', desc: '' }, [ts[0]]); });
    await page.click('[data-act="openSettings"]'); await W(400);
    await page.click('[data-act="exportLib"]'); await W(300);
    // 1) normal page (no window.claude): a real file download is produced
    const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 5000 }), page.click('#export-dl')]);
    expect(/^sonora-backup-\d{4}-\d{2}-\d{2}\.json$/.test(dl.suggestedFilename()), 'file name: ' + dl.suggestedFilename());
    const file = JSON.parse(fs.readFileSync(await dl.path(), 'utf8'));
    eq(file.app, 'SONORA', 'downloaded file is a SONORA backup'); eq(file.library.playlists.map(p => p.name), ['Exported'], 'backup holds the playlist');
    // 2) inside the artifact viewer: window.claude.use('downloads').save() is used instead of a link
    await ev(page, () => { window.__saves = []; window.__mode = 'ok'; window.claude = { use: async n => n === 'downloads' ? { save: async r => { window.__saves.push(r); if (window.__mode === 'declined') throw { code: 'declined', message: 'no' }; if (window.__mode === 'broken') throw { code: 'unavailable', message: 'x' }; return { status: 'saved' }; } } : null }; });
    let extra = 0; page.on('download', () => extra++);
    await page.click('#export-dl'); await W(400);
    const saves = await ev(page, () => window.__saves);
    eq(saves.length, 1, 'save() called once'); expect(/^sonora-backup-\d{4}-\d{2}-\d{2}\.json$/.test(saves[0].filename), 'viewer filename ' + saves[0].filename);
    eq(JSON.parse(saves[0].data).app, 'SONORA', 'viewer gets the backup JSON'); eq(extra, 0, 'no second (link) download when the capability is used');
    expect(await ev(page, () => /Backup saved/i.test(document.querySelector('#toasts').innerText)), 'success toast');
    // viewer declines: nothing else happens (no error toast, no link download)
    await ev(page, () => { window.__mode = 'declined'; document.querySelector('#toasts').innerHTML = ''; });
    await page.click('#export-dl'); await W(400);
    expect(await ev(page, () => !/Couldn.t save/i.test(document.querySelector('#toasts').innerText)), 'declining is not an error'); eq(extra, 0, 'still no link download');
    // capability breaks: told to use Copy
    await ev(page, () => { window.__mode = 'broken'; });
    await page.click('#export-dl'); await W(400);
    expect(await ev(page, () => /Use Copy instead/i.test(document.querySelector('#toasts').innerText)), 'failure points to Copy');
  });

  const ok = T.report(__dirname + '/results-lib.json');
  await h.close(); process.exit(ok ? 0 : 1);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
