/* PWA check: service worker installs, caches the shell, and the app reloads with the network OFF; manifest is valid. */
const { boot, APP, MOCK } = require('./harness');
const path = require('path'), fs = require('fs');
const W = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const h = await boot(); let ok = true; const fail = m => { ok = false; console.log('  ✗', m); }; const pass = m => console.log('  ✓', m);
  const ctx = await h.browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: 'allow' });
  const page = await ctx.newPage(); const errors = []; page.on('pageerror', e => errors.push(e.message));
  await page.addInitScript(`try{localStorage.setItem('sonora.prefs', JSON.stringify({audiusHost:'${MOCK}'}))}catch(e){}`);
  await page.goto(APP + '/index.html');
  const reg = await page.evaluate(async () => { const r = await navigator.serviceWorker.ready; return { scope: r.scope, active: !!r.active }; }).catch(e => ({ err: e.message }));
  reg.active ? pass('service worker active, scope ' + reg.scope) : fail('service worker not active ' + JSON.stringify(reg));
  await page.setInputFiles('#file-local', [path.join(__dirname, 'assets/local/tagged.mp3')]); await page.waitForFunction(() => SONORA.LOCAL.length === 1, null, { timeout: 10000 });
  await page.reload(); await W(800);                       // second load: SW controls the page, shell gets (re)cached
  await ctx.setOffline(true);
  await page.reload(); await page.waitForFunction(() => window.SONORA, null, { timeout: 8000 }).then(() => pass('app shell reloads with the network OFF'), () => fail('app did not boot offline'));
  await page.waitForFunction(() => SONORA.LOCAL.length === 1, null, { timeout: 8000 }).then(() => pass('local library available offline'), () => fail('local library missing offline'));
  await page.click('.nav-btn[data-tab="library"]'); await page.click('[data-act="libTab"][data-tab="local"]'); await page.click('#lib-body .row >> nth=0');
  await page.waitForFunction(() => SONORA.E.d.el.currentTime > 0.8 && !SONORA.E.d.el.paused, null, { timeout: 9000 }).then(() => pass('local song plays offline after a cold reload'), () => fail('offline playback failed'));
  await ctx.setOffline(false);
  const m = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'dist', 'manifest.webmanifest'), 'utf8'));
  const files = m.icons.map(i => i.src).filter(s => !fs.existsSync(path.join(__dirname, '..', 'dist', s)));
  files.length === 0 && m.display === 'standalone' && m.start_url ? pass('manifest valid; all ' + m.icons.length + ' icon files exist') : fail('manifest problem ' + files);
  errors.length ? fail('page errors ' + errors) : pass('no page errors');
  await h.close(); process.exit(ok ? 0 : 1);
})().catch(e => { console.error(e); process.exit(2); });
