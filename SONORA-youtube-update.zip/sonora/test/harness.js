/* Shared test harness: static server for dist/, mock Audius, Playwright launch helpers. */
const http = require('http'), fs = require('fs'), path = require('path');
const { chromium } = require('playwright');
const mock = require('./mock-audius');
const DIST = path.join(__dirname, '..', 'dist');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png' };

function staticServer(port) {
  return new Promise(res => {
    const s = http.createServer((req, rs) => {
      let p = decodeURIComponent(req.url.split('?')[0]); if (p.endsWith('/')) p += 'index.html';
      const f = path.join(DIST, p);
      if (!f.startsWith(DIST)) { rs.statusCode = 403; return rs.end(); }
      fs.readFile(f, (e, b) => { if (e) { rs.statusCode = 404; return rs.end('nf'); } rs.setHeader('Content-Type', MIME[path.extname(f)] || 'application/octet-stream'); rs.setHeader('Cache-Control', 'no-store'); rs.end(b); });
    }).listen(port, '127.0.0.1', () => res(s));
  });
}
const APP = 'http://127.0.0.1:4000', MOCK = 'http://127.0.0.1:4010';

async function boot({ headless = true } = {}) {
  const servers = [await staticServer(4000), await mock.start(4010)];
  const browser = await chromium.launch({ headless, ...(process.env.PW_CHANNEL ? { channel: process.env.PW_CHANNEL } : {}), args: ['--autoplay-policy=no-user-gesture-required', '--use-fake-ui-for-media-stream'] });
  return { browser, close: async () => { await browser.close(); servers.forEach(s => s.close()); } };
}
async function newPage(browser, { prefs = {}, viewport = { width: 390, height: 844 }, mobile = true, errors = [], init } = {}) {
  const ctx = await browser.newContext({ viewport, deviceScaleFactor: 2, isMobile: mobile, hasTouch: mobile, acceptDownloads: true, serviceWorkers: 'block' });
  const page = await ctx.newPage();
  page.on('pageerror', e => errors.push('pageerror: ' + e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push('console.error: ' + m.text()); });
  const P = JSON.stringify(Object.assign({ audiusHost: MOCK }, prefs));
  await page.addInitScript(`try{ if(!localStorage.getItem('sonora.prefs') && !sessionStorage.getItem('__seeded')) { localStorage.setItem('sonora.prefs', ${JSON.stringify(P)}); sessionStorage.setItem('__seeded','1'); } }catch(e){}`);
  if (init) await page.addInitScript(init);
  return { ctx, page, errors };
}
const ctl = q => fetch(`${MOCK}/__ctl?${q}`).then(r => r.json());
const mlog = (clear) => fetch(`${MOCK}/__log${clear ? '?clear=1' : ''}`).then(r => r.json());
module.exports = { boot, newPage, ctl, mlog, APP, MOCK, DIST };
