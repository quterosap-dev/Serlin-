/* E2E group 3: speed, equalizer (CORS + no-CORS + signal check), crossfade, sleep timer, session restore, settings/themes,
   data saver, stats, Jamendo/Archive parsing (stubbed), restricted-environment behaviour, layout at several viewports, contrast. */
const { boot, mlog, ctl, MOCK, APP, newPage } = require('./harness');
const T = require('./lib');
const { test, expect, eq, ev, audio, until, W } = T;
const fs = require('fs'), path = require('path');
const A = p => path.join(__dirname, 'assets', p);
const play0 = async page => { await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5); await page.click('#sh-trending .card >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.6 && !SONORA.E.d.el.paused, null, 9000); };
const openSound = async page => { await page.click('.mini-main'); await W(500); await page.click('#np-sound'); await W(500); };
/* RMS of the signal coming OUT of the EQ chain (tap an analyser on the last filter) */
const eqSignal = page => page.evaluate(async () => {
  const g = SONORA.E.graph; if (!g) return -1;
  const an = g.ctx.createAnalyser(); an.fftSize = 2048; g.filters[g.filters.length - 1].connect(an);
  const buf = new Float32Array(an.fftSize); let max = 0;
  for (let i = 0; i < 8; i++) { await new Promise(r => setTimeout(r, 120)); an.getFloatTimeDomainData(buf); let s = 0; for (const v of buf) s += v * v; max = Math.max(max, Math.sqrt(s / buf.length)); }
  return { rms: max, state: g.ctx.state };
});

(async () => {
  const h = await boot();
  T.init(h, process.argv[2]);
  console.log('E2E extra — against local mock Audius at', MOCK);

  /* ---------------- speed ---------------- */
  await test('speed: applies to the element, survives track change and reload', async (page) => {
    await play0(page); await openSound(page);
    await page.click('[data-act="setSpeed"][data-val="1.5"]'); await W(200);
    eq((await audio(page)).rate, 1.5, 'playbackRate 1.5');
    await page.keyboard.press('Escape'); await page.keyboard.press('Escape'); await W(400);
    await ev(page, () => SONORA.PL.next()); await until(page, () => SONORA.E.d.el.currentTime > 0.5, null, 9000);
    eq((await audio(page)).rate, 1.5, 'kept after next track');
    // the position advances faster than real time
    const t0 = (await audio(page)).t; await W(2000); const dt = (await audio(page)).t - t0; expect(dt > 2.4 && dt < 3.6, 'advanced ~1.5× real time: ' + dt.toFixed(2) + 's in 2s');
    await page.reload(); await page.waitForFunction(() => window.SONORA);
    eq(await ev(page, () => SONORA.PREFS.speed), 1.5, 'speed persisted');
    await page.click('.mini-play'); await until(page, () => SONORA.E.d.el.currentTime > 0.3 && !SONORA.E.d.el.paused, null, 9000);
    eq((await audio(page)).rate, 1.5, 'applied after reload');
  });

  /* ---------------- equalizer ---------------- */
  await test('EQ (server allows CORS): real signal flows through the filter chain; presets and sliders change gains; position kept', async (page) => {
    await play0(page); await W(1200);
    const t0 = (await audio(page)).t;
    await openSound(page);
    await page.click('[data-act="togglePref"][data-pref="eqOn"]');
    await until(page, () => SONORA.PREFS.eq.on === true && SONORA.E.cors === true && SONORA.E.graph, null, 6000);
    await until(page, () => SONORA.E.d.el.currentTime > 0.5 && !SONORA.E.d.el.paused, null, 9000);
    expect((await audio(page)).t >= t0 - 1.5, 'resumed near where it was (' + t0.toFixed(1) + ' → ' + (await audio(page)).t.toFixed(1) + ')');
    const sig = await eqSignal(page); expect(sig.rms > 0.005, 'audible signal at the end of the EQ chain, rms=' + (sig.rms || 0).toFixed(4) + ' ctx=' + sig.state);
    await page.click('[data-act="eqPreset"][data-preset="bass"]'); await W(200);
    const g1 = await ev(page, () => SONORA.E.graph.filters.map(f => Math.round(f.gain.value * 10) / 10));
    expect(g1[0] > 2, 'bass preset boosts 60 Hz: ' + g1);
    await ev(page, () => { const s = document.querySelector('[data-range="eq"][data-i="4"]'); s.value = -6; s.dispatchEvent(new Event('input', { bubbles: true })); });
    await W(150);
    eq(await ev(page, () => Math.round(SONORA.E.graph.filters[4].gain.value)), -6, 'slider sets the 14 kHz gain');
    // turn it off again: plain element, still playing
    await page.click('[data-act="togglePref"][data-pref="eqOn"]'); await W(500);
    await until(page, () => SONORA.PREFS.eq.on === false && SONORA.E.cors === false && SONORA.E.d.el.currentTime > 0.3 && !SONORA.E.d.el.paused, null, 9000);
  });

  await test('EQ remembered across restart: engine is rebuilt with the graph (UI never claims EQ on when it is not)', async (page) => {
    await play0(page); await openSound(page);
    await page.click('[data-act="togglePref"][data-pref="eqOn"]'); await until(page, () => SONORA.E.cors === true, null, 6000);
    await page.reload(); await page.waitForFunction(() => window.SONORA);
    eq(await ev(page, () => [SONORA.PREFS.eq.on, SONORA.E.cors, !!SONORA.E.graph]), [true, true, true], 'engine rebuilt at launch');
    await page.click('.mini-play'); await until(page, () => SONORA.E.d.el.currentTime > 0.5 && !SONORA.E.d.el.paused, null, 9000);
    const sig = await eqSignal(page); expect(sig.rms > 0.005, 'signal passes through the chain after restart rms=' + (sig.rms || 0).toFixed(4));
  });

  await test('EQ when the server forbids CORS: falls back to plain playback, EQ switched off, says why, music keeps playing', async (page) => {
    await play0(page); await openSound(page);
    await ctl('cors=0');                                         // from now on the audio host sends no CORS headers
    await page.click('[data-act="togglePref"][data-pref="eqOn"]');
    await until(page, () => SONORA.PREFS.eq.on === false && /equalizer needs audio sources/i.test(document.querySelector('#toasts').innerText), null, 12000);
    await until(page, () => SONORA.E.cors === false && SONORA.E.d.el.currentTime > 0.4 && !SONORA.E.d.el.paused, null, 12000);
    expect(await ev(page, () => !document.querySelector('[data-pref="eqOn"][aria-checked="true"], [data-pref="eqOn"].on')), 'toggle shows off');
  }, { allowErrors: true });

  /* ---------------- crossfade ---------------- */
  await test('crossfade: two decks overlap, next track takes over, volumes end correct', async (page) => {
    await ev(page, () => SONORA.setPref('crossfade', 3));
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 30 }); SONORA.PL.play([ts.find(t => t.id === 'au:T1'), ts.find(t => t.id === 'au:T2')], 0, { type: 'test', name: 'Test' }); });
    await until(page, () => SONORA.E.d.el.currentTime > 0.6, null, 9000);
    await ev(page, () => { SONORA.E.d.el.currentTime = SONORA.E.d.el.duration - 4.2; });
    await until(page, () => !!SONORA.E.fading, null, 9000);
    await W(1200);
    const both = await ev(page, () => ({ playing: SONORA.E.decks.filter(d => !d.el.paused).length, vols: SONORA.E.decks.map(d => +d.el.volume.toFixed(2)), idx: SONORA.Q.idx }));
    eq(both.playing, 2, 'both decks playing during the fade'); expect(both.vols[0] > 0 && both.vols[1] > 0 && both.vols[0] < 1 && both.vols[1] < 1, 'both partially audible ' + both.vols);
    await until(page, () => SONORA.Q.idx === 1 && !SONORA.E.fading, null, 9000);
    const end = await ev(page, () => ({ playing: SONORA.E.decks.filter(d => !d.el.paused).length, vol: +SONORA.E.d.el.volume.toFixed(2), master: SONORA.PREFS.volume, title: SONORA.Q.list[SONORA.Q.idx].title }));
    eq(end.playing, 1, 'one deck left playing'); expect(Math.abs(end.vol - end.master) < 0.02, 'volume restored to master ' + end.vol + ' vs ' + end.master);
    expect(!(await audio(page)).paused && (await audio(page)).t > 1, 'next track playing');
  });

  await test('crossfade is skipped with Data saver on, repeat-one, or when the next track is unplayable', async (page) => {
    await ev(page, () => { SONORA.setPref('crossfade', 3); SONORA.setPref('dataSaver', true); });
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 30 }); SONORA.PL.play([ts.find(t => t.id === 'au:T1'), ts.find(t => t.id === 'au:T2')], 0, { type: 'test', name: 'Test' }); });
    await until(page, () => SONORA.E.d.el.currentTime > 0.6, null, 9000);
    await ev(page, () => { SONORA.E.d.el.currentTime = SONORA.E.d.el.duration - 2.5; }); await W(1200);
    eq(await ev(page, () => !!SONORA.E.fading), false, 'no fade under data saver');
    await until(page, () => SONORA.Q.idx === 1, null, 9000);   // still advances normally
  });

  /* ---------------- sleep timer ---------------- */
  await test('sleep timer: "end of track" stops playback instead of advancing; timed mode fades out, pauses, restores volume', async (page) => {
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 30 }); SONORA.PL.play([ts.find(t => t.id === 'au:T4'), ts.find(t => t.id === 'au:T1')], 0, { type: 'test', name: 'Test' }); });
    await until(page, () => SONORA.E.d.el.currentTime > 0.5, null, 9000);
    await page.click('.mini-main'); await W(500); await page.click('#np-sleep'); await W(400);
    await page.click('[data-act="sleepSet"][data-m="track"]'); await W(300);
    eq(await ev(page, () => SONORA.Sleep.mode), 'track', 'armed');
    await ev(page, () => { SONORA.E.d.el.currentTime = SONORA.E.d.el.duration - 1.0; });
    await until(page, () => SONORA.PS.playing === false, null, 9000);
    eq(await ev(page, () => SONORA.Q.idx), 0, 'did not advance to the next track');
    // timed mode (use a tiny duration through the same API the sheet uses)
    await page.click('#np [data-act="toggle"]'); await until(page, () => SONORA.PS.playing, null, 6000);
    await ev(page, () => SONORA.Sleep.set(0.04));            // 2.4 s
    expect(await ev(page, () => SONORA.Sleep.mode === 'time' && SONORA.Sleep.remaining() > 1500), 'timer armed');
    await until(page, () => SONORA.E.d.el.volume < SONORA.PREFS.volume * 0.9, null, 8000);   // fading
    await until(page, () => SONORA.PS.playing === false && SONORA.Sleep.mode === null, null, 12000);
    await W(300);
    expect(Math.abs((await audio(page)).vol - (await ev(page, () => SONORA.PREFS.volume))) < 0.02, 'volume restored after the fade so the next play is audible');
    expect(await ev(page, () => /Sleep timer finished/.test(document.querySelector('#toasts').innerText)), 'user told');
  });

  /* ---------------- session restore ---------------- */
  await test('session restore: same track + position, paused (never autoplays), resumes on tap', async (page) => {
    await play0(page); await ev(page, () => { SONORA.E.d.el.currentTime = 12; }); await W(1500);
    await page.click('.mini-play'); await W(300);
    const title = await ev(page, () => SONORA.Q.list[SONORA.Q.idx].title), pos = (await audio(page)).t;
    await W(800);   // let the periodic/pause save run
    await page.reload(); await page.waitForFunction(() => window.SONORA); await W(1200);
    expect(await ev(page, () => !document.querySelector('#mini').hidden), 'mini-player restored');
    eq(await ev(page, () => SONORA.Q.list[SONORA.Q.idx].title), title, 'same track');
    eq(await ev(page, () => SONORA.PS.playing), false, 'not playing after launch');
    await page.click('.mini-play'); await until(page, () => SONORA.E.d.el.currentTime > 0.3 && !SONORA.E.d.el.paused, null, 9000);
    expect((await audio(page)).t > pos - 3, 'resumed near the saved position ' + pos.toFixed(1) + ' → ' + (await audio(page)).t.toFixed(1));
  });

  /* ---------------- settings ---------------- */
  await test('settings: theme (dark/light/system), accent, persist across reload', async (page) => {
    await page.click('[data-act="openSettings"]'); await W(400);
    const bg = () => ev(page, () => getComputedStyle(document.body).backgroundColor);
    const dark = await bg();
    await page.click('[data-act="setPref"][data-pref="theme"][data-val="light"]'); await W(300);
    eq(await ev(page, () => document.documentElement.dataset.theme), 'light', 'data-theme=light'); const light = await bg(); expect(light !== dark, 'background changed ' + dark + ' → ' + light);
    await page.click('[data-act="setPref"][data-pref="accent"][data-val="violet"], [data-act="setPref"][data-pref="accent"] >> nth=1'); await W(200);
    expect(await ev(page, () => !!document.documentElement.dataset.accent), 'accent attribute applied');
    await page.reload(); await page.waitForFunction(() => window.SONORA);
    eq(await ev(page, () => document.documentElement.dataset.theme), 'light', 'theme persisted'); eq(await bg(), light, 'same colours after reload');
    await page.click('[data-act="openSettings"]'); await W(400);
    await page.click('[data-act="setPref"][data-pref="theme"][data-val="system"]'); await W(200);
    await page.emulateMedia({ colorScheme: 'dark' }); await W(300); const sysDark = await bg();
    await page.emulateMedia({ colorScheme: 'light' }); await W(300); const sysLight = await bg();
    expect(sysDark !== sysLight, 'System follows prefers-color-scheme: ' + sysDark + ' vs ' + sysLight);
  });

  await test('data saver: smaller artwork only, no big images requested', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    await page.click('[data-act="openSettings"]'); await W(400);
    await page.click('[data-act="togglePref"][data-pref="dataSaver"]'); await W(300);
    eq(await ev(page, () => SONORA.PREFS.dataSaver), true, 'toggle turned data saver on');
    await page.click('.topbar [data-act="back"], [data-act="back"]'); await W(400);
    await mlog(true);
    await page.click('[data-act="homeRefresh"]'); await until(page, () => document.querySelectorAll('#sh-trending .card img').length >= 3, null, 8000); await W(800);
    const art = (await mlog()).filter(l => l.url.startsWith('/ART/'));
    expect(art.length > 0, 'artwork was requested');
    expect(art.every(l => /s=150/.test(l.url)), 'only small artwork requested: ' + [...new Set(art.map(l => l.url.split('?')[1]))]);
    eq(await ev(page, () => document.documentElement.hasAttribute('data-saver')), true, 'data-saver attribute set');
  });

  await test('stats: a counted play shows in History/Recent and in the Stats screen', async (page) => {
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 30 }); SONORA.PL.play([ts.find(t => t.id === 'au:T4')], 0, { type: 'test', name: 'Test' }); });
    await until(page, () => SONORA.E.d.el.currentTime > 0.5, null, 9000);
    // a play counts after genuinely listening to 50% of a short track (seeking does not count, by design)
    await until(page, () => SONORA.LIB.stats.plays === 1, null, 16000);
    eq(await ev(page, () => SONORA.LIB.history.length), 1, 'history entry');
    await page.click('.nav-btn[data-tab="library"]'); await page.click('[data-act="openStats"]'); await W(500);
    const txt = await ev(page, () => [...document.querySelectorAll('.view')].filter(v => !v.hidden).pop().innerText);
    expect(/Afterimage|Fault|Hollow|Low Tide|Paper|Midnight|Salt|Chrome/.test(txt) || /1\s*(play|song)/i.test(txt), 'stats mention the played song: ' + txt.slice(0, 200).replace(/\n/g, ' | '));
    expect(/listen|minutes|time|seconds|plays/i.test(txt), 'stats show listening numbers');
  });

  /* ---------------- other providers (client parsing only — stubbed, NOT live) ---------------- */
  await test('Jamendo (STUBBED response in documented shape): enabled with a client id, results parsed, plays, failure handled', async (page) => {
    await page.route('https://api.jamendo.com/**', route => route.fulfill({ status: 200, contentType: 'application/json', headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ headers: { status: 'success', code: 0 }, results: [{ id: '1001', name: 'Jam Stub Song', artist_id: '77', artist_name: 'Stub Artist', album_name: 'Stub LP', duration: 40, image: MOCK + '/ART/5?s=300', audio: MOCK + '/media/s2.mp3', audiodownload_allowed: false, license_ccurl: 'https://creativecommons.org/licenses/by/4.0/', releasedate: '2025-01-01', shareurl: 'https://www.jamendo.com/track/1001', musicinfo: { tags: { genres: ['electronic'] } } }] }) }));
    await ev(page, () => { SONORA.setPref('jamendoId', 'testclient'); SONORA.setPref('useJamendo', true); SONORA.CACHE.clear(); });
    await page.click('.nav-btn[data-tab="search"]'); await page.fill('#search-input', 'stub');
    await until(page, () => /Jam Stub Song/.test(document.querySelector('#search-body').innerText), null, 8000);
    expect(await ev(page, () => /Jamendo/.test(document.querySelector('#search-body').innerText)), 'source badge shown');
    await page.click('#search-body .row:has-text("Jam Stub Song")');
    await until(page, () => SONORA.E.d.el.currentTime > 0.6 && !SONORA.E.d.el.paused, null, 9000);
    eq(await ev(page, () => SONORA.Q.list[SONORA.Q.idx].src), 'jamendo', 'played through the jamendo path');
    // failure response from the provider
    await page.unroute('https://api.jamendo.com/**');
    await page.route('https://api.jamendo.com/**', route => route.fulfill({ status: 200, contentType: 'application/json', headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ headers: { status: 'failed', error_message: 'invalid client_id' }, results: [] }) }));
    await ev(page, () => SONORA.CACHE.clear()); await page.fill('#search-input', 'other'); await W(1800);
    expect(await ev(page, () => document.querySelectorAll('#search-body .row-title').length >= 1 || /problem|couldn|error/i.test(document.querySelector('#search-body').innerText)), 'one provider failing does not blank the whole search (Audius results still shown)');
  }, { allowErrors: true });

  await test('Internet Archive (STUBBED, experimental): search parsed, stream URL resolved from file list', async (page) => {
    await page.route('https://archive.org/advancedsearch.php**', route => route.fulfill({ status: 200, contentType: 'application/json', headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ response: { docs: [{ identifier: 'stub-item', title: 'Archive Stub Recording', creator: ['Stub Collective'], licenseurl: 'https://creativecommons.org/publicdomain/zero/1.0/' }] } }) }));
    await page.route('https://archive.org/metadata/**', route => route.fulfill({ status: 200, contentType: 'application/json', headers: { 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ files: [{ name: 'cover.jpg', format: 'JPEG' }, { name: 'tone.mp3', format: 'VBR MP3' }] }) }));
    await page.route('https://archive.org/download/**', route => route.fulfill({ status: 200, contentType: 'audio/mpeg', headers: { 'Access-Control-Allow-Origin': '*' }, body: fs.readFileSync(A('stream/s1.mp3')) }));
    await page.route('https://archive.org/services/img/**', route => route.fulfill({ status: 200, contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10"/>' }));
    await ev(page, () => { SONORA.setPref('useArchive', true); SONORA.CACHE.clear(); });
    await page.click('.nav-btn[data-tab="search"]'); await page.fill('#search-input', 'stub');
    await until(page, () => /Archive Stub Recording/.test(document.querySelector('#search-body').innerText), null, 8000);
    await page.click('#search-body .row:has-text("Archive Stub Recording")');
    await until(page, () => SONORA.E.d.el.currentTime > 0.6 && !SONORA.E.d.el.paused, null, 9000);
    expect((await audio(page)).src.includes('archive.org/download/stub-item/tone.mp3'), 'resolved file URL: ' + (await audio(page)).src);
  }, { allowErrors: true });

  /* ---------------- restricted environments ---------------- */
  await test('network entirely blocked + default (real) host: clear messaging, retry control, no crash, local music still works', async (page, ctx) => {
    // (this is what the Claude artifact viewer / an offline phone looks like to the app)
    await page.goto('about:blank');
    await page.route('**/*', r => (r.request().url().startsWith(APP) ? r.continue() : r.abort('blockedbyclient')));
    await page.addInitScript(() => { try { localStorage.setItem('sonora.prefs', JSON.stringify({})); } catch { } });
    await page.goto(APP + '/index.html'); await page.waitForFunction(() => window.SONORA); await W(2500);
    expect(await ev(page, () => !document.querySelector('#netbar').hidden && /Can.t reach/i.test(document.querySelector('#netbar').innerText)), 'connection banner shown');
    expect(await ev(page, () => document.querySelectorAll('#tab-home [data-act="retryShelf"], #tab-home [data-act="netRetry"]').length >= 1), 'retry controls present');
    expect(await ev(page, () => !document.querySelector('.skel') ), 'no endless skeleton loaders');
    await page.setInputFiles('#file-local', [A('local/tagged.mp3')]); await until(page, () => SONORA.LOCAL.length === 1, null, 10000);
    await page.click('.nav-btn[data-tab="library"]'); await page.click('[data-act="libTab"][data-tab="local"]');
    await page.click('#lib-body .row >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.8 && !SONORA.E.d.el.paused, null, 9000);
  }, { allowErrors: true, noGoto: true });

  await test('Artifact build (fragment in the viewer skeleton, strict CSP, no network): renders, no script errors, shows degraded-mode message', async (page, ctx, errors) => {
    const frag = fs.readFileSync(path.join(__dirname, '..', 'dist', 'artifact.html'), 'utf8');
    const doc = `<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style></head><body>${frag}</body></html>`;
    const csp = "default-src 'none'; script-src 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src data: blob:; media-src blob: data:; connect-src 'none'";
    await page.route('http://sonora.test/artifact', r => r.fulfill({ status: 200, contentType: 'text/html', headers: { 'Content-Security-Policy': csp }, body: doc }));
    await page.goto('http://sonora.test/artifact'); await page.waitForFunction(() => window.SONORA, null, { timeout: 8000 }); await W(2500);
    expect(await ev(page, () => document.title === 'SONORA'), 'title');
    expect(await ev(page, () => document.querySelector('#nav .nav-btn')), 'app shell rendered');
    expect(await ev(page, () => /Can.t reach|restricted preview|offline/i.test(document.body.innerText)), 'honest degraded-mode message under the strict CSP');
    const real = errors.filter(e => !/Content Security Policy|Refused to|Failed to load|ERR_|fonts\./i.test(e)); eq(real, [], 'no JS errors besides CSP refusals');
    errors.length = 0;
  }, { allowErrors: true, noGoto: true });

  /* ---------------- layout, overflow, contrast ---------------- */
  for (const [w, hgt, label] of [[320, 568, 'small phone 320'], [360, 740, 'phone 360'], [768, 1024, 'tablet'], [1440, 900, 'desktop']]) {
    await test(`layout @${label}: no horizontal overflow on any tab, Now Playing or sheets`, async (page) => {
      await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
      const over = async name => { const r = await ev(page, () => { const e = document.documentElement; const clipped = el => { for (let n = el.parentElement; n && n !== document.body; n = n.parentElement) { const o = getComputedStyle(n).overflowX; if (o !== 'visible') { const b = n.getBoundingClientRect(); if (b.right <= innerWidth + 1 && b.left >= -1) return true; } } return false; };
      const bad = [...document.querySelectorAll('body *')].filter(el => { if (el instanceof SVGElement) return false; const b = el.getBoundingClientRect(); return b.width > 0 && b.right > innerWidth + 1 && !clipped(el) && getComputedStyle(el).position !== 'fixed'; }).slice(0, 3).map(el => el.tagName + '.' + String(el.className)); return { sw: e.scrollWidth, iw: innerWidth, bad }; }); expect(r.sw <= r.iw + 1 && r.bad.length === 0, name + ' overflows: ' + JSON.stringify(r)); };
      for (const t of ['home', 'explore', 'search', 'library']) { await page.click(`.nav-btn[data-tab="${t}"]`); await W(500); await over(t); }
      await page.click('.nav-btn[data-tab="home"]'); await page.click('#sh-trending .card >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.4, null, 9000);
      await page.keyboard.press('n'); await W(700); await over('now playing');
      const art = await ev(page, () => { const b = document.querySelector('#np-art').getBoundingClientRect(); return [Math.round(b.width), Math.round(b.height), Math.round(b.bottom), innerHeight]; });
      expect(art[0] >= 120 && art[1] >= 120, 'artwork visible at this size ' + art);
      await page.click('#np-sound'); await W(500); await over('sound sheet'); await page.keyboard.press('Escape'); await W(300);
      const ctlBottom = await ev(page, () => document.querySelector('#np-play').getBoundingClientRect().bottom <= innerHeight + 1);
      expect(ctlBottom, 'play button inside the viewport on Now Playing');
    }, { viewport: { width: w, height: hgt }, mobile: w < 800 });
  }

  await test('contrast: text vs background meets WCAG AA (4.5:1) in dark and light themes, for every accent colour', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    const measure = () => ev(page, () => {
      const parse = c => { const m = c.match(/[\d.]+/g).map(Number); return { r: m[0], g: m[1], b: m[2], a: m[3] == null ? 1 : m[3] }; };
      const lum = ({ r, g, b }) => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
      const bgOf = el => { const stack = []; for (let n = el; n; n = n.parentElement) { const c = parse(getComputedStyle(n).backgroundColor); if (c.a > 0) stack.push(c); if (c.a >= 1) break; } let base = { r: 255, g: 255, b: 255 }; for (let i = stack.length - 1; i >= 0; i--) { const c = stack[i]; base = { r: c.r * c.a + base.r * (1 - c.a), g: c.g * c.a + base.g * (1 - c.a), b: c.b * c.a + base.b * (1 - c.a) }; } return base; };
      const ratio = el => { const fg = parse(getComputedStyle(el).color), bg = bgOf(el); const l1 = lum(fg), l2 = lum(bg); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); };
      const picks = { 'section title': '#sh-trending .sec-title, #tab-home h2', 'card title': '#sh-trending .card-title', 'card subtitle': '#sh-trending .card-sub', 'section subtitle': '#sh-trending .sec-sub', 'greeting': '#tab-home h1', 'nav label': '#nav .nav-btn:not(.on) span', 'active nav label': '#nav .nav-btn.on span', 'see all link': '#sh-trending .link-btn' };
      const out = {}; for (const [k, sel] of Object.entries(picks)) { const el = document.querySelector(sel); if (el) out[k] = +ratio(el).toFixed(2); } return out;
    });
    const fails = [], table = {};
    for (const theme of ['dark', 'light']) for (const accent of ['ember', 'iris', 'lagoon', 'sun']) {
      await ev(page, ([t, a]) => { SONORA.setPref('theme', t); SONORA.setPref('accent', a); }, [theme, accent]); await W(250);
      const r = await measure(); table[theme + '/' + accent] = r;
      for (const [k, v] of Object.entries(r)) if (v < 4.5) fails.push(`${theme}/${accent}/${k}=${v}`);
    }
    console.log('      min ratios:', JSON.stringify(Object.fromEntries(Object.entries(table).map(([k, r]) => [k, Math.min(...Object.values(r))]))));
    eq(fails, [], 'contrast below 4.5:1');
  });

  const ok = T.report(__dirname + '/results-extra.json');
  await h.close(); process.exit(ok ? 0 : 1);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
