#!/usr/bin/env node
/* Local MOCK of the Audius REST API (documented v1 shapes) for testing SONORA.
 * This is NOT Audius. It exists because the live API cannot be reached from the build sandbox.
 * Results from tests run against it prove SONORA's client logic and real <audio> playback, not Audius uptime.
 *
 *   node test/mock-audius.js [port]      (default 4010)
 *
 * Control endpoint (tests flip behaviour at runtime):
 *   GET /__ctl?cors=0|1 &delay=ms &fail=<substring>:<status>[,...] &reset=1
 *   GET /__log   -> JSON array of requests seen    GET /__log?clear=1
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const STREAM_DIR = path.join(__dirname, 'assets', 'stream');
const STATE = { cors: true, delay: 0, fail: [], log: [] };
const reset = () => { STATE.cors = true; STATE.delay = 0; STATE.fail = []; };

/* ---------- data ---------- */
const GENRES = ['Electronic', 'Hip-Hop/Rap', 'Rock', 'Ambient', 'Pop', 'Lo-Fi'];
const USERS = [
  ['u1', 'Neon Harbor', 'neonharbor', 12840, true], ['u2', 'Lagoon Kids', 'lagoonkids', 5120, false],
  ['u3', 'Ada & The Amps', 'adaamps', 880, false], ['u4', 'Quiet Orbit', 'quietorbit', 23100, true],
  ['u5', 'DJ Müller', 'djmuller', 410, false], ['u6', '東京ナイト', 'tokyonight', 3300, false]
].map(([id, name, handle, followers, verified]) => ({ id, name, handle, follower_count: followers, is_verified: verified, track_count: 0 }));

const TITLES = [
  'Midnight Circuit', 'Ember Glow', 'Salt & Static', 'Paper Planes', 'Low Tide Lullaby', 'Chrome Hearts',
  'Velvet Hours', 'Run It Back', 'Glass Garden', 'Hollow Moon', 'Sunday Static', 'Afterimage',
  'Coastline', 'Tape Hiss Dreams', 'Neon Rain', 'Slow Burn', 'Orbit Decay', 'The Long Way Home',
  'Back Alley Beats', 'Daybreak', 'Fault Lines', 'Marigold', 'Quiet Storm', 'Last Train Out'
];
const TRACKS = TITLES.map((title, i) => {
  const user = USERS[i % USERS.length];
  const n = i + 1;
  return {
    id: 'T' + n, title, genre: GENRES[i % GENRES.length], mood: ['Energizing', 'Peaceful', 'Yearning'][i % 3],
    duration: i % 8 === 3 ? 14 : 40, play_count: 100000 - i * 3000, favorite_count: 50 + i, repost_count: 5 + i,
    release_date: `2026-0${(i % 9) + 1}-1${i % 9}`, created_at: `2026-0${(i % 9) + 1}-1${i % 9}T10:00:00Z`,
    permalink: `/${user.handle}/${title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`,
    is_streamable: true, access: { stream: true, download: i % 5 === 0 }, user,
    file: 's' + ((i % 6) + 1) + '.mp3',
    artwork: i === 6 ? null : art(n)
  };
});
// special cases
TRACKS[1].title = `<b>Tom & Jerry's "Test"</b> <img src=x onerror=alert(1)>`;   // escaping check
TRACKS[2].is_streamable = false; TRACKS[2].access = { stream: false, download: false };   // not streamable
TRACKS[3].duration = 14;                                                                  // short, uses s4.mp3 (14s)
TRACKS[3].file = 's4.mp3';
TRACKS[4].artwork = null;                                                                 // no artwork
TRACKS[8].file = 'missing.mp3';                                                           // stream 404

function art(n) {
  return { '150x150': `ART/${n}?s=150`, '480x480': `ART/${n}?s=480`, '1000x1000': `ART/${n}?s=1000` };
}
USERS.forEach(u => { u.track_count = TRACKS.filter(t => t.user.id === u.id).length; });
USERS.forEach((u, i) => { u.profile_picture = { '150x150': `ART/${i + 40}?s=150`, '480x480': `ART/${i + 40}?s=480`, '1000x1000': `ART/${i + 40}?s=1000` }; });
USERS[4].profile_picture = null;

const LISTS = [
  { id: 'P1', playlist_name: 'Night Drive Essentials', is_album: false, description: 'Synths for late roads', trackIds: [1, 2, 4, 5, 6, 7, 8], user: USERS[0] },
  { id: 'P2', playlist_name: 'Focus Flow', is_album: false, description: '', trackIds: [4, 10, 13, 16], user: USERS[3] },
  { id: 'A1', playlist_name: 'Salt & Static (LP)', is_album: true, description: 'Debut album', trackIds: [3, 9, 15, 21], user: USERS[2] },
  { id: 'A2', playlist_name: 'Harbor Lights', is_album: true, description: 'Second album', trackIds: [1, 7, 13, 19, 24], user: USERS[0] },
  { id: 'A3', playlist_name: 'Empty Album', is_album: true, description: 'No tracks', trackIds: [], user: USERS[1] }
].map((l, i) => ({ ...l, track_count: l.trackIds.length, artwork: art(l.trackIds[0] || 90 + i), permalink: `/${l.user.handle}/${l.is_album ? 'album' : 'playlist'}/${l.id.toLowerCase()}` }));

/* ---------- shapes ---------- */
function shapeTrack(t, base) {
  const a = t.artwork && Object.fromEntries(Object.entries(t.artwork).map(([k, v]) => [k, base + '/' + v]));
  return {
    id: t.id, title: t.title, genre: t.genre, mood: t.mood, duration: t.duration, play_count: t.play_count,
    favorite_count: t.favorite_count, repost_count: t.repost_count, release_date: t.release_date, created_at: t.created_at,
    permalink: t.permalink, is_streamable: t.is_streamable, access: t.access, artwork: a || null,
    user: shapeUser(t.user, base), is_downloadable: !!t.access.download,
    album_backlink: LISTS.find(l => l.is_album && l.trackIds.includes(Number(t.id.slice(1)))) ? { playlist_name: LISTS.find(l => l.is_album && l.trackIds.includes(Number(t.id.slice(1)))).playlist_name } : undefined
  };
}
function shapeUser(u, base) {
  const p = u.profile_picture && Object.fromEntries(Object.entries(u.profile_picture).map(([k, v]) => [k, base + '/' + v]));
  return { id: u.id, name: u.name, handle: u.handle, follower_count: u.follower_count, track_count: u.track_count, is_verified: u.is_verified, profile_picture: p || null };
}
function shapeList(l, base) {
  const a = l.artwork && Object.fromEntries(Object.entries(l.artwork).map(([k, v]) => [k, base + '/' + v]));
  return { id: l.id, playlist_name: l.playlist_name, is_album: l.is_album, description: l.description, track_count: l.track_count, artwork: a, permalink: l.permalink, user: shapeUser(l.user, base) };
}

/* ---------- artwork: tiny deterministic SVG ---------- */
function artSvg(n, size) {
  const h1 = (n * 47) % 360, h2 = (h1 + 70) % 360;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h1},75%,55%)"/><stop offset="1" stop-color="hsl(${h2},70%,35%)"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><circle cx="${30 + (n * 7) % 40}" cy="${35 + (n * 11) % 30}" r="${14 + n % 10}" fill="rgba(255,255,255,.22)"/></svg>`;
}

/* ---------- server ---------- */
function cors(res, ct) {
  if (STATE.cors) { res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges'); }
  res.setHeader('Cache-Control', 'no-store');
  if (ct) res.setHeader('Content-Type', ct);
}
const json = (res, code, body) => { cors(res, 'application/json'); res.statusCode = code; res.end(JSON.stringify(body)); };

function serveFile(req, res, file) {
  fs.stat(file, (err, st) => {
    if (err) { cors(res); res.statusCode = 404; return res.end('not found'); }
    const range = req.headers.range;
    cors(res, 'audio/mpeg'); res.setHeader('Accept-Ranges', 'bytes');
    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range) || [];
      let s = m[1] ? parseInt(m[1], 10) : 0, e = m[2] ? parseInt(m[2], 10) : st.size - 1;
      if (isNaN(s) || s >= st.size) { res.statusCode = 416; res.setHeader('Content-Range', `bytes */${st.size}`); return res.end(); }
      e = Math.min(e, st.size - 1);
      res.statusCode = 206; res.setHeader('Content-Range', `bytes ${s}-${e}/${st.size}`); res.setHeader('Content-Length', e - s + 1);
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file, { start: s, end: e }).pipe(res);
    } else {
      res.statusCode = 200; res.setHeader('Content-Length', st.size);
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).pipe(res);
    }
  });
}

function handler(req, res) {
  const u = new URL(req.url, 'http://x');
  const base = `http://${req.headers.host}`;
  const p = u.pathname, q = u.searchParams;
  if (p === '/__ctl') {
    if (q.get('reset')) reset();
    if (q.has('cors')) STATE.cors = q.get('cors') !== '0';
    if (q.has('delay')) STATE.delay = Number(q.get('delay')) || 0;
    if (q.has('fail')) STATE.fail = q.get('fail') ? q.get('fail').split(',').map(x => { const [s, c] = x.split(':'); return { s, c: Number(c) || 500 }; }) : [];
    return json(res, 200, { ok: true, STATE: { cors: STATE.cors, delay: STATE.delay, fail: STATE.fail } });
  }
  if (p === '/__log') {
    if (q.get('clear')) STATE.log = [];
    return json(res, 200, STATE.log);
  }
  if (req.method === 'OPTIONS') { cors(res); res.setHeader('Access-Control-Allow-Headers', '*'); res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS'); res.statusCode = 204; return res.end(); }
  STATE.log.push({ t: Date.now(), method: req.method, url: req.url, range: req.headers.range || null });
  const go = () => {
    const f = STATE.fail.find(x => req.url.includes(x.s));
    if (f) { cors(res, 'application/json'); res.statusCode = f.c; return res.end(JSON.stringify({ error: 'mock failure' })); }
    route();
  };
  const route = () => {
    let m;
    if ((m = /^\/ART\/(\d+)$/.exec(p))) { cors(res, 'image/svg+xml'); return res.end(artSvg(Number(m[1]), Number(q.get('s')) || 150)); }
    if ((m = /^\/media\/([\w.-]+)$/.exec(p))) return serveFile(req, res, path.join(STREAM_DIR, m[1]));

    const lim = Math.min(Number(q.get('limit')) || 25, 100), off = Number(q.get('offset')) || 0;
    const page = arr => arr.slice(off, off + lim);

    if (p === '/v1/tracks/trending') {
      let l = TRACKS.slice().sort((a, b) => b.play_count - a.play_count);
      if (q.get('genre')) l = l.filter(t => t.genre === q.get('genre'));
      return json(res, 200, { data: page(l).map(t => shapeTrack(t, base)) });
    }
    if (p === '/v1/tracks/search') {
      const k = (q.get('query') || '').toLowerCase();
      let l = TRACKS.filter(t => t.title.toLowerCase().includes(k) || t.user.name.toLowerCase().includes(k) || t.genre.toLowerCase().includes(k));
      return json(res, 200, { data: page(l).map(t => shapeTrack(t, base)) });
    }
    if ((m = /^\/v1\/tracks\/(T\d+)\/stream$/.exec(p))) {
      const t = TRACKS.find(x => x.id === m[1]);
      if (!t) { cors(res); res.statusCode = 404; return res.end(); }
      if (!t.is_streamable) { cors(res); res.statusCode = 403; return res.end(); }
      cors(res); res.statusCode = 302; res.setHeader('Location', `${base}/media/${t.file}`); return res.end();   // real Audius also answers 302 -> mp3
    }
    if (p === '/v1/users/search') {
      const k = (q.get('query') || '').toLowerCase();
      return json(res, 200, { data: page(USERS.filter(x => x.name.toLowerCase().includes(k) || x.handle.includes(k))).map(x => shapeUser(x, base)) });
    }
    if ((m = /^\/v1\/users\/(u\d+)\/tracks$/.exec(p))) return json(res, 200, { data: page(TRACKS.filter(t => t.user.id === m[1])).map(t => shapeTrack(t, base)) });
    if ((m = /^\/v1\/users\/(u\d+)$/.exec(p))) { const x = USERS.find(y => y.id === m[1]); return x ? json(res, 200, { data: shapeUser(x, base) }) : json(res, 404, { error: 'nope' }); }
    if (p === '/v1/playlists/search') {
      const k = (q.get('query') || '').toLowerCase();
      let l = LISTS.filter(x => x.playlist_name.toLowerCase().includes(k) || (k === 'album' && x.is_album) || (k === 'playlist' && !x.is_album));
      return json(res, 200, { data: page(l).map(x => shapeList(x, base)) });
    }
    if (p === '/v1/playlists/trending') {
      const type = q.get('type'); let l = LISTS.slice();
      if (type) l = l.filter(x => (type === 'album') === x.is_album);
      return json(res, 200, { data: page(l).map(x => shapeList(x, base)) });
    }
    if ((m = /^\/v1\/playlists\/([AP]\d+)\/tracks$/.exec(p))) {
      const l = LISTS.find(x => x.id === m[1]); if (!l) return json(res, 404, { error: 'nope' });
      return json(res, 200, { data: l.trackIds.map(i => shapeTrack(TRACKS[i - 1], base)) });
    }
    return json(res, 404, { error: 'unknown mock route ' + p });
  };
  if (STATE.delay && !/^\/media\//.test(p)) setTimeout(go, STATE.delay); else go();
}

function start(port = 4010) {
  return new Promise(resolve => { const s = http.createServer(handler).listen(port, '127.0.0.1', () => resolve(s)); });
}
module.exports = { start, TRACKS, LISTS, USERS };
if (require.main === module) start(Number(process.argv[2]) || 4010).then(() => console.log('mock audius on http://127.0.0.1:' + (process.argv[2] || 4010)));
