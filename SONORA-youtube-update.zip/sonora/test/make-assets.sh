#!/usr/bin/env bash
# Generates REAL audio files for tests with ffmpeg (synthesized tones — no copyrighted material).
#  assets/stream/*.mp3   served by the mock Audius server
#  assets/local/*        files for the local-music import tests, with real ID3 / Vorbis / MP4 tags + cover art
set -euo pipefail
cd "$(dirname "$0")"
A=assets; rm -rf $A; mkdir -p $A/stream $A/local $A/cover
FF="ffmpeg -hide_banner -loglevel error -y"

# --- cover art (PNG) ---
$FF -f lavfi -i "gradients=s=300x300:c0=0xff6a3d:c1=0x7c5cff:d=1:speed=0.0001" -frames:v 1 $A/cover/cover1.png 2>/dev/null \
 || $FF -f lavfi -i "color=c=0xff6a3d:s=300x300" -frames:v 1 $A/cover/cover1.png
$FF -f lavfi -i "color=c=0x2fd1b4:s=300x300" -frames:v 1 $A/cover/cover2.png

# --- streamable mp3s: chord-ish tones with slow tremolo so they are audibly different ---
tone() { # name  seconds  f1 f2 f3
  $FF -f lavfi -i "sine=f=$3:d=$2" -f lavfi -i "sine=f=$4:d=$2" -f lavfi -i "sine=f=$5:d=$2" \
      -filter_complex "[0][1][2]amix=inputs=3,volume=2.2,tremolo=f=3:d=0.4" -c:a libmp3lame -b:a 64k -ar 44100 -ac 2 $A/stream/$1.mp3
}
tone s1 40 220 277 330
tone s2 40 247 311 370
tone s3 40 196 247 294
tone s4 14 262 330 392    # short one: lets tests reach "ended" quickly
tone s5 40 175 220 262
tone s6 40 294 370 440

# --- local files with tags ---
# 1) MP3 + ID3v2.3: title/artist/album/year/genre/track, cover, lyrics (USLT)
$FF -f lavfi -i "sine=f=440:d=12" -i $A/cover/cover1.png -map 0:a -map 1:v -c:a libmp3lame -b:a 96k -c:v copy -id3v2_version 3 \
  -metadata:s:v title="Album cover" -metadata:s:v comment="Cover (front)" \
  -metadata title="Ember Test Tone" -metadata artist="Test Artist" -metadata album="Sine Waves Vol. 1" \
  -metadata date="2024" -metadata genre="Electronic" -metadata track="3" -metadata lyrics="La la la (embedded lyrics line one)" \
  $A/local/tagged.mp3
# 2) WAV (RIFF INFO tags only; browsers play it, tag parser should fall back to the filename)
$FF -f lavfi -i "sine=f=523:d=6" -c:a pcm_s16le -ar 44100 "$A/local/Plain Wave File.wav"
# 3) FLAC + Vorbis comments + picture
$FF -f lavfi -i "sine=f=330:d=10" -i $A/cover/cover2.png -map 0:a -map 1:v -c:a flac -c:v copy -disposition:v attached_pic \
  -metadata title="Lossless Lagoon" -metadata artist="Flac Artist" -metadata album="Hi-Res Tests" -metadata date="2023" -metadata genre="Ambient" -metadata tracknumber="1" \
  $A/local/lossless.flac
# 4) M4A (AAC) + iTunes atoms + cover
$FF -f lavfi -i "sine=f=392:d=9" -i $A/cover/cover1.png -map 0:a -map 1:v -c:a aac -b:a 96k -c:v copy -disposition:v attached_pic \
  -metadata title="Aac Sunrise" -metadata artist="M4A Artist" -metadata album="Mobile Tests" -metadata date="2022" -metadata genre="Pop" -metadata track="7" \
  $A/local/aac-sunrise.m4a
# 5) MP3 with NO tags and no cover (name must be used as title)
$FF -f lavfi -i "sine=f=294:d=5" -map_metadata -1 -c:a libmp3lame -b:a 64k "$A/local/untagged_song-name.mp3"
# 6) OGG/Opus (browser support varies by platform — test only checks it imports without crashing)
$FF -f lavfi -i "sine=f=349:d=5" -c:a libopus -b:a 48k $A/local/opus-clip.ogg
# 7) not audio at all (must be rejected politely)
echo "this is not audio" > $A/local/notes.txt
# 8) a corrupt "mp3" (valid extension, garbage bytes)
head -c 2048 /dev/urandom > $A/local/corrupt.mp3

# 9) MP3 with a REAL ID3v2.3 USLT frame (UTF-16 + BOM, unicode text) crafted byte-by-byte, plus a TXXX-lyrics variant
$FF -f lavfi -i "sine=f=311:d=6" -map_metadata -1 -write_id3v2 0 -c:a libmp3lame -b:a 64k $A/cover/_raw.mp3
python3 - "$A" <<'PY'
import sys, struct
A = sys.argv[1]
audio = open(A + '/cover/_raw.mp3', 'rb').read()
def frame(fid, body): return fid + struct.pack('>I', len(body)) + b'\x00\x00' + body
def u16(s): return b'\xff\xfe' + s.encode('utf-16le')
def tag(frames):
    body = b''.join(frames)
    n = len(body)
    ss = bytes([(n >> 21) & 0x7f, (n >> 14) & 0x7f, (n >> 7) & 0x7f, n & 0x7f])
    return b'ID3\x03\x00\x00' + ss + body
lyr = 'H\u00e9llo w\u00f6rld \u266a\nLine two of the USLT lyrics'
uslt = frame(b'USLT', b'\x01' + b'eng' + u16('') + b'\x00\x00' + u16(lyr))
t = tag([frame(b'TIT2', b'\x01' + u16('Uslt Song \u00e9\u266a') + b'\x00\x00'), frame(b'TPE1', b'\x01' + u16('Lyric Artist') + b'\x00\x00'), uslt])
open(A + '/local/uslt-utf16.mp3', 'wb').write(t + audio)
PY
rm -f $A/cover/_raw.mp3

# --- lyrics sidecar ---
cat > $A/local/tagged.lrc <<'EOF'
[ti:Ember Test Tone]
[00:00.50]First synced line
[00:03.00]Second synced line
[00:06.00]Third synced line
[00:09.00]Fourth synced line
EOF

ls -la $A/stream $A/local | sed 's/^/  /'
echo "assets ok"
