/* E2E group 1: boot, navigation, home, search, playback engine, queue. Runs against the LOCAL MOCK of Audius. */
const { boot, mlog, ctl, APP, MOCK } = require('./harness');
const T = require('./lib');
const { test, expect, eq, ev, audio, until, W } = T;
const fs = require('fs');

(async () => {
  const h = await boot();
  T.init(h, process.argv[2]);
  console.log('E2E core — against local mock Audius at', MOCK);

  /* ---------------- boot & structure ---------------- */
  await test('boot: no JS errors, 4 tabs, home shelves load from API', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    const shelves = await ev(page, () => [...document.querySelectorAll('#tab-home .sec')].map(s => s.id));
    for (const id of ['sh-trending', 'sh-rec', 'sh-new', 'sh-albums', 'sh-lists', 'sh-artists']) expect(shelves.includes(id), 'home has ' + id + ' → ' + shelves);
    eq(await ev(page, () => document.querySelectorAll('#nav .nav-btn').length), 4, 'nav buttons');
  });

  await test('no dead buttons: every data-act in the app has a handler', async (page) => {
    const html = fs.readFileSync(__dirname + '/../dist/index.html', 'utf8');
    const acts = [...new Set([...html.matchAll(/data-act="([A-Za-z]+)"/g)].map(m => m[1]))];
    const missing = await ev(page, a => a.filter(x => typeof SONORA.ACT[x] !== 'function'), acts);
    eq(missing, [], 'unhandled data-act values (' + acts.length + ' checked)');
  });

  await test('hostile track title is escaped (no HTML/script injection)', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    const r = await ev(page, () => ({ injected: !!document.querySelector('#sh-trending img[src="x"]'), text: [...document.querySelectorAll('#sh-trending .card-title')].some(e => e.textContent.includes('<b>Tom')) }));
    expect(!r.injected, 'no injected <img>'); expect(r.text, 'title shown as literal text');
  });

  await test('icon-only buttons all have accessible names', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    const bad = await ev(page, () => [...document.querySelectorAll('button')].filter(b => !b.textContent.trim() && !b.getAttribute('aria-label') && !b.getAttribute('title')).map(b => b.outerHTML.slice(0, 90)));
    eq(bad, [], 'unlabelled buttons');
  });

  await test('tab navigation + unified back handling', async (page) => {
    for (const t of ['explore', 'search', 'library', 'home']) {
      await page.click(`.nav-btn[data-tab="${t}"]`); await W(150);
      expect(await ev(page, t => !document.querySelector('#tab-' + t).hidden && document.querySelector(`.nav-btn[data-tab="${t}"]`).classList.contains('on'), t), 'tab ' + t + ' visible and active');
    }
    // open settings (pushed view) then browser back
    await page.click('[data-act="openSettings"]'); await W(250);
    eq(await ev(page, () => SONORA.UI_STACK.length), 1, 'pushed view on stack');
    await page.goBack(); await W(300);
    eq(await ev(page, () => SONORA.UI_STACK.length), 0, 'stack empty after back');
    expect(page.url().includes('index.html'), 'still in the app after back');
  });

  /* ---------------- search ---------------- */
  await test('live search: songs/artists/albums, tabs, history, clear', async (page) => {
    await page.click('.nav-btn[data-tab="search"]');
    await page.fill('#search-input', 'neon');
    await until(page, () => document.querySelectorAll('#search-body .row-title').length >= 3, null, 6000);
    const songs = await ev(page, () => [...document.querySelectorAll('#search-body .row-title')].map(e => e.textContent));
    expect(songs.includes('Midnight Circuit'), 'finds track by artist name: ' + songs);
    expect(await ev(page, () => /Neon Harbor/.test(document.querySelector('#search-body').innerText)), 'artist result visible');
    // tabs
    await page.click('[data-act="searchTab"][data-tab="artists"]'); await W(200);
    expect(await ev(page, () => document.querySelectorAll('#search-body .row').length === 0 && /Neon Harbor/.test(document.querySelector('#search-body').innerText)), 'artists tab only');
    await page.click('[data-act="searchTab"][data-tab="albums"]'); await W(200);
    await page.fill('#search-input', 'harbor'); await until(page, () => /Harbor Lights/.test(document.querySelector('#search-body').innerText), null, 6000);
    // history is committed on Enter (not on every keystroke), then shown when the box is empty
    expect(await ev(page, () => SONORA.LIB.searches.length === 0), 'typing alone does not pollute history');
    await page.press('#search-input', 'Enter'); await W(200);
    await page.click('[data-act="searchClear"]'); await W(300);
    const hist = await ev(page, () => SONORA.LIB.searches.map(s => s.q || s));
    expect(hist.length >= 1, 'history saved: ' + JSON.stringify(hist));
    expect(await ev(page, () => /Recent searches|Recent/i.test(document.querySelector('#search-body').innerText)), 'history shown when input empty');
    await page.click('[data-act="searchClearHistory"]'); await W(200);
    eq(await ev(page, () => SONORA.LIB.searches.length), 0, 'history cleared');
  });

  await test('search: no results + API failure are handled with real messages', async (page) => {
    await page.click('.nav-btn[data-tab="search"]');
    await page.fill('#search-input', 'zzzzqqq'); await until(page, () => /No results/.test(document.querySelector('#search-body').innerText), null, 6000);
    await ctl('fail=/search:500');
    await page.fill('#search-input', 'neon'); await until(page, () => /problem|error|couldn|Try again/i.test(document.querySelector('#search-body').innerText), null, 6000);
    await ctl('fail=');
    await page.click('[data-act="searchRetry"]').catch(() => { });
    await until(page, () => document.querySelectorAll('#search-body .row').length >= 1, null, 6000);
  }, { allowErrors: true });

  /* ---------------- real playback ---------------- */
  await test('REAL playback: tap → audio advances, Range stream via 302, mini-player, Media Session', async (page) => {
    await mlog(true);
    await page.click('#sh-trending .card >> nth=0');
    await until(page, () => SONORA.E.d.el.currentTime > 1.2 && !SONORA.E.d.el.paused, null, 9000);
    const a = await audio(page);
    expect(a.src.includes('/v1/tracks/T1/stream'), 'element src is the documented stream endpoint: ' + a.src);
    expect(a.rs >= 3 && Math.abs(a.dur - 40) < 1.5, 'decoded real mp3 duration ' + a.dur);
    const log = await mlog();
    expect(log.some(l => l.url.startsWith('/v1/tracks/T1/stream')), 'stream endpoint requested');
    expect(log.some(l => l.url.startsWith('/media/s1.mp3')), '302 target (the mp3) was fetched by the browser');
    expect(log.some(l => l.url.startsWith('/media/s1.mp3') && l.range), 'browser used HTTP Range requests: ' + JSON.stringify(log.filter(l => l.url.startsWith('/media')).slice(0, 3)));
    expect(!(await ev(page, () => document.querySelector('#mini').hidden)), 'mini-player shown');
    const ms = await ev(page, () => ({ title: navigator.mediaSession.metadata && navigator.mediaSession.metadata.title, artist: navigator.mediaSession.metadata && navigator.mediaSession.metadata.artist, art: navigator.mediaSession.metadata && navigator.mediaSession.metadata.artwork.length, st: navigator.mediaSession.playbackState }));
    eq(ms.title, 'Midnight Circuit', 'media session title'); eq(ms.artist, 'Neon Harbor', 'media session artist'); eq(ms.st, 'playing', 'media session state');
    expect(ms.art >= 1, 'media session artwork');
  });

  await test('transport: pause/resume, seek, next/prev, volume, mute', async (page) => {
    await page.click('#sh-trending .card >> nth=0');
    await until(page, () => SONORA.E.d.el.currentTime > 0.8, null, 9000);
    await page.click('.mini-play'); await W(300);
    expect((await audio(page)).paused, 'paused via mini button');
    const t0 = (await audio(page)).t; await W(600); expect(Math.abs((await audio(page)).t - t0) < 0.15, 'stays paused');
    await page.click('.mini-play'); await until(page, t => SONORA.E.d.el.currentTime > t + 0.5, t0, 5000);
    // seek via the Now Playing slider (real input event)
    await page.click('.mini-main'); await W(600);
    await ev(page, () => { const s = document.querySelector('#np-seek'); s.value = 500; s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true })); });
    await until(page, () => Math.abs(SONORA.E.d.el.currentTime - 20) < 3, null, 5000);
    // next
    const id0 = await ev(page, () => SONORA.Q.list[SONORA.Q.idx].id);
    await page.click('#np [data-act="next"]'); await W(200);
    const id1 = await ev(page, () => SONORA.Q.list[SONORA.Q.idx].id); expect(id1 !== id0, 'next changed track');
    await until(page, () => SONORA.E.d.el.currentTime > 0.5 && !SONORA.E.d.el.paused, null, 8000);
    expect(/Salt|Tom|Paper|Low Tide|Chrome|Velvet|Run It|Glass|Hollow/.test(await ev(page, () => document.querySelector('#np-title').textContent)), 'NP title updated: ' + id1);
    // prev after >3s restarts; prev within 3s goes back
    await page.click('#np [data-act="prev"]'); await W(250);
    const id2 = await ev(page, () => SONORA.Q.list[SONORA.Q.idx].id); eq(id2, id0, 'prev returned to the first track');
    // volume + mute
    await ev(page, () => { const v = document.querySelector('#np-vol'); v.value = 30; v.dispatchEvent(new Event('input', { bubbles: true })); });
    await W(100); expect(Math.abs((await audio(page)).vol - 0.3) < 0.02, 'volume applied to element');
    await page.click('#np-mute'); await W(100); expect((await audio(page)).vol === 0, 'mute silences element');
    await page.click('#np-mute'); await W(100); expect(Math.abs((await audio(page)).vol - 0.3) < 0.02, 'unmute restores');
  });

  await test('end of track: auto-advance; repeat-one loops; repeat-off stops at end of queue', async (page) => {
    // T4 is the 14-second track (index 3 on the trending list order differs, so use a custom queue)
    await ev(page, async () => {
      const ts = await SONORA.Audius.trending({ limit: 30 }); const short = ts.find(t => t.id === 'au:T4'); const long = ts.find(t => t.id === 'au:T1');
      window.__short = short; SONORA.PL.play([short, long], 0, { type: 'test', name: 'Test' });
    });
    await until(page, () => SONORA.E.d.el.currentTime > 0.5, null, 8000);
    await ev(page, () => { SONORA.E.d.el.currentTime = SONORA.E.d.el.duration - 1.2; });
    await until(page, () => SONORA.Q.idx === 1, null, 8000);
    await until(page, () => SONORA.E.d.el.currentTime > 0.4 && !SONORA.E.d.el.paused, null, 8000);
    // repeat one on a short track
    await ev(page, () => { SONORA.PL.play([window.__short], 0, { type: 'test', name: 'Test' }); SONORA.PREFS.repeat = 'one'; });
    await until(page, () => SONORA.E.d.el.currentTime > 0.5, null, 8000);
    await ev(page, () => { SONORA.E.d.el.currentTime = SONORA.E.d.el.duration - 1.0; });
    await until(page, () => SONORA.E.d.el.currentTime < 5 && !SONORA.E.d.el.paused && SONORA.E.d.el.currentTime > 0.2, null, 9000);
    eq(await ev(page, () => SONORA.Q.idx), 0, 'repeat-one stays on the same track');
    // repeat off: stops after the last track
    await ev(page, () => { SONORA.PREFS.repeat = 'off'; SONORA.E.d.el.currentTime = SONORA.E.d.el.duration - 1.0; });
    await until(page, () => !SONORA.PS.playing, null, 9000);
    expect(await ev(page, () => SONORA.PS.playing === false), 'stopped at end of queue');
  });

  await test('shuffle: reorders upcoming, restores original order when turned off', async (page) => {
    await page.click('#sh-trending .card >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.3, null, 8000);
    const before = await ev(page, () => SONORA.Q.list.map(t => t.id).join());
    await ev(page, () => SONORA.PL.toggleShuffle()); await W(200);
    const mid = await ev(page, () => ({ list: SONORA.Q.list.map(t => t.id).join(), cur: SONORA.Q.list[SONORA.Q.idx].id, pref: SONORA.PREFS.shuffle }));
    expect(mid.pref, 'shuffle pref on'); expect(mid.list !== before, 'order changed'); eq(mid.cur, 'au:T1', 'current track unchanged by shuffle');
    await ev(page, () => SONORA.PL.toggleShuffle()); await W(200);
    eq(await ev(page, () => SONORA.Q.list.map(t => t.id).join()), before, 'original order restored');
  });

  await test('queue sheet: jump, remove, play next, add to queue', async (page) => {
    await page.click('#sh-trending .card >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.3, null, 8000);
    // "play next" from a card's menu
    await page.click('#sh-trending .card >> nth=4 >> [data-act="trackMenu"]'); await W(400);
    await page.click('[data-act="menuNext"]'); await W(300);
    const nextId = await ev(page, () => SONORA.Q.list[SONORA.Q.idx + 1].id);
    await page.keyboard.press('q'); await W(500);
    expect(await ev(page, () => document.querySelectorAll('.sheet .row, .sheet .queue-row').length >= 3), 'queue sheet lists tracks');
    const n0 = await ev(page, () => SONORA.Q.list.length);
    await page.click('.sheet [data-act="queueRemove"] >> nth=0'); await W(250);
    eq(await ev(page, () => SONORA.Q.list.length), n0 - 1, 'removed one from queue');
    await page.click('.sheet .q-row:not(.is-current):not(.is-past)'); await W(300);
    expect(await ev(page, () => SONORA.Q.idx >= 1), 'jumped forward');
    await until(page, () => SONORA.E.d.el.currentTime > 0.3 && !SONORA.E.d.el.paused, null, 8000);
    void nextId;
  });

  /* ---------------- failure paths ---------------- */
  await test('non-streamable track: clear message, nothing broken', async (page) => {
    await page.click('#sh-trending .card >> nth=2'); await W(500);
    expect(await ev(page, () => /isn.t available/.test(document.querySelector('#toasts').innerText)), 'toast shown');
    eq(await ev(page, () => SONORA.Q.list.length), 0, 'no queue was created');
  });

  await test('stream 404 (dead file): error shown, auto-skips to next, no loop', async (page) => {
    // T9's /media file does not exist → the 302 target 404s
    await ev(page, async () => { const ts = await SONORA.Audius.trending({ limit: 30 }); const bad = ts.find(t => t.id === 'au:T9'), ok = ts.find(t => t.id === 'au:T1'); SONORA.PL.play([bad, ok], 0, { type: 'test', name: 'Test' }); });
    await until(page, () => SONORA.Q.idx === 1 && SONORA.E.d.el.currentTime > 0.4, null, 12000);
    expect(await ev(page, () => SONORA.UNAVAIL.has('au:T9')), 'dead track remembered as unavailable');
    expect(await ev(page, () => /couldn|unavailable|skipp/i.test(document.querySelector('#toasts').innerText)), 'user told: ' + await ev(page, () => document.querySelector('#toasts').innerText));
  }, { allowErrors: true });

  await test('trending API failure → falls back to the saved snapshot and says so', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    await ctl('fail=/tracks/trending:500');
    await page.click('[data-act="homeRefresh"]');
    await until(page, () => /Saved from/.test(document.querySelector('#sh-trending .sec-sub').textContent), null, 8000);
    expect(await ev(page, () => document.querySelectorAll('#sh-trending .card').length >= 5), 'cached cards still shown');
  }, { allowErrors: true });

  await test('shelf API failure (no cache) → error state with working Retry', async (page) => {
    await until(page, () => document.querySelectorAll('#sh-albums .card').length >= 1);
    await ctl('fail=/playlists:500');
    await page.click('[data-act="homeRefresh"]');
    await until(page, () => document.querySelector('#sh-albums [data-act="retryShelf"]'), null, 8000);
    expect(await ev(page, () => /problem|error|couldn|try again/i.test(document.querySelector('#sh-albums').innerText)), 'message: ' + await ev(page, () => document.querySelector('#sh-albums').innerText));
    await ctl('fail=');
    await page.click('#sh-albums [data-act="retryShelf"]');
    await until(page, () => document.querySelectorAll('#sh-albums .card').length >= 1, null, 8000);
  }, { allowErrors: true });

  await test('network drop mid-stream → waits, then resumes when back online', async (page, ctx) => {
    await page.click('#sh-trending .card >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 1, null, 9000);
    await ctx.setOffline(true); await W(300);
    await ev(page, () => window.dispatchEvent(new Event('offline')));
    await until(page, () => !document.querySelector('#netbar').hidden, null, 4000);
    await ctx.setOffline(false); await ev(page, () => window.dispatchEvent(new Event('online')));
    await W(1200);
    const t = (await audio(page)).t;
    await until(page, t => SONORA.E.d.el.currentTime > t + 0.8 && !SONORA.E.d.el.paused, t, 12000);
    expect(await ev(page, () => document.querySelector('#netbar').hidden), 'offline bar hidden again');
  }, { allowErrors: true });

  await test('history stays balanced across close-then-open menu actions (regression: Back used to leave the app)', async (page) => {
    const settle = async (label) => { await W(900); const r = await ev(page, () => ({ d: SONORA.H.depth, n: SONORA.UI_STACK.length, q: SONORA.H.q.length, busy: SONORA.H.busy, url: location.pathname })); eq([r.d, r.q, r.busy, r.url.endsWith('index.html')], [r.n, 0, false, true], label + ' → ' + JSON.stringify(r)); };
    await until(page, () => document.querySelectorAll('#sh-trending .card').length >= 5);
    // song menu → Add to playlist (menu item closes its sheet and opens another) → New playlist (closes again, opens a dialog)
    await page.click('#sh-trending .card >> nth=0 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="menuAddPl"]'); await settle('menu → add-to-playlist sheet');
    await page.click('.sheet [data-act="addToNewPl"]'); await settle('→ new-playlist dialog');
    await page.keyboard.press('Escape'); await settle('Esc closes dialog');
    // play next / queue items close the sheet only
    await page.click('#sh-trending .card >> nth=1 >> [data-act="trackMenu"]'); await W(300);
    await page.click('[data-act="menuQueue"]'); await settle('menu → queue');
    // Now Playing → sound sheet → Esc → close NP, repeated rapidly
    await page.click('.mini-main'); await W(500);
    for (let i = 0; i < 3; i++) { await page.click('#np-sound'); await W(250); await page.keyboard.press('Escape'); await W(150); }
    await page.click('#np [data-act="closeNP"]'); await settle('rapid sheet open/close then close NP');
    // pushed view + sheet + system back x2 must land back on the tab, inside the app
    await page.click('[data-act="openSettings"]'); await W(300);
    await page.click('[data-act="openSound"]'); await W(300);
    await page.goBack(); await W(300); await page.goBack(); await settle('system Back twice from settings+sheet');
    eq(await ev(page, () => document.querySelector('#tab-home').hidden), false, 'home tab visible again');
  });

  /* ---------------- keyboard ---------------- */
  await test('keyboard shortcuts', async (page) => {
    await page.click('#sh-trending .card >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.5, null, 8000);
    await page.keyboard.press('Space'); await W(250); expect((await audio(page)).paused, 'space pauses');
    await page.keyboard.press('Space'); await W(400); expect(!(await audio(page)).paused, 'space resumes');
    const t = (await audio(page)).t; await page.keyboard.press('ArrowRight'); await W(150); expect((await audio(page)).t >= t + 4, 'right seeks +5s');
    await page.keyboard.press('ArrowLeft'); await W(150);
    const v = await ev(page, () => SONORA.PREFS.volume); await page.keyboard.press('ArrowDown'); eq(await ev(page, () => Math.round(SONORA.PREFS.volume * 100)), Math.round((v - 0.05) * 100), 'down lowers volume');
    await page.keyboard.press('m'); expect(await ev(page, () => SONORA.PREFS.muted), 'm mutes'); await page.keyboard.press('m');
    await page.keyboard.press('l'); expect(await ev(page, () => SONORA.LIB.liked.length === 1), 'l likes');
    await page.keyboard.press('s'); expect(await ev(page, () => SONORA.PREFS.shuffle), 's toggles shuffle');
    await page.keyboard.press('r'); eq(await ev(page, () => SONORA.PREFS.repeat), 'all', 'r cycles repeat');
    await page.keyboard.press('n'); await W(500); expect(await ev(page, () => document.querySelector('#np').classList.contains('in')), 'n opens now playing');
    await page.keyboard.press('Escape'); await W(500); expect(!(await ev(page, () => document.querySelector('#np').classList.contains('in'))), 'esc closes it');
    await page.keyboard.press('/'); await W(400); expect(await ev(page, () => document.activeElement && document.activeElement.id === 'search-input'), '/ focuses search');
    await page.keyboard.press('Escape');
    await page.click('body', { position: { x: 5, y: 300 } }).catch(() => { });
    await page.keyboard.press('?'); await W(400); expect(await ev(page, () => /Keyboard shortcuts/.test(document.querySelector('.sheet').innerText)), '? shows help');
  });

  await test('Now Playing + sheets close with the browser/Android back button', async (page) => {
    await page.click('#sh-trending .card >> nth=0'); await until(page, () => SONORA.E.d.el.currentTime > 0.3, null, 8000);
    await page.click('.mini-main'); await W(500);
    await page.click('#np-sound'); await W(500);
    eq(await ev(page, () => SONORA.UI_STACK.length), 2, 'np + sheet on stack');
    await page.goBack(); await W(400); eq(await ev(page, () => SONORA.UI_STACK.length), 1, 'back closed the sheet first');
    await page.goBack(); await W(400); eq(await ev(page, () => SONORA.UI_STACK.length), 0, 'back closed now playing');
    expect(!(await audio(page)).paused, 'music kept playing');
    expect(page.url().includes('index.html'), 'did not leave the app');
  });

  const ok = T.report(__dirname + '/results-core.json');
  await h.close(); process.exit(ok ? 0 : 1);
})().catch(e => { console.error('HARNESS ERROR', e); process.exit(2); });
