const { boot, newPage, APP } = require('./harness');
(async () => {
  const h = await boot();
  const errors = [];
  const { page } = await newPage(h.browser, { errors });
  await page.goto(APP + '/index.html');
  await page.waitForTimeout(2500);
  const info = await page.evaluate(() => ({ title: document.title, home: document.querySelector('#tab-home')?.innerText.slice(0, 400), shelves: document.querySelectorAll('#tab-home .shelf').length, sonora: typeof window.SONORA }));
  console.log(JSON.stringify(info, null, 1));
  await page.screenshot({ path: 'shots/home-dark.png' });
  console.log('ERRORS', errors);
  await h.close();
})().catch(e => { console.error(e); process.exit(1); });
