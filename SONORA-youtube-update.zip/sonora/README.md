# SONORA

A free, mobile-first music player for the open web. It streams from **Audius** (no account, no API key), can add **Jamendo** and **Internet Archive** as optional sources, and plays your **own audio files** from the device. Plain HTML, CSS and JavaScript. No framework, no build dependencies, no paid services, no tracking.

Built to run in a browser today and to wrap into an Android app later (see [docs/ANDROID.md](docs/ANDROID.md)).

## Read this first: what is and isn't verified

| Area | Status |
|---|---|
| App logic, UI, playback engine, playlists, library, local files, offline, settings | **Tested** end to end in real Chromium 157 and Google Chrome 153 (55 end-to-end tests plus 6 offline/PWA checks, each run on both browsers; see [docs/TEST-REPORT.md](docs/TEST-REPORT.md)). |
| Audius streaming and search | **Not tested against the live Audius service.** The build environment could not reach it. The client follows Audius's documented REST API and was tested against a **local mock** of that API serving real MP3 files. The first time you run it on a normal connection is the first live test. |
| Jamendo, Internet Archive | **Not tested live.** Parsing and playback were tested against stubbed responses in the documented shape only. Both are off by default. |
| Lyrics | **No lyrics provider is included** (none is both free and properly licensed). Lyrics work from tags embedded in your own files and from `.lrc` files you attach. |
| Background playback / lock-screen controls | Media Session API is wired up, but **browsers do not guarantee background playback**, and it was not testable here. A reliable version needs the native Android path in the docs. |
| Android APK | **Not built.** No Android SDK here. The guide is written from current Android/Capacitor documentation; the native plugin code is a reference skeleton, not compiled. |
| Safari, Firefox, iOS | **Not tested** (only Chromium-family browsers were available). |
| Accounts / cloud sync | **Not implemented.** The data model is sync-ready and the design is documented. |

## Run it

The finished app is one file: `dist/index.html` (plus the PWA files next to it).

Streaming needs network access to `api.audius.co` and the audio hosts, which a normal browser tab has.

```bash
# any static server will do
cd dist && python3 -m http.server 8080      # then open http://localhost:8080
# or:  npx serve dist
```

Opening `index.html` straight from disk also works for local files and the UI, but the service worker (offline shell, installable app) needs `http://localhost` or `https://`.

### Host it free
GitHub Pages, Netlify (drag the `dist` folder onto Netlify Drop), Cloudflare Pages and similar static hosts all work. There is no server component. Check each host's current terms and limits yourself.

### Why it doesn't stream inside the Claude artifact preview
Claude's artifact viewer runs pages inside a locked-down frame that blocks network requests, remote audio and remote images. The artifact build (`dist/artifact.html`) still loads and shows the interface, local music import and playback still work, and the app says clearly that online music is blocked. For real streaming use `dist/index.html` on any normal host.

## Features

- **Home**: greeting, continue listening, recently played, trending, recommended (from what you play and like), new releases, popular albums, featured playlists, popular artists, made-for-you mixes.
- **Explore**: genres, languages and regions, categories (charts, moods, study/sleep/focus). Audius has no language or region catalogue, so the language/region tiles are keyword searches and the results are uneven. The app says so on screen.
- **Search**: live results for songs, artists, albums and playlists, suggestions, search history, trending searches, recently opened.
- **Player**: mini-player and full Now Playing screen, queue (reorder, remove, play next), shuffle, repeat, seek, speed, sleep timer (with fade-out), equalizer, crossfade, volume, adaptive background colour from the artwork, Media Session metadata and controls.
- **Playlists**: create, rename, description, cover upload, add, remove, drag to reorder, play, shuffle, delete, like songs.
- **Library**: liked songs, playlists, saved albums, followed artists, downloads, on-device music, history; sort and filter.
- **Local files**: mp3, wav, flac, m4a/aac, ogg/opus and anything your browser can decode, through the file picker, a folder picker or drag and drop. Tags and cover art are read from ID3, FLAC and MP4 metadata. Files stay on the device (IndexedDB).
- **Offline downloads**: only for tracks whose artist allows downloads (Audius `access.download`), stored in your browser.
- **Extras**: listening stats, data saver, dark/light/system theme with four accents, connectivity banner, keyboard shortcuts, JSON backup/restore, wipe-everything.
- **PWA**: installable, app shell cached for offline use.

### Keyboard shortcuts
`Space` play/pause · `←` `→` seek 5 s · `Shift+←` `Shift+→` previous/next · `↑` `↓` volume · `M` mute · `L` like · `S` shuffle · `R` repeat · `N` Now Playing · `Q` queue · `/` search · `?` help · `Esc` close

## Music sources and attribution

- **Audius** (primary). Free, no key for reading. SONORA sends `app_name=SONORA` with requests. Audius's own announcement says tracks are API-accessible unless the artist opts out, that artists' chosen restrictions carry over to the API, and that developers must follow the Audius API Terms. SONORA only streams tracks the API marks streamable and only offers downloads the artist allows. If you publish SONORA, read the current [Audius API terms](https://docs.audius.org) and keep attribution (the app credits Audius and shows each track's source).
- **Jamendo** (optional). Creative Commons music. You need your own free client ID from <https://devportal.jamendo.com>; paste it in Settings (gear icon on Home, then Music sources). It is stored on your device only. Respect each track's licence.
- **Internet Archive** (optional, experimental). Searches only items that carry a Creative Commons or public-domain licence URL.
- SONORA does **not** scrape or proxy any commercial streaming service and has no way to play Spotify, YouTube Music, Apple Music and similar catalogues.

## Project layout

```
src/            sources (plain JS, concatenated in numeric order, plus shell.html and styles.css)
build.js        dependency-free build  ->  dist/index.html, dist/artifact.html, PWA files
tools/          make-icons.js (PNG icons from the logo SVG)
test/           mock Audius server, ffmpeg asset generator, Playwright e2e suites
docs/           ANDROID.md, ARCHITECTURE.md, TEST-REPORT.md
dist/           build output (included so you can use it immediately)
package.json    npm scripts: build, serve, icons, assets, test, test:chrome
```

```bash
node build.js                    # rebuild dist/
node tools/make-icons.js         # regenerate PNG icons (needs Playwright)
# tests (need: node, playwright with Chromium, ffmpeg, python3)
bash test/make-assets.sh         # synthesise real test audio with tags
node test/e2e-core.js            # boot, search, playback, queue, errors, keyboard, back button
node test/e2e-lib.js             # playlists, library, local files, offline, backup/restore
node test/e2e-extra.js           # EQ, crossfade, sleep, settings, providers (stubbed), layout, contrast
node test/e2e-pwa.js             # service worker + offline reload
PW_CHANNEL=chrome node test/e2e-core.js   # same suites on installed Google Chrome
```

The suites start their own static server (port 4000) and mock Audius (port 4010). Pass a text filter as the first argument to run matching tests only.

## Honest limitations

- Audius availability, response shape drift and per-track CORS behaviour can only be confirmed live. The equalizer needs audio hosts that send CORS headers; if one doesn't, SONORA detects it, switches the equalizer off and says so.
- Crossfade and the equalizer are web-audio features; they are not available in a future native (Media3) engine without extra work.
- Local music is stored in the browser's IndexedDB. Browsers can evict it under storage pressure unless the app is installed or persistent storage is granted. Export your library JSON regularly (it contains metadata, not the audio files).
- No account system: playlists live on one device until you export them.
