# SONORA test report

Last full run: **2026-11-20**, after the final code change, rebuilt `dist/`.

## Bottom line

- The app's own logic (UI, player, queue, playlists, library, local music, offline, settings, error handling) passes **55 end-to-end tests + 6 offline/PWA checks, on two browser builds**, with real audio decoding.
- **It has not been run against the live Audius service.** The sandbox the app was built in cannot reach `api.audius.co` (the proxy refuses the connection; re-checked on 2026-11-20 and still refused). Every "streaming" test ran against a **local mock Audius server** that serves real MP3 files and imitates Audius's documented REST responses. The first run on a normal internet connection is the first live test. If Audius has changed its response format, some shelves could show errors; the app is built to show a message and a Retry button rather than break.
- Jamendo and Internet Archive were tested **only with stubbed responses** in their documented formats.
- Not tested at all: Firefox, Safari/WebKit, iOS, real Android devices, the Android/Capacitor/Media3 code, lock-screen and background playback.

## Results

| Suite | What it covers | Chromium 157 (Playwright build) | Google Chrome 153 (installed) |
|---|---|---|---|
| `e2e-core.js` | boot, search, real playback, queue, errors, keyboard, back button | **20 / 20** | **20 / 20** |
| `e2e-lib.js` | playlists, library, artist/album pages, explore, local files, lyrics, offline downloads, backup/restore | **15 / 15** | **15 / 15** |
| `e2e-extra.js` | speed, EQ, crossfade, sleep timer, session restore, settings, data saver, stats, Jamendo/Archive (stubbed), blocked network, artifact build, layout ×4 widths, contrast | **20 / 20** | **20 / 20** |
| `e2e-pwa.js` | service worker, offline reload, offline local playback, manifest/icons | **6 / 6** | **6 / 6** |

Run with `node test/e2e-core.js` etc. (`PW_CHANNEL=chrome` for installed Chrome). Playwright 1.63.0.

## Test environment

- **Mock Audius** (`test/mock-audius.js`): 24 tracks, 5 playlists/albums, real stream endpoint that answers `302` to an MP3 file and honours `Range` requests. Deliberate edge cases: a track whose title contains HTML and a script-style attribute, a non-streamable track, a 14-second track (to reach "ended" quickly), tracks with no artwork, a track whose stream returns 404, tracks whose artist allows download. A control endpoint can switch CORS on/off, add delay and force failures.
- **Test audio** (`test/make-assets.sh`): generated with ffmpeg (synthesised tones, no copyrighted material), with real ID3v2, Vorbis-comment and MP4 tags and cover art; a hand-built ID3 file with a UTF-16 `USLT` lyrics frame; an Opus file; a non-audio file and a corrupt "mp3" for rejection tests.
- Browsers run headless. Audio is decoded by the real browser media stack, and tests assert `currentTime` actually advances, that `Range` requests reached the server, and (for EQ) that a measured signal passes through the filter chain.

## What each suite proves

**Core (20)** — boots with no JS errors and four tabs; every `data-act` in the markup has a handler (no dead buttons); hostile provider text is escaped; every icon-only button has an accessible name; tab navigation; live search with history; "no results" and API-failure messages; **real playback** (audio advances, stream served via 302 with Range requests, mini-player updates, Media Session metadata set); pause/seek/next/previous/volume/mute; auto-advance, repeat-one and end-of-queue behaviour; shuffle and un-shuffle; queue sheet (jump, remove, play next, add); non-streamable track message; dead stream (404) skip without looping; trending falls back to the saved snapshot and says so; shelf error with working Retry; network drop mid-stream and automatic resume; history balance (regression, see bug 1); keyboard shortcuts; back button closes Now Playing and sheets.

**Library (15)** — playlist create (name, description, cover upload) → add → remove → reorder (menu and real pointer drag) → rename → play → shuffle → delete; add-to-playlist from a song menu without duplicates; likes with sort/filter; artist page + follow; album page + save; every Explore tile opens; local import of mp3/wav/flac/m4a with real tag and cover parsing and junk rejected; local playback across reload and offline; embedded and `.lrc` lyrics; a genuine UTF-16 USLT frame decoded; removing a local track; offline download of a permitted track plays with the network off; export → wipe → import restores the library; the export "Download file" button produces a real browser download on a normal page and uses the viewer's `downloads` capability (including decline and failure handling) when it is present.

**Extra (20)** — speed; EQ with a real signal, EQ restore on launch, EQ falling back when the server forbids CORS; crossfade overlap and its skip conditions; sleep timer (end-of-track and timed with fade-out); session restore (paused, never auto-plays); theme/accent/persistence; data saver; stats; Jamendo and Archive with stubbed responses; fully blocked network; the artifact build inside a strict-CSP frame; no horizontal overflow at 320, 360, 768 and 1440 px; WCAG AA text contrast (4.5:1) for 2 themes × 4 accents.

**PWA (6)** — service worker activates; the shell reloads with the network switched off; the local library is available offline; a local song plays after a cold offline reload; the manifest is valid and all its icon files exist; no page errors.

## Bugs the tests found (all fixed, all re-tested)

| # | Problem | Fix |
|---|---|---|
| 1 | **Back button left the app.** A menu item that closed one sheet and opened another left the browser history one entry short, so the next Back went to a blank page. | History calls are now serialised through a queue (`H`) that waits for the browser's `popstate`; regression test asserts the history depth equals the open-layer count. |
| 2 | **"Delete everything" didn't stay deleted.** The page's `pagehide` save wrote the library back. | A `frozen` flag in the storage layer blocks all writes after a wipe. |
| 3 | Lyrics stored in an ID3 `TXXX` frame were ignored. | Parsed, in addition to `USLT`. |
| 4 | EQ switched on in a previous session was not rebuilt on launch (UI said "on", audio unprocessed). | The audio graph is rebuilt at startup, and EQ is switched off honestly if that fails. |
| 5 | Playback position was lost on a quick reload. | Session is saved on `pagehide`, on hidden, and on pause. |
| 6 | Light-theme secondary text and accent text were below 4.5:1 contrast. | Darker light-theme tokens; contrast is now a test. |
| 7 | Data-saver mode was only applied when toggled, not when loaded from storage. | Applied at theme-apply time. |
| 8 | The artist button on Now Playing had no accessible name. | Labelled. |
| 9 | The first card of a shelf sat flush against the screen edge after snapping. | `scroll-padding`. |
| 10 | Found when publishing the artifact: the backup "Download file" button does nothing inside Claude's artifact viewer (it blocks page-initiated downloads). | The button now uses the viewer's `downloads` capability when present and the normal link otherwise; Copy always works. New test covers both paths. |

Several other failures during development were mistakes in the tests themselves (wrong selector, skeleton rows matched as real rows, stale expectations) and were corrected in the tests, not the app. One more was found while writing this report: `e2e-pwa.js` read its audio file relative to the current directory and failed when run from the project root. It now resolves the path from its own folder.

## Not verified — please read

| Claim | Status |
|---|---|
| Streaming and search work against **live Audius** | **Unverified.** Mock only. |
| Audius endpoints `users/search`, `playlists/search`, `playlists/{id}/tracks`, `playlists/trending` | **Unverified.** Written from documentation and OpenAPI mirrors; not seen live. |
| Audius audio hosts send CORS headers (needed for the equalizer) | **Unverified.** The app detects failure and switches EQ off. |
| Jamendo, Internet Archive | **Unverified live.** Stubbed responses only; both are off by default. |
| Firefox, Safari, iOS | **Not tested.** |
| Real Android phone, APK, Capacitor wrapper, Media3 service | **Not built or tested.** |
| Background playback, lock-screen controls, headset buttons | **Not testable in headless browsers.** Media Session metadata is verified to be *set*; whether a given phone shows controls is not. |
| Lyrics for streamed songs | **No provider exists.** Only lyrics embedded in your own files or `.lrc` files you attach. |
| Accounts / cloud sync | **Not implemented** (design in ARCHITECTURE.md; third-party free-tier figures were read from their pricing pages and must be re-checked before use). |
| Screen-reader behaviour | Names/labels are checked automatically; real screen-reader use was not tested. |
| Performance on low-end phones | Not measured. |
| Browser support of the file/folder pickers on Android WebView | Not tested. |

## How to reproduce

```bash
bash test/make-assets.sh          # needs ffmpeg and python3
node build.js
node test/e2e-core.js && node test/e2e-lib.js && node test/e2e-extra.js && node test/e2e-pwa.js
PW_CHANNEL=chrome node test/e2e-core.js   # installed Google Chrome
```

To test against the real service on a machine with internet, open `dist/index.html` over `http://localhost` and use the app normally; the suites deliberately use the mock so they are repeatable and don't hit Audius.
