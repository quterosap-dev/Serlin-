# SONORA architecture

How the app is put together, where data lives, how to add a music source, and how an account/sync backend would plug in later.

> **Status labels used below**
> **Implemented and tested**: in the code, covered by the e2e suites (against a local mock of Audius, see [TEST-REPORT.md](TEST-REPORT.md)).
> **Design only**: written down so it can be built later. Not implemented, not tested.

---

## 1. Build and module layout

No framework, no bundler dependencies. `build.js` concatenates the files in `src/` in numeric order into **one global script**, inlines `styles.css` and `shell.html`, and writes `dist/`.

| File | Responsibility |
|---|---|
| `00-util.js` | DOM helper (`$`), `esc` (HTML escaping), `debounce`/`throttle`, time/number formatting, `Bus` (tiny event emitter), toasts. |
| `01-storage.js` | `LS` (localStorage with in-memory fallback and a `frozen` flag used by "Delete everything"), `IDB` (IndexedDB wrapper), `PREFS`, `LIB`, `slim()`, the `Sync` stub, track registry `TR`. |
| `02-providers.js` | Network layer (`jget`, cache, in-flight de-duplication, stale fallback), `Audius`, `Jamendo`, `Archive`, `searchAll`, `resolveSources`. |
| `03-local.js` | Local files: file import, ID3v2 / FLAC / MP4 tag and cover parsing, LRC parsing, IndexedDB blob storage. |
| `04-lib.js` | `Lib`: every mutation of the user's library (likes, playlists, follows, history, stats, backup/restore). No UI code. |
| `05-player.js` | `PL` player engine, `Q` queue, `E` audio graph (EQ), sleep timer, Media Session, session save/restore. |
| `06-ui.js` | Rendering primitives (rows, cards, shelves with skeleton/error/retry), sheets, toasts, the navigation stack `UI_STACK` and history queue `H`. |
| `07-browse.js` | Home, Explore, Search. |
| `08-library.js` | Library tabs, playlist/album/artist pages, downloads, stats. |
| `09-player-ui.js` | Mini-player, Now Playing, queue sheet, lyrics view. |
| `10-actions.js` | `ACT`: one dispatcher for every `data-act="…"` button in the markup (so there are no inline handlers). |
| `11-boot.js` | Wiring, keyboard shortcuts, service-worker registration, `window.SONORA` debug hook used by the tests. |

Build outputs: `dist/index.html` (standalone app), `dist/artifact.html` (fragment for the Claude artifact viewer), `manifest.webmanifest`, `sw.js`, `icons/`.

## 2. Data model — implemented and tested

### Storage

| Where | Key / store | Holds |
|---|---|---|
| localStorage | `sonora.prefs` | Preferences: theme, accent, data saver, crossfade, EQ, volume, speed, shuffle/repeat, provider switches, Audius host, **Jamendo client ID (device only)**. |
| localStorage | `sonora.lib` | The library `LIB` (below). |
| localStorage | `sonora.session` | Queue, current track and position, restored **paused** on next launch (never auto-plays). |
| localStorage | `sonora.snap` | Last good Home shelves, shown with "Saved from …" when the network fails. |
| IndexedDB `sonora` (v1) | `files` | Local audio files as Blobs. |
| IndexedDB `sonora` | `meta` | Parsed tags and cover art for local files. |
| IndexedDB `sonora` | `offline` | Downloaded copies of tracks the artist allows downloading. |

If localStorage or IndexedDB is unavailable (private mode, blocked), the app keeps working in memory and says storage is unavailable instead of failing silently.

### `LIB` (the part that would sync)

```
liked[]       { t: track, at }
playlists[]   { id, name, desc, cover, tracks: [track], created, updatedAt }
savedLists[]  saved Audius playlists / albums
followed[]    followed artists
history[]     { t: track, at }   (capped at 150)
searches[]    recent queries     recentItems[] recently opened items
stats         { seconds, plays, byDay, artists, genres }
lyrics        { trackId: text | LRC }     downloads[]   tracks saved offline
tombstones[]  { type, id, at }    deletions, kept for future sync (capped at 500)
updatedAt     set by every mutation
```

A **track** is stored through `slim()`, a whitelist of small fields (id, source, title, artist, artwork URLs, duration, genre, permission flags, …). IDs are namespaced by source: `au:123` (Audius), `ja:…` (Jamendo), `ia:…` (Internet Archive), `lo:…` (a local file, hashed from name, size and modified time).

Every mutation goes through `Lib.*`, which stamps `updatedAt`, writes a tombstone on deletion, saves (debounced, and forced on `pagehide`/`visibilitychange`), and emits a `lib` event the UI listens to.

### Backup / restore
`Lib.exportJSON()` writes `{app: "SONORA", version: 1, library: {...}, prefs: {...}}` and **blanks the Jamendo client ID**. `Lib.importJSON()` **merges additively** (it adds playlists, likes, saved items and follows that are not already present; it does not delete or overwrite). It rejects non-JSON and non-SONORA files with a readable message. Audio files themselves are not in the backup.

## 3. Provider layer — implemented and tested against mocks

`jget(url, {ttl, provider, signal})` is the single network path: in-memory cache (250 entries, 5-minute default TTL), de-duplication of identical in-flight requests, abort support, typed errors (`kind`: network/http/parse), and a network-status model (`NET`) behind the offline/"service trouble" banners. `jgetStale` falls back to an older cached value when a refresh fails.

- **Audius** (`Audius`): `trending`, `searchTracks`, `searchUsers`, `searchLists`, `trendingLists`, `listTracks`, `userTracks`, `user`, `streamUrl`. Every request carries `app_name=SONORA`. Normalisers (`normAudiusTrack/User/List`) turn API objects into SONORA shapes and tolerate missing fields (null artwork, missing user, and so on). A track is playable only if the API says `is_streamable !== false` and `access.stream !== false`; download requires `access.download`. The stream URL is `/v1/tracks/{id}/stream`, which the API answers with a redirect to the audio file. The host is configurable (`PREFS.audiusHost`) because Audius is a decentralised network; the default is `https://api.audius.co`.
- **Jamendo** (`Jamendo`): only when the user enables it and supplies their own client ID. Uses the documented v3.0 `tracks` endpoint.
- **Internet Archive** (`Archive`): advanced search restricted to items with a Creative Commons / public-domain licence URL, then a metadata lookup to pick a playable audio file.
- `searchAll` queries all enabled providers in parallel and interleaves results; one provider failing does not blank the others.

### Adding a provider
1. Write `normXTrack()` returning the common track shape with a unique `src` prefix.
2. Add an object with `enabled()` and the search/list functions you need, calling `jget(..., {provider: 'X'})`.
3. Register it in `searchAll` and, if it needs a late-bound stream URL, in `resolveSources`.
4. Add a toggle in Settings and attribution text in the README.
Do not add a provider unless its terms allow third-party client streaming.

## 4. Player engine — implemented and tested

- Two `<audio>` **decks** so crossfade can overlap the outgoing and incoming tracks. A deck has its own element; one is "active".
- **EQ** is a 5-band `BiquadFilter` chain, built **on demand** only when the EQ is on (routing an element through WebAudio requires CORS-enabled audio, so the decks are created with `crossOrigin="anonymous"` only then). If a remote track then fails to load on every candidate URL, the engine assumes the host does not allow audio processing, rebuilds the decks without the graph, switches the EQ off and tells the user. (Tested with a mock that can switch CORS headers on and off. Real hosts' CORS behaviour is unverified.)
- **Network loss**: on a stalled stream (10 s of buffering) or an error while offline, the engine waits and resumes from the same position when the browser reports it is back online.
- **Unplayable tracks** (404, non-streamable, decode error): skipped with a message when "Skip unavailable tracks" is on; after three failures in a row playback stops instead of skipping through the whole queue.
- **Queue**: reorder, remove, play next, add to queue, shuffle (keeps the current track first), repeat off/all/one.
- **Media Session**: metadata (title, artist, album, artwork) and actions (play, pause, previous, next, seek, seek-to) so lock-screen and notification controls work **where the browser supports them**.
- **Sleep timer**: minutes or end-of-track, with a fade-out.
- **Session**: saved every few seconds and on `pagehide`; restored paused.
- **Stats**: only real listening time counts (seeking does not).

## 5. Navigation and the back button — implemented and tested

Sheets, Now Playing, album/artist/playlist pages and search are entries on a stack (`UI_STACK`). Each entry is mirrored by a browser-history entry so the **system Back gesture or Android back button closes the top layer instead of leaving the app**. History calls are serialised through a small queue `H`, because `history.go()` is asynchronous and overlapping calls (a sheet that opens another sheet) previously left history one entry short and dropped the user out of the app. A regression test asserts `H.depth === UI_STACK.length` after navigation settles.

## 6. Offline and PWA — implemented and tested

The service worker caches **only the app shell** (the HTML, manifest, icons). It never intercepts cross-origin requests or `Range` requests, so audio streaming is never touched by the cache. Streams are not cached; "Download" stores a copy in IndexedDB only for tracks whose artist permits it.

## 7. Accounts and cloud sync — DESIGN ONLY (not implemented, not tested)

Today everything is on one device. The code is arranged so a backend can be added without rewriting the app:

- every mutation already stamps `updatedAt` and records deletions as tombstones;
- all saves pass through `saveLibNow()`, which calls `Sync.push()`;
- `Sync` is a stub `{ adapter, push() }`. **There is no `pull()` or merge yet**; that is the work to do.

### What a sync layer has to add
1. Sign-in UI and a session.
2. `pull()` on launch / when the tab becomes visible.
3. A merge: for each collection, union by id; for an id present on both sides keep the one with the newer `updatedAt`; drop any id that has a newer tombstone. (Last-writer-wins is simple and good enough for one person's playlists. It can lose a concurrent edit made on two devices at the same moment.)
4. `push()` after local mutations, debounced, with retry when offline.
5. Do **not** sync local audio files or downloads. They are large, they may be copyrighted, and the free tiers' storage and egress would be used up quickly. Sync only metadata (a local track would appear as "file not on this device").

### Option A — Supabase (Postgres + Auth)
Figures from supabase.com/pricing, read on 2026-11-20 (check again before relying on them): Free plan with 50,000 monthly active users, 500 MB database, 1 GB file storage, 5 GB egress (plus 5 GB cached), 2 active projects; **free projects are paused after one week of inactivity**.

Sketch (untested). One row per user keeps it simple; the library JSON is small:

```sql
create table public.libraries (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  data       jsonb       not null,
  updated_at timestamptz not null default now()
);
alter table public.libraries enable row level security;
create policy "own library select" on public.libraries for select using (auth.uid() = user_id);
create policy "own library insert" on public.libraries for insert with check (auth.uid() = user_id);
create policy "own library update" on public.libraries for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own library delete" on public.libraries for delete using (auth.uid() = user_id);
```

Client: `@supabase/supabase-js` with the project URL and the **anon (publishable) key**. The anon key is designed to be public **only because Row Level Security is on**; leave RLS off and anyone can read everyone's data. Never put the `service_role` key in the app.

### Option B — Firebase (Auth + Firestore)
Spark plan: no payment details required, and when a product's free quota is exceeded it is **shut off until the quota resets** rather than billed. Cloud Functions need the paid Blaze plan, so do all merging on the client and protect data with Firestore Security Rules (`request.auth.uid == userId`). Quotas have changed in the past, so read the current Firestore limits (daily reads/writes) on Firebase's pricing page before choosing.

### Either way
- Magic-link or Google sign-in avoids storing passwords.
- Add rate/size limits in rules or constraints so one account cannot fill the free tier.
- Provide "export my data" and "delete my account and data".
- Tell users what is stored. Playlists reference tracks by provider ID plus a small metadata snapshot.

## 8. Security and privacy notes

- No secrets are stored in the app. The Jamendo client ID is not a secret, but it is kept only in the device's localStorage and **excluded from backups**.
- The app has no analytics, no ads and no third-party scripts. The only external requests are to the music providers the user enabled, artwork hosts, and Google Fonts for the typefaces.
- All text from provider APIs (titles, artist names, descriptions) is inserted with `textContent`/escaped attributes. A test serves a hostile track title (`<b>…</b> <img src=x onerror=alert(1)>`, quotes, ampersand) and asserts that no `<img>` element was injected and that the title is shown as literal text.
- No inline event handlers; all interaction goes through `data-act` and one delegated listener, which keeps the page compatible with a strict Content-Security-Policy.
- Importing a backup validates the shape before merging.

## 9. Audius terms and attribution

Per Audius's own announcement of its API terms update, developers using the API are governed by the Audius API Terms; tracks are accessible through the API unless the artist opts out; and artists' chosen restrictions carry over to API use. SONORA therefore: identifies itself (`app_name=SONORA`), plays only tracks the API marks streamable, offers download only where `access.download` is true, links each track back to its Audius page (`perm`), and credits Audius in the app. The full API Terms page (docs.audius.org) could not be retrieved while building this, so **read it yourself before publishing the app publicly**.

## 10. Enabling Jamendo (optional)

1. Create a free account at <https://devportal.jamendo.com> and register an application to get a **client ID**.
2. In SONORA: Home → gear icon (Settings) → Music sources → turn on Jamendo and paste the client ID. (It is saved on the device only.)
3. Jamendo music is licensed per track under Creative Commons; keep attribution and respect each licence's conditions (some forbid commercial use). Jamendo's terms may restrict commercial applications of the API; read them if SONORA is ever monetised.
