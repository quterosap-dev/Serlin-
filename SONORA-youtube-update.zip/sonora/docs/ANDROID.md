# Turning SONORA into an Android app

> **Read this first.** SONORA has **not** been built as an Android app. No Android SDK, emulator or device was available while this project was made, so **nothing in this guide has been compiled or run**. The setup facts (versions, commands, manifest entries, Capacitor plugin pattern) were read from the current Capacitor and Android Media3 documentation. The Java code below is a **reference skeleton** to start from. Expect to fix compile errors and to test on a real phone.

There are two stages, and you can stop after the first:

1. **Wrap the web app** in a Capacitor Android project. This gives you an installable APK that runs `dist/index.html` in a WebView. The app logic is the same one that was tested in Chrome.
2. **Add a native audio engine** (Media3 `MediaSessionService`) so playback continues reliably with the screen off and shows a proper media notification. This is the part that browsers cannot guarantee.

---

## 1. What you need

From Capacitor's environment-setup page (v8):

- Node.js **22 or newer**
- Android Studio **2025.2.1 or newer** (it bundles the JDK that Capacitor 8 needs)
- Android SDK with **API level 24** (Android 7.0) as the minimum Capacitor supports

Everything here is free. Google Play distribution needs a paid developer account (check the current fee); sideloading an APK does not.

## 2. Wrap the web app (stage 1)

From the project root (the folder containing `dist/`):

```bash
node build.js                       # make sure dist/ is current
npm init -y                         # skip if package.json already exists (it does in this project)
npm i @capacitor/core @capacitor/app
npm i -D @capacitor/cli @capacitor/android
npx cap init SONORA com.yourname.sonora --web-dir dist     # pick your own reverse-domain app id
npx cap add android
npx cap sync android                # copies dist/ into the Android project
npx cap open android                # opens Android Studio
```

In Android Studio, let Gradle sync, pick a device or emulator, and press Run. Each time you rebuild the web app, run `node build.js && npx cap sync android` again.

### Debug APK from the command line
```bash
cd android && ./gradlew assembleDebug
# result: android/app/build/outputs/apk/debug/app-debug.apk   (install with: adb install -r <that file>)
```

### Release build
Use Android Studio: **Build → Generate Signed Bundle / APK**, create a keystore, and **back the keystore up** (losing it means you cannot update the app under the same identity). Play Store uploads use the `.aab` bundle.

## 3. Things that behave differently inside the WebView (check each one)

These are the places most likely to differ from the desktop-Chrome testing. None has been tested in a WebView.

| Area | What to check |
|---|---|
| **Origin and CORS** | Capacitor serves the app from its own local origin (by default `https://localhost`), so requests to `api.audius.co` are cross-origin exactly as on the web. If Audius sends CORS headers for browsers (it must for web apps to work), it should behave the same. Confirm on a device. Capacitor also has an optional native HTTP plugin if a provider blocks WebView origins. |
| **Audio over HTTPS** | Use HTTPS music hosts only. Android blocks cleartext HTTP by default, and mixed content from an HTTPS page is blocked. |
| **Service worker** | Not needed inside the app (the files are already local). It is harmless, but you may skip registering it when `window.Capacitor?.isNativePlatform()` is true. |
| **Local music picker** | The file picker (`<input type="file">`) is expected to work in Capacitor's WebView. The **folder** picker (`webkitdirectory`) is not reliably supported on Android WebView, so use the multi-file picker there. Verify both. |
| **Storage** | localStorage and IndexedDB persist in the app's private storage. Imported local music is copied into IndexedDB, so it survives, but the user's storage space is used twice. |
| **Back button** | SONORA's screens are history entries, so the Android back button should close the top sheet or page first. If back exits the app too early, add the `@capacitor/app` listener below. |
| **Autoplay** | A WebView may require a user gesture before audio starts. SONORA restores sessions paused and starts audio only from a tap, which is the safe pattern. |
| **EQ and crossfade** | They use WebAudio on the web engine. A native engine would need its own implementation (see §6). |

Optional back-button handling (test the default first; Capacitor's default is to navigate WebView history):
```js
// in 11-boot.js, only when running natively
if (window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()) {
  // SONORA is not bundled, so this relies on Capacitor.Plugins exposing @capacitor/app.
  // If App is undefined on a device, bundle the file with a bundler and `import { App } from '@capacitor/app'`.
  const { App } = Capacitor.Plugins;
  App.addListener('backButton', () => {
    if (UI_STACK.length) { popTop(false); }          // close the top sheet / page
    else App.minimizeApp();                          // do not kill playback
  });
}
```

## 4. Why background playback needs stage 2

A browser or WebView is allowed to pause or kill page audio when the screen is off or the app is backgrounded. This depends on the phone maker's battery manager, the Android version and the WebView version, so **it cannot be promised from web code**. SONORA registers Media Session metadata and handlers (which is what lets a browser show lock-screen controls), but that only helps where the platform cooperates.

The dependable way is the way every Android music app does it: audio is played by a **foreground service** that owns a Media3 `ExoPlayer` and a `MediaSession`. Android then shows a media notification with controls, the system can route headset/Bluetooth buttons to it, and the process keeps running with the screen off.

## 5. The native service (Media3) — reference skeleton

Facts taken from the Media3 background-playback documentation:

- Subclass **`MediaSessionService`**; build the player and the `MediaSession` in `onCreate`, return the session from `onGetSession`, release both in `onDestroy`.
- Manifest permissions: `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_MEDIA_PLAYBACK`.
- Declare the service with `android:foregroundServiceType="mediaPlayback"` and an intent filter for the action `androidx.media3.session.MediaSessionService`.
- Media3 creates a media-style notification automatically.
- The service leaves the foreground after the player has been paused or stopped for 10 minutes.
- Optionally stop playback when the user swipes the app away by overriding `onTaskRemoved` to call `pauseAllPlayersAndStopSelf()`.

`android/app/build.gradle` (use the **current** Media3 version from the Android developers release page; one is deliberately not pinned here because it was not verified):
```gradle
dependencies {
    implementation "androidx.media3:media3-exoplayer:<current-version>"
    implementation "androidx.media3:media3-session:<current-version>"
}
```

`android/app/src/main/AndroidManifest.xml` additions:
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
<!-- Android 13+: needed to show the media notification; request it at runtime -->
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<application ...>
    <service
        android:name=".PlaybackService"
        android:foregroundServiceType="mediaPlayback"
        android:exported="true">
        <intent-filter>
            <action android:name="androidx.media3.session.MediaSessionService" />
        </intent-filter>
    </service>
</application>
```

`PlaybackService.java` (skeleton, not compiled):
```java
package com.yourname.sonora;

import androidx.annotation.Nullable;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class PlaybackService extends MediaSessionService {
    private MediaSession mediaSession;

    @Override public void onCreate() {
        super.onCreate();
        ExoPlayer player = new ExoPlayer.Builder(this).build();
        mediaSession = new MediaSession.Builder(this, player).build();
    }

    @Nullable @Override
    public MediaSession onGetSession(MediaSession.ControllerInfo controllerInfo) {
        return mediaSession;
    }

    @Override public void onDestroy() {
        if (mediaSession != null) {
            mediaSession.getPlayer().release();
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }
}
```

## 6. Connecting the web app to the native engine — design

Capacitor's documented local-plugin pattern (v8, Java): a class annotated `@CapacitorPlugin(name = "…")` that extends `Plugin`; methods annotated `@PluginMethod()` taking a `PluginCall` and ending in `call.resolve(...)` or `call.reject(...)`; events sent with `notifyListeners("name", jsObject)`; registered in `MainActivity.onCreate` with `registerPlugin(X.class)` **before** `super.onCreate(...)`; called from JS through `registerPlugin('Name')` from `@capacitor/core`.

### What the web engine actually needs from an audio element
`mkDeck()` in `src/05-player.js` creates `new Audio()` and the engine uses only this surface, which makes a drop-in facade practical:

- properties: `src`, `currentTime`, `duration`, `volume`, `playbackRate`, `preservesPitch`, `crossOrigin`, `preload`, `ended`, `error`
- methods: `play()`, `pause()`, `load()`, `setAttribute/getAttribute/removeAttribute('src')`, `addEventListener`
- events: `loadstart`, `loadedmetadata`, `durationchange`, `canplay`, `playing`, `play`, `pause`, `waiting`, `stalled`, `seeking`, `timeupdate`, `ended`, `error`

Plan: write `NativeAudio` (in a new `src/05b-native.js`) that implements exactly that surface by forwarding to a Capacitor plugin and re-dispatching native events as DOM events, and have `mkDeck()` use it when `Capacitor.isNativePlatform()` is true. The queue, shuffle, sleep timer, UI and library code then stay unchanged.

### Plugin contract (suggested)
| JS → native | Meaning |
|---|---|
| `load({url, title, artist, album, artworkUrl, startAt})` | Prepare a track (set `MediaItem` with `MediaMetadata` so the notification shows it). |
| `play()` / `pause()` / `seek({ms})` | Transport. |
| `setRate({rate})` / `setVolume({v})` | Speed, volume. |
| `queueHint({next:[…]})` | Optional: let ExoPlayer pre-buffer the next track. |

| native → JS (`notifyListeners`) | Meaning |
|---|---|
| `state` `{playing, buffering, ended}` | Maps to `play/pause/waiting/playing/ended` DOM events. |
| `time` `{posMs, durMs}` ~4×/s | Maps to `timeupdate` and `durationchange`. |
| `error` `{code, message}` | Maps to `error`. |
| `next` / `prev` | Notification and headset buttons; call `PL.next()` / `PL.prev()`. |

Skeleton (reference only):
```java
@CapacitorPlugin(name = "SonoraAudio")
public class SonoraAudioPlugin extends Plugin {
    @PluginMethod()
    public void load(PluginCall call) {
        String url = call.getString("url");
        if (url == null) { call.reject("url is required"); return; }
        // connect to PlaybackService through a MediaController (androidx.media3.session),
        // set a MediaItem with MediaMetadata, prepare(), then:
        call.resolve();
    }
    // play, pause, seek, setRate, setVolume likewise; push events with:
    //   JSObject o = new JSObject(); o.put("playing", true); notifyListeners("state", o);
}
```
```java
// MainActivity.java — register BEFORE super.onCreate
public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SonoraAudioPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
```
```js
// JS side
const Native = Capacitor.registerPlugin('SonoraAudio');
await Native.load({ url, title, artist, album, artworkUrl, startAt: 0 });
Native.addListener('time', e => { /* update currentTime/duration, dispatch 'timeupdate' */ });
```

### Notes and limits of the native route
- The Audius stream URL is a redirect to the audio file. ExoPlayer follows HTTP redirects by default, but check that Range requests and seeking work against the live service.
- **Equalizer and crossfade** would have to be re-implemented natively (Android's `Equalizer` effect on the audio session; two players for crossfade). Start with them disabled when native, and hide the controls.
- **Local files** are Blobs in IndexedDB, which native code cannot read. Either keep local playback on the web engine, or pass the file through a `content://` URI chosen with the native file picker.
- Offline downloads work the same way: web-side blobs stay on the web engine unless you move them to the native file system.
- Request `POST_NOTIFICATIONS` at runtime on Android 13+ or the media notification will not show.

## 7. Test checklist for a real phone

1. App installs, opens, shows Home with real Audius content (this is also the first live test of the network layer).
2. Play a track, lock the screen, wait 5+ minutes: does audio continue? (Stage 1: depends on the phone. Stage 2: should.)
3. Notification controls and Bluetooth/headset buttons: play, pause, next, previous, seek.
4. Back button: closes sheets, then pages, then minimises (does not exit mid-song).
5. Airplane mode mid-song, then back online: playback resumes.
6. Import local files (multi-select) and play them; restart the app; they are still there.
7. Rotate, split-screen, dark/light, font scaling.
8. Swipe the app away from recents: playback stops (or continues, as you decided in `onTaskRemoved`).
9. Battery-saver mode on a Xiaomi/Oppo/Samsung phone: these vendors are the ones that kill background services.

## 8. Publishing notes

- Keep the Audius attribution and the "not affiliated" text. Review the Audius API terms, Jamendo's terms if enabled, and Google Play's current policies for music and user-generated content before publishing. The publisher is responsible for compliance.
- Do not enable any provider that streams commercial catalogues without a licence.
- A `targetSdk` and Play requirements change every year; use the values the current Capacitor template and Play Console ask for.
